#!/usr/bin/env python3
"""Emberspire server: serves the game, keeps the leaderboard, chat raids, friend invites and rest reminders,
and runs the Telegram bot.

Python 3.8+ standard library. Pillow (apt install python3-pil) is optional: it turns the challenge card into
the JPEG Telegram needs for the "send to a chat" card; without it the game shares a plain link instead.

Settings come from environment variables (see emberspire.env.example):
  BOT_TOKEN   token from @BotFather (required)
  WEBAPP_URL  public https address of the game, e.g. https://ebashnya.win/
  APP_NAME    short name of the Mini App made with /newapp in @BotFather, default "game"
  PORT        local port, default 8080 (Caddy forwards https traffic here)
  DB_PATH     sqlite file, default ./emberspire.db
"""
import html as _html
import random
import base64, hashlib, hmac, io, json, os, sqlite3, threading, time, urllib.parse, urllib.request, urllib.error, mimetypes, logging

from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
WEBAPP_URL = os.environ.get("WEBAPP_URL", "").strip()
# where players write about the game and payments (a channel post); shown on /terms, /paysupport and the terms page
SUPPORT_URL = os.environ.get("SUPPORT_URL", "").strip()
def terms_url():
    return (WEBAPP_URL.rstrip("/") + "/terms") if WEBAPP_URL else ""
if WEBAPP_URL and not WEBAPP_URL.endswith("/"):
    WEBAPP_URL += "/"
APP_NAME = os.environ.get("APP_NAME", "game").strip() or "game"
PORT = int(os.environ.get("PORT", "8080"))
HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(HERE, "emberspire.db"))
PUBLIC = os.path.join(HERE, "public")
CARDS = os.path.join(HERE, "cards")
os.makedirs(CARDS, exist_ok=True)

INIT_MAX_AGE = 24 * 3600      # Telegram sign-in data older than a day is refused
ROOM_SECONDS = 12             # a fair player needs at least the 15 s cooldown plus the fight per room; 12 s leaves slack
ROOM_SLACK = 3                # rooms allowed on top of the time budget (network hiccups, retries)
TOP_N = 10

# raid: one boss per group chat per week, everyone hits whenever they like (must match the game)
RAID_NAME = "Король Пепла"
# chat bosses: name, accusative for "призывает …", words /boss understands
RAID_BOSSES = {"raidboss": ("Король Пепла", "Короля Пепла", ("король", "пепел", "king", "ash")),
               "deruv": ("Павол Дерув", "Павола Дерува", ("павол", "дерув", "pavol", "deruv", "durov", "дуров")),
               "ohevich": ("Андре Охевич", "Андре Охевича", ("андре", "охевич", "andre", "ohevich", "ohuenko")),
               "idea": ("Идейный @ideaAnimator", "Идейного @ideaAnimator", ("идейн", "idea", "аниматор", "animator", "ideaanimator"))}
RAID_NEW_W = 2967             # Идейный joins the weekly rotation from Monday 9.11.2026, so this week's boss doesn't change (must match the game)
def raid_boss_of(ci, week):
    """An event keeps the boss its admin called; a plain chat raid changes boss every week (and differs between chats)."""
    if week == -1:
        r = db.execute("SELECT boss FROM raid_events WHERE ci=?", (ci,)).fetchone()
        if r and r[0] in RAID_BOSSES:
            return r[0]
    keys = list(RAID_BOSSES)
    if week < RAID_NEW_W:
        keys = keys[:3]
    return keys[(int(hashlib.md5(str(ci).encode()).hexdigest()[:6], 16) + max(0, week)) % len(keys)]
RAID_TRIES = 3                # hits per player per chat per day (v244: Moscow day, was UTC — reset at 03:00 MSK confused players)
RAID_MIN_GAP = 30             # seconds between two hits of one player: a raid fight lasts 40 s
RAID_SHARE = 8                # each new raider adds this many typical hits to the boss's health

# friends: what the inviter gets when a friend reaches these rooms, and the newcomer's gift (must match the game)
REF_STEPS = [(10, 5, 1), (30, 5, 2), (60, 10, 3)]     # (room, rest skips, cores) for the inviter; stars are never given, only bought
WELCOME = {"skips": 5, "cores": 1}                     # the newcomer's gift: rest skips land on the server balance at once

ADMIN_IDS = {int(x) for x in os.environ.get("ADMIN_IDS", "678418106").replace(" ", "").split(",") if x}
REMIND_EVERY = float(os.environ.get("REMIND_GAP_H", "8")) * 3600      # at most one rest reminder per player in this many seconds
REMIND_AWAY = float(os.environ.get("REMIND_AWAY_MIN", "30")) * 60     # ...and only after the player has been away this long

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("emberspire")

# ---------------------------------------------------------------- storage
db_lock = threading.Lock()
db = sqlite3.connect(DB_PATH, check_same_thread=False)
# v232: WAL — a commit no longer waits for the disk (fsync only at checkpoints), readers don't block the writer
try:
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA synchronous=NORMAL")
except sqlite3.Error as e:
    logging.getLogger("emberspire").warning("WAL not enabled: %s", e)
db.execute("""CREATE TABLE IF NOT EXISTS players(
  id INTEGER PRIMARY KEY, name TEXT, username TEXT, cls TEXT, room INTEGER DEFAULT 0, level INTEGER DEFAULT 1,
  kills INTEGER DEFAULT 0, bosses INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
  first_seen REAL, updated REAL, reached REAL, flagged INTEGER DEFAULT 0)""")
# columns added after the first release: added in place, existing players keep their records
_cols = {r[1] for r in db.execute("PRAGMA table_info(players)")}
for col, decl in [("ref_by", "INTEGER"), ("welcomed", "INTEGER DEFAULT 0"), ("ref_paid", "INTEGER DEFAULT 0"),
                  ("notify", "INTEGER DEFAULT 0"), ("rest_at", "REAL DEFAULT 0"), ("reminded", "REAL DEFAULT 0"),
                  ("seen", "REAL DEFAULT 0"), ("notify_off", "INTEGER DEFAULT 0"), ("can_pm", "INTEGER DEFAULT 0"),
                  ("wipe_at", "REAL DEFAULT 0")]:
    if col not in _cols:
        db.execute(f"ALTER TABLE players ADD COLUMN {col} {decl}")
db.execute("CREATE INDEX IF NOT EXISTS by_room ON players(flagged, room DESC, reached ASC)")
db.execute("CREATE INDEX IF NOT EXISTS by_ref ON players(ref_by)")
db.execute("CREATE INDEX IF NOT EXISTS by_rest ON players(rest_at)")
# ---- balance statistics (v193): who played on which day, and every fight on a floor the hero had not cleared yet
AC_TZ_S = float(os.environ.get("AC_TZ", "3")) * 3600
db.execute("CREATE TABLE IF NOT EXISTS act(day INTEGER, uid INTEGER, PRIMARY KEY(day, uid))")
db.execute("""CREATE TABLE IF NOT EXISTS fight_log(uid INTEGER, ts REAL, room INTEGER, kind TEXT, win INTEGER, tries INTEGER,
  dur INTEGER, cls TEXT, level INTEGER, hp INTEGER, atk INTEGER, df INTEGER, q INTEGER, auto INTEGER)""")
db.execute("CREATE INDEX IF NOT EXISTS fl_ts ON fight_log(ts)")
db.execute("CREATE TABLE IF NOT EXISTS ref_hits(inviter INTEGER, visitor INTEGER, day INTEGER, PRIMARY KEY(inviter, visitor, day))")
# v238 partner program: given by the owners to bloggers/streamers only. A partner's referrals are new players who came by his
# link (startapp=p_<code>) or typed his code in their first days; he earns pct % of every Stars payment they make, forever.
# Amounts in hundredths of a star (INTEGER). Times are INTEGER unix seconds; column names avoid the PostgreSQL adapter's
# timestamp names (seen, updated, created, last, ends, ...) on purpose.
db.execute("""CREATE TABLE IF NOT EXISTS partners(uid BIGINT PRIMARY KEY, code TEXT, pct INTEGER DEFAULT 0, active INTEGER DEFAULT 1,
  gave INTEGER DEFAULT 0, earned_c INTEGER DEFAULT 0, paid_c INTEGER DEFAULT 0)""")
db.execute("""CREATE TABLE IF NOT EXISTS partner_refs(ref BIGINT PRIMARY KEY, partner BIGINT, joined INTEGER DEFAULT 0,
  spent INTEGER DEFAULT 0, earned_c INTEGER DEFAULT 0)""")
db.execute("""CREATE TABLE IF NOT EXISTS partner_pays(id INTEGER PRIMARY KEY AUTOINCREMENT, uid BIGINT, amount_c INTEGER DEFAULT 0,
  at_t INTEGER DEFAULT 0, by_uid BIGINT)""")
db.execute("CREATE INDEX IF NOT EXISTS by_partner ON partner_refs(partner)")
db.commit()
# PostgreSQL: a Telegram id does not fit a 32-bit INTEGER (SQLite's INTEGER holds 64 bits, so only PostgreSQL is hit).
# These three are the only tables created here and not by a TS migration, so older copies still declare INTEGER.
for _t, _c in (("partners", "uid"), ("partner_refs", "ref"), ("partner_refs", "partner"),
               ("partner_pays", "uid"), ("partner_pays", "by_uid")):
    try:
        db.execute(f"ALTER TABLE {_t} ALTER COLUMN {_c} TYPE BIGINT")
    except Exception:
        pass    # SQLite has no ALTER COLUMN / the column is already BIGINT — nothing to do
db.execute("""CREATE TABLE IF NOT EXISTS raids(ci TEXT, week INTEGER, max INTEGER, hp INTEGER, killed REAL,
  PRIMARY KEY(ci, week))""")
db.execute("""CREATE TABLE IF NOT EXISTS raid_hits(ci TEXT, week INTEGER, uid INTEGER, dmg INTEGER DEFAULT 0,
  claimed INTEGER DEFAULT 0, PRIMARY KEY(ci, week, uid))""")
db.execute("""CREATE TABLE IF NOT EXISTS saves(uid INTEGER PRIMARY KEY, data TEXT, score REAL, ts REAL)""")
# chat events made by a group admin with /boss: the boss lives in raids/raid_hits under ci 'g<chat id>' and week -1
db.execute("""CREATE TABLE IF NOT EXISTS raid_events(ci TEXT PRIMARY KEY, chat_id INTEGER, by_uid INTEGER, ends REAL,
  lvl INTEGER DEFAULT 1, closed INTEGER DEFAULT 0)""")
if "title" not in {r[1] for r in db.execute("PRAGMA table_info(raid_events)")}:
    db.execute("ALTER TABLE raid_events ADD COLUMN title TEXT")
if "boss" not in {r[1] for r in db.execute("PRAGMA table_info(raid_events)")}:
    db.execute("ALTER TABLE raid_events ADD COLUMN boss TEXT")
if "pin_mid" not in {r[1] for r in db.execute("PRAGMA table_info(raid_events)")}:
    db.execute("ALTER TABLE raid_events ADD COLUMN pin_mid INTEGER")
db.execute("""CREATE TABLE IF NOT EXISTS raid_tries_c(uid INTEGER, ci TEXT, day INTEGER, n INTEGER DEFAULT 0, last REAL DEFAULT 0,
  PRIMARY KEY(uid, ci, day))""")
db.execute("""CREATE TABLE IF NOT EXISTS raid_stats(uid INTEGER, ci TEXT, dmg INTEGER DEFAULT 0, best INTEGER DEFAULT 0, hits INTEGER DEFAULT 0,
  PRIMARY KEY(uid, ci))""")
db.execute("CREATE TABLE IF NOT EXISTS raid_chats(ci TEXT PRIMARY KEY)")
# v270: PostgreSQL's INTEGER ends at 2 147 483 647. Strong heroes hit the chat boss for billions now: such a hit failed
# with «integer out of range» and was lost (the game still showed its own number). Damage gets 64 bits, as in SQLite.
for _t, _c in (("raid_hits", "dmg"), ("raid_stats", "dmg"), ("raid_stats", "best")):
    try:
        db.execute(f"ALTER TABLE {_t} ALTER COLUMN {_c} TYPE BIGINT")
        db.commit()
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
db.execute("CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT)")
_rcols = {r[1] for r in db.execute("PRAGMA table_info(raids)")}
if "lvl" not in _rcols:
    db.execute("ALTER TABLE raids ADD COLUMN lvl INTEGER DEFAULT 1")
db.execute("""CREATE TABLE IF NOT EXISTS raid_tries(uid INTEGER, day INTEGER, n INTEGER DEFAULT 0, last REAL DEFAULT 0,
  PRIMARY KEY(uid, day))""")
db.commit()

# ---------------------------------------------------------------- telegram sign-in check
def check_init_data(init_data):
    """Validate Telegram Mini App initData. Returns (user, fields) or (None, None)."""
    if not init_data or not BOT_TOKEN:
        return None, None
    data = dict(urllib.parse.parse_qsl(init_data, keep_blank_values=True))
    got = data.pop("hash", None)
    if not got:
        return None, None
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    want = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(want, got):
        return None, None
    try:
        if time.time() - int(data.get("auth_date", "0")) > INIT_MAX_AGE:
            return None, None
        user = json.loads(data.get("user", "null"))
    except (ValueError, TypeError):
        return None, None
    if not (isinstance(user, dict) and "id" in user):
        return None, None
    return user, data

def display_name(u):
    name = (u.get("first_name", "") + " " + u.get("last_name", "")).strip()
    return (name or u.get("username") or "Игрок")[:40]

def as_int(v, lo=0, hi=10**9):
    try:
        return max(lo, min(hi, int(v)))
    except (ValueError, TypeError):
        return lo

def day_id(now=None):
    return int((now or time.time()) // 86400)

def week_id(now=None):
    """Weeks start on Monday 00:00 UTC, the same count the game uses."""
    return int(((now or time.time()) / 86400 + 3) // 7)

def week_end_ms(week):
    return ((week + 1) * 7 - 3) * 86400 * 1000

# ---------------------------------------------------------------- players and leaderboard
def ensure_player(user):
    """First contact registers the player, so the time budget for rooms starts counting from then.
    Returns True when the player is new."""
    now = time.time()
    with db_lock:
        cur = db.execute("INSERT OR IGNORE INTO players(id, name, username, room, first_seen, updated, seen) VALUES(?,?,?,0,?,?,?)",
                         (user["id"], display_name(user), user.get("username"), now, now, now))
        db.execute("UPDATE players SET seen=? WHERE id=?", (now, user["id"]))
        db.execute("INSERT OR IGNORE INTO act(day, uid) VALUES(?,?)", (int((now + AC_TZ_S) // 86400), user["id"]))
        if user.get("allows_write_to_pm"):
            # reminders are on by default for everyone the bot may write to, unless they switched them off
            db.execute("UPDATE players SET can_pm=1, notify=CASE WHEN notify_off=1 THEN notify ELSE 1 END WHERE id=?", (user["id"],))
        db.commit()
        return cur.rowcount == 1

def _ref_ping(inviter, friend, need, sk, co):
    """«Твой друг прошёл 10 этажей»: a bot message with a button straight to the reward."""
    with db_lock:
        pm = db.execute("SELECT can_pm FROM players WHERE id=?", (inviter,)).fetchone()
    log.info("ref step: %s passed %s for inviter %s", friend, need, inviter)
    if not (pm and pm[0]):
        return
    txt = (f"🎉 Твой друг {friend} прошёл {need} этажей!\n"
           f"Тебе награда: {sk} пропусков отдыха и {co} {'ядро' if co == 1 else 'ядра'}.\n"
           f"Забери её: Мир → Я → Друзья.")
    def go():
        try:
            tg("sendMessage", chat_id=inviter, text=txt,
               reply_markup={"inline_keyboard": [[{"text": "Забрать награду", "url": app_link("friends")}]]})
        except Exception as e:
            log.info("ref pm to %s: %s", inviter, e)
    threading.Thread(target=go, daemon=True).start()

def submit_score(user, body):
    now = time.time()
    room, level = as_int(body.get("room")), as_int(body.get("level"), 1, 10000)
    wins, kills, bosses = as_int(body.get("wins")), as_int(body.get("kills")), as_int(body.get("bosses"))
    cls = str(body.get("cls", ""))[:20]
    with db_lock:
        row = db.execute("SELECT room, first_seen FROM players WHERE id=?", (user["id"],)).fetchone()
        prev_room, first_seen = row if row else (0, now)
        reason = None
        # every room needs a won fight, a boss every tenth room, and real time between rooms
        sv = _save_of(user["id"])
        if room > wins + 1:
            reason = "more rooms than wins"
        elif room > prev_room and user["id"] not in ADMIN_IDS and (not sv or room > as_int(sv.get("maxCleared"), 0, 10**7) + 3):
            reason = "save behind"
        elif room >= 50 and bosses < room // 50:
            reason = "skipped bosses"
        elif room > prev_room and room > ROOM_SLACK + (now - (first_seen or now)) / ROOM_SECONDS:
            reason = "too fast"
        if reason:
            log.warning("score refused for %s: room %s (prev %s): %s", user["id"], room, prev_room, reason)
            return 422, {"ok": False, "reason": reason}
        best = max(room, prev_room)
        reached = now if room > prev_room else None
        db.execute("""UPDATE players SET name=?, username=?, cls=?, room=?, level=?, kills=?, bosses=?, wins=?, updated=?,
                      reached=COALESCE(?, reached) WHERE id=?""",
                   (display_name(user), user.get("username"), cls, best, level, kills, bosses, wins, now, reached, user["id"]))
        db.commit()
        # an invited friend just passed a reward floor: tell the one who invited them
        rb = db.execute("SELECT ref_by FROM players WHERE id=?", (user["id"],)).fetchone()
        steps = [st for st in REF_STEPS if prev_room < st[0] <= best] if rb and rb[0] else []
    for need, sk, co in steps:
        _ref_ping(rb[0], display_name(user), need, sk, co)
    return 200, {"ok": True, "room": best}

def _cls_aliases(key):
    """players.cls holds what the game sent: the class key or its Russian name (older versions). All spellings of one class."""
    a = {key}
    if key in CLS_RU:
        a.add(CLS_RU[key])
    if key == "duelist":
        a.add("Гамблер")
    return sorted(a)

def _cls_key(c):
    c = (c or "").strip()
    if c in CLS_RU:
        return c
    for k, v in CLS_RU.items():
        if v.lower() == c.lower():
            return k
    return "duelist" if c.lower() == "гамблер" else ""

_look_cache = {}
def leaderboard(user, cls=""):
    """The tower's top, or (v195) the top of one class; with the list of classes that have players on the board."""
    key = _cls_key(cls)
    with db_lock:
        if key:
            al = _cls_aliases(key)
            ph = ",".join("?" * len(al))
            top = db.execute(f"""SELECT id, name, cls, room, level FROM players WHERE flagged=0 AND room>0 AND cls IN ({ph})
                                 ORDER BY room DESC, reached ASC LIMIT ?""", (*al, TOP_N)).fetchall()
        else:
            top = db.execute("""SELECT id, name, cls, room, level FROM players WHERE flagged=0 AND room>0
                                ORDER BY room DESC, reached ASC LIMIT ?""", (TOP_N,)).fetchall()
        me = db.execute("SELECT room, reached, cls FROM players WHERE id=?", (user["id"],)).fetchone()
        my_key = _cls_key(me[2]) if me else ""
        rank = None
        if me and me[0] > 0 and (not key or key == my_key):
            if key:
                rank = 1 + db.execute(f"""SELECT COUNT(*) FROM players WHERE flagged=0 AND cls IN ({ph}) AND (room>? OR (room=? AND reached<?))""",
                                      (*al, me[0], me[0], me[1])).fetchone()[0]
            else:
                rank = 1 + db.execute("""SELECT COUNT(*) FROM players WHERE flagged=0 AND (room>? OR (room=? AND reached<?))""",
                                      (me[0], me[0], me[1])).fetchone()[0]
        rows = []
        for i, (pid, n, c, r, lv) in enumerate(top):
            lk = _look_cache.get(pid)  # what the hero wears, for the portraits on the podium (v232: kept 20 s, a save is 20+ KB to read)
            if not lk or time.time() - lk[0] > 20:
                sv = _save_of(pid)
                lk = _look_cache[pid] = (time.time(), _look(sv) if sv else None)
            rows.append({"rank": i + 1, "name": n, "cls": CLS_RU.get(c, c), "room": r, "level": lv or 0, "me": pid == user["id"], "tag": _tag(pid),
                         "look": lk[1]})
        counts = {}
        for c, n in db.execute("SELECT cls, COUNT(*) FROM players WHERE flagged=0 AND room>0 GROUP BY cls").fetchall():
            k = _cls_key(c)
            if k:
                counts[k] = counts.get(k, 0) + n
        db.commit()
    classes = [{"key": k, "ru": CLS_RU.get(k, k), "n": n} for k, n in sorted(counts.items(), key=lambda x: -x[1])]
    return 200, {"top": rows, "me": {"rank": rank, "room": me[0]} if rank else None, "cls": key, "my_cls": my_key, "classes": classes}

# ---------------------------------------------------------------- friends
def hello(user, fields, is_new, body):
    """A newcomer who opened an invite link (start param ref_<id>) gets a gift once, and the inviter is remembered."""
    start = str(fields.get("start_param") or body.get("start") or "")
    admin = user["id"] in ADMIN_IDS
    with db_lock:
        _qbase(user["id"]); _qbase_f(user["id"], "ekills"); _qbase_f(user["id"], "bkills")
        db.commit()
    if start.startswith("p_"):
        pj = partner_attach(user["id"], code=start[2:], is_new=is_new)
        with db_lock:     # v239: a partner's link counts for his «кто-то зашёл по твоей ссылке» too
            pr = db.execute("SELECT uid FROM partners WHERE code=?", (_pcode(start[2:]),)).fetchone()
            if pr and pr[0] != user["id"]:
                db.execute("INSERT OR IGNORE INTO ref_hits(inviter, visitor, day) VALUES(?,?,?)", (pr[0], user["id"], q_day()))
                db.commit()
        return 200, {"ok": True, "admin": admin, "partner_joined": pj.get("name") if pj.get("ok") else None,
                     "partner_gift": pj.get("gift") if pj.get("ok") else None}
    if not (start.startswith("ref_") or start.startswith("rr_") or start.startswith("duel_")):
        return 200, {"ok": True, "admin": admin}
    with db_lock:
        if start.startswith("duel_"):
            # a duel link thrown into a chat invites too: the one who threw it is the inviter
            d = db.execute("SELECT from_uid FROM duels WHERE id=?", (start[5:21],)).fetchone()
            inviter = d[0] if d else 0
        else:
            inviter = as_int(start.split("_", 1)[1], 0, 10**15)   # v268: Telegram ids are past 10⁹ now — the old cap turned every such inviter into nobody
        # the daily «someone came by your link»: any player but the link's owner, once a day each. v239: a duel challenge
        # thrown into a chat counts too — the quest's hint tells players to send one, and before it silently didn't count
        if inviter and inviter != user["id"]:
            db.execute("INSERT OR IGNORE INTO ref_hits(inviter, visitor, day) VALUES(?,?,?)", (inviter, user["id"], q_day()))
            db.commit()
        # «new» is not only the very first request: the game loads the cloud save before it says hello, and a friend may
        # have pressed /start in the bot first. A newcomer is anyone without an inviter yet, seen for the first time within
        # two days and still below floor 10 — an old player can't be claimed by someone's link.
        me = db.execute("SELECT ref_by, welcomed, room, first_seen FROM players WHERE id=?", (user["id"],)).fetchone()
        fresh = is_new or (me and me[0] is None and not me[1] and (me[2] or 0) < 10 and time.time() - (me[3] or 0) < 2 * 86400)
        if not fresh:
            return 200, {"ok": True, "admin": admin}
        ok = inviter and inviter != user["id"] and db.execute("SELECT 1 FROM players WHERE id=?", (inviter,)).fetchone()
        if not ok:
            return 200, {"ok": True}
        cur = db.execute("UPDATE players SET ref_by=?, welcomed=1 WHERE id=? AND ref_by IS NULL", (inviter, user["id"]))
        if cur.rowcount == 1:
            db.execute("UPDATE players SET skips=skips+? WHERE id=?", (WELCOME["skips"], user["id"]))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], 0, "ref-welcome-skips", WELCOME["skips"], time.time()))
            _ecr_add(user["id"], c=WELCOME["cores"], i=1)
        db.commit()
    if cur.rowcount != 1:
        return 200, {"ok": True, "admin": admin}
    log.info("player %s joined by invite from %s", user["id"], inviter)
    return 200, {"ok": True, "welcome": WELCOME}

def _ref_trusted(fid):
    """Caller holds db_lock. v257: a friend brings the inviter rewards only for floors climbed honestly: the server never
    refused one of his saves, and the anti-cheat neither holds him under suspicion nor has him hidden (the owner's
    «Оправдать» makes him count again)."""
    if _kv_get(f"refused:{fid}", ""):
        return False
    r = db.execute("SELECT status FROM ac_flags WHERE uid=?", (fid,)).fetchone()
    return not r or r[0] == "cleared"

def ref_state(uid):
    rows = db.execute("SELECT id, name, room, ref_paid FROM players WHERE ref_by=? ORDER BY room DESC LIMIT 100", (uid,)).fetchall()
    friends, skips, cores = [], 0, 0
    for fid, name, room, paid in rows:
        ok = _ref_trusted(fid)
        friends.append((fid, name, room, paid, ok))
        if not ok:
            continue
        for i, (need, k_, c) in enumerate(REF_STEPS):
            if i >= (paid or 0) and room >= need:
                skips += k_
                cores += c
    return friends, skips, cores

def ref_info(user):
    with db_lock:
        friends, skips, cores = ref_state(user["id"])
    return 200, {"friends": [{"name": n, "room": r, "hold": 0 if ok else 1} for _f, n, r, _p, ok in friends],
                 "claimable": {"skips": skips, "cores": cores}}

def ref_claim(user):
    with db_lock:
        friends, skips, cores = ref_state(user["id"])
        for fid, _n, room, paid, ok in friends:
            if not ok:
                continue
            reached = sum(1 for need, _k, _c in REF_STEPS if (room or 0) >= need)
            if reached > (paid or 0):
                db.execute("UPDATE players SET ref_paid=? WHERE id=?", (reached, fid))
        db.commit()
        if skips:
            db.execute("UPDATE players SET skips=skips+? WHERE id=?", (skips, user["id"]))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], 0, "ref-skips", skips, time.time()))
        if cores:
            _ecr_add(user["id"], c=cores)
        db.commit()
    return 200, {"skips": skips, "cores": cores}

# ---------------------------------------------------------------- chat raid
# Two kinds: the weekly boss of a group chat (key = chat_instance) and an admin's event (key 'g<chat id>', week -1, /boss).
# try_dmg(room) is what an average hero of that floor deals in one 40-second try (measured in the game's balance sim).
# The boss starts at 3 tries of the host's floor and each new fighter adds 2 tries of their own floor, so a chat of N players
# needs about two thirds of one day's tries. The fight in the game starts with the boss's real HP and ends when it dies.
def _curve(n, a, b, piv=70):
    if n <= piv:
        return 1 + a * n + b * n * n
    v = 1 + a * piv + b * piv * piv
    k = (a + 2 * b * piv) * piv / v
    return v * (n / piv) ** k

def try_dmg(room):
    r = max(1, room)
    return int(_curve(r - 1, 0.24, 0.006) * (500 + 4 * r))

def raid_key(fields, given):
    """An admin's event ('g<chat id>') when it exists; otherwise the group the game was opened from (signed by Telegram)."""
    given = str(given or "")
    if given.startswith("g"):
        ev = db.execute("SELECT ends, closed FROM raid_events WHERE ci=?", (given,)).fetchone()
        # only a running event: once it is over the bot has posted the results and the chat's own raid is back
        if ev and not ev[1] and ev[0] > time.time():
            gi = fields.get("chat_instance") if fields.get("chat_type") in ("group", "supergroup") else None
            if gi:
                db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", ("ev:" + gi, given))
            return given, -1
    inst = fields.get("chat_instance") if fields.get("chat_type") in ("group", "supergroup") else None
    if inst:
        # a group that has an admin's event: opened from that group, the game goes straight to its event
        m = db.execute("SELECT v FROM kv WHERE k=?", ("ev:" + inst,)).fetchone()
        if m:
            ev = db.execute("SELECT ends, closed FROM raid_events WHERE ci=?", (m[0],)).fetchone()
            if ev and not ev[1] and ev[0] > time.time():
                return m[0], -1
        # a group without an admin's /boss has no boss at all: only chat admins call one
        return None, "noboss"
    return None, None

def chat_label(ci, uid=None):
    """Telegram does not tell a Mini App the group's name; events know their chat, plain raids get a stable number."""
    ev = db.execute("SELECT title FROM raid_events WHERE ci=?", (ci,)).fetchone()
    if ev and ev[0]:
        return ev[0]
    n = db.execute("SELECT rowid FROM raid_chats WHERE ci=?", (ci,)).fetchone()
    if not n:
        db.execute("INSERT OR IGNORE INTO raid_chats(ci) VALUES(?)", (ci,))
        n = db.execute("SELECT rowid FROM raid_chats WHERE ci=?", (ci,)).fetchone()
    return f"Чат №{n[0]}"

def raid_view(ci, week, uid):
    """The Ash King is immortal: the view is the damage race of this chat."""
    ev = db.execute("SELECT ends, closed, lvl FROM raid_events WHERE ci=?", (ci,)).fetchone() if week == -1 else None
    top = db.execute("""SELECT h.uid, p.name, h.dmg FROM raid_hits h LEFT JOIN players p ON p.id=h.uid
                        WHERE h.ci=? AND h.week=? AND h.dmg>0 ORDER BY h.dmg DESC LIMIT 10""", (ci, week)).fetchall()
    me = db.execute("SELECT dmg FROM raid_hits WHERE ci=? AND week=? AND uid=?", (ci, week, uid)).fetchone()
    my = me[0] if me else 0
    rank = None
    if my > 0:
        rank = 1 + db.execute("SELECT COUNT(*) FROM raid_hits WHERE ci=? AND week=? AND dmg>?", (ci, week, my)).fetchone()[0]
    tot = db.execute("SELECT COALESCE(SUM(dmg),0) FROM raid_hits WHERE ci=? AND week=?", (ci, week)).fetchone()[0]
    t = db.execute("SELECT n FROM raid_tries_c WHERE uid=? AND ci=? AND day=?", (uid, ci, q_day())).fetchone()
    boss = raid_boss_of(ci, week)
    return {"name": RAID_BOSSES[boss][0], "boss": boss, "event": 1 if ev else 0, "immortal": 1, "total": tot, "chat": chat_label(ci),
            "me": {"dmg": my, "rank": rank, "tries": t[0] if t else 0},
            "top": [{"name": n or "Игрок", "dmg": d, "me": u == uid} for u, n, d in top],
            "over": bool(ev) and (ev[1] or ev[0] < time.time()),
            "endsAt": int(ev[0] * 1000) if ev else week_end_ms(week)}

def _player_room(uid):
    return (db.execute("SELECT room FROM players WHERE id=?", (uid,)).fetchone() or (0,))[0]

def raid_get(user, fields, given):
    with db_lock:
        ci, week = raid_key(fields, given)
        if not ci:
            if week == "noboss":
                return 200, {"noboss": 1}
            return 400, {"ok": False, "reason": "open the game from a group chat"}
        v = raid_view(ci, week, user["id"])
        db.commit()
        return 200, v

def raid_join(user, fields, body):
    with db_lock:
        ci, week = raid_key(fields, body.get("ci"))
        if not ci:
            if week == "noboss":
                return 200, {"noboss": 1}
            return 400, {"ok": False, "reason": "open the game from a group chat"}
        chat_label(ci)
        db.execute("INSERT OR IGNORE INTO raid_hits(ci, week, uid, dmg) VALUES(?,?,?,0)", (ci, week, user["id"]))
        db.commit()
        return 200, raid_view(ci, week, user["id"])

def raid_reward(dmg, room, event):
    """Paid right after every try, growing with damage compared to an average hero of that floor."""
    q = min(2.0, dmg / max(1, try_dmg(room)))
    gold = int((120 + room * 18) * q * (1.3 if event else 1))
    return {"gold": gold, "cores": (1 if q >= 0.6 else 0) + (1 if q >= 1.2 else 0)}

def raid_hit(user, fields, body):
    now, day = time.time(), q_day()
    with db_lock:
        ci, week = raid_key(fields, body.get("ci"))
        if not ci:
            if week == "noboss":
                return 200, {"noboss": 1}
            return 400, {"ok": False, "reason": "open the game from a group chat"}
        v = raid_view(ci, week, user["id"])
        if v["over"]:
            return 200, dict(v, counted=0, why="over")
        # three tries a day in every chat separately
        t = db.execute("SELECT n, last FROM raid_tries_c WHERE uid=? AND ci=? AND day=?", (user["id"], ci, day)).fetchone()
        n, last = t if t else (0, 0)
        if n >= RAID_TRIES:
            return 200, dict(v, counted=0, why="tries")
        if now - last < RAID_MIN_GAP:
            return 429, {"ok": False, "reason": "too soon"}
        db.execute("INSERT OR REPLACE INTO raid_tries_c(uid, ci, day, n, last) VALUES(?,?,?,?,?)", (user["id"], ci, day, n + 1, now))
        room = max(_player_room(user["id"]), 1)
        # one 40 s try can't do more than ~3 average tries of the player's floor: forged numbers are cut
        # strong heroes do many times the average of their floor; only absurd numbers are cut
        dmg = min(as_int(body.get("dmg"), 0, 10**15), 15 * try_dmg(min(max(as_int(body.get("room"), 0, 100000), 1), room + 20)))
        why = None
        if is_flagged(user["id"]):
            dmg, why = 0, "review"
        # In PostgreSQL a bare column name in ON CONFLICT DO UPDATE SET is ambiguous
        # (it exists both in the target table and in "excluded"), so the existing row
        # must be referenced by table name: raid_hits.dmg. SQLite accepts the same form.
        db.execute("""INSERT INTO raid_hits(ci, week, uid, dmg) VALUES(?,?,?,?)
                      ON CONFLICT(ci, week, uid) DO UPDATE SET dmg=raid_hits.dmg+excluded.dmg""", (ci, week, user["id"], dmg))
        db.execute("""INSERT INTO raid_stats(uid, ci, dmg, best, hits) VALUES(?,?,?,?,1)
                      ON CONFLICT(uid, ci) DO UPDATE SET dmg=raid_stats.dmg+excluded.dmg, best=MAX(raid_stats.best, excluded.best), hits=raid_stats.hits+1""",
                   (user["id"], ci, dmg, dmg))
        chat_label(ci)
        db.commit()
        v = raid_view(ci, week, user["id"])
    v["reward"] = raid_reward(dmg, room, week == -1)
    v["counted"] = dmg
    if why:
        v["why"] = why
    with db_lock:
        _ecr_add(user["id"], g=v["reward"]["gold"], c=v["reward"]["cores"])
        db.commit()
    return 200, v

def raid_stats(user, given, fields):
    """Every chat this player has fought in: their damage there this week/event and their place."""
    with db_lock:
        here, _w = raid_key(fields, given)
        rows = db.execute("SELECT ci, dmg, best, hits FROM raid_stats WHERE uid=? ORDER BY dmg DESC LIMIT 20", (user["id"],)).fetchall()
        chats, total, best, hits = [], 0, 0, 0
        for ci, dmg, b, h in rows:
            total += dmg; best = max(best, b); hits += h
            wk = -1 if ci.startswith("g") else week_id()
            my = (db.execute("SELECT dmg FROM raid_hits WHERE ci=? AND week=? AND uid=?", (ci, wk, user["id"])).fetchone() or (0,))[0]
            rank = 1 + db.execute("SELECT COUNT(*) FROM raid_hits WHERE ci=? AND week=? AND dmg>?", (ci, wk, my)).fetchone()[0] if my else "—"
            chats.append({"name": chat_label(ci), "dmg": my, "all": dmg, "rank": rank, "here": ci == here})
        db.commit()
    return 200, {"total": total, "best": best, "hits": hits, "chats": chats}

def raid_claim(user, fields, body):
    return 200, {"ok": True}

def html_esc(t):
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def mention(uid, name, username):
    """@username tags the player; without one, a link on the name still notifies them."""
    if username:
        return "@" + html_esc(username)
    return f'<a href="tg://user?id={int(uid)}">{html_esc(name or "Игрок")}</a>'

# ---- the results of a chat boss as a picture: the boss, the chat's total, a podium with the three best (v208)
# public/bot/res_<boss>.png is the background drawn from the game's art (240×168, the pedestals and the crown);
# the names and numbers are written here in the game's own pixel font (public/bot/ember_400.ttf, ember_700.ttf), then ×3.
def _fmt(n):
    return f"{int(n):,}".replace(",", " ")

def results_card(bkey, bname, tot, top, fighters):
    """Returns the URL of the picture, or None (no Pillow, no template): the caption then carries everything."""
    try:
        from PIL import Image, ImageDraw, ImageFont
        base = os.path.join(PUBLIC, "bot")
        im = Image.open(os.path.join(base, f"res_{bkey}.png")).convert("RGB")
        F = lambda w, z: ImageFont.truetype(os.path.join(base, f"ember_{w}.ttf"), z)
        d = ImageDraw.Draw(im)
        d.fontmode = "1"                       # no smoothing: pixels stay pixels when the picture is enlarged
        # the font is drawn at its own pixel size (10 for both weights; 9 breaks the thin one's letters) — big text is the same text doubled
        def text(x, y, t, w, z, col, center=False, maxw=None, big=False):
            f = F(w, z)
            k = 2 if big and d.textlength(t, font=f) * 2 <= (maxw or 999) else 1
            if maxw and d.textlength(t, font=f) * k > maxw:
                while t and d.textlength(t + "…", font=f) > maxw:
                    t = t[:-1]
                t += "…"
            tw = d.textlength(t, font=f)
            if center:
                x -= tw * k / 2
            if k == 1:
                d.text((round(x), y), t, font=f, fill=col)
                return
            lay = Image.new("RGBA", (int(tw) + 2, z + 4), (0, 0, 0, 0))
            ld = ImageDraw.Draw(lay)
            ld.fontmode = "1"
            ld.text((0, 0), t, font=f, fill=col)
            lay = lay.resize((lay.width * 2, lay.height * 2), Image.NEAREST)
            im.paste(lay, (round(x), y), lay)
        text(54, 7, "ИТОГИ БИТВЫ", 700, 10, "#ff9a2e")
        text(54, 19, bname, 700, 10, "#ffffff", maxw=180, big=True)
        text(54, 42, f"Чат нанёс {_fmt(tot)} урона", 400, 10, "#ffd27a", maxw=180)
        text(54, 54, f"Бойцов: {fighters}", 400, 10, "#d8ccff")
        spots = ((120, 98, "#fff3c0", 1), (48, 112, "#ffffff", 2), (192, 120, "#ffe0c0", 3))
        for cx, top_y, col, place in spots:
            row = top[place - 1] if len(top) >= place else None
            name, dmg = (row[1] or (("@" + row[2]) if row[2] else "Игрок"), row[3]) if row else ("—", None)
            text(cx, top_y - 13, name, 700, 10, "#ffffff" if place == 1 else "#e8e0ff", center=True, maxw=100 if place == 1 else 70)
            if dmg is not None:
                dm = _fmt(dmg)
                if d.textlength(dm, font=F(700, 10)) > 58:          # 12 345 678 does not fit a pedestal: 12,3 млн
                    dm = (f"{dmg / 1e9:.1f} млрд" if dmg >= 1e9 else f"{dmg / 1e6:.1f} млн").replace(".", ",")
                text(cx, top_y + 24, dm, 700, 10, col, center=True, maxw=58)
        im = im.resize((im.width * 5, im.height * 5), Image.NEAREST)
        name = "res_" + hashlib.sha256(f"{bkey}{tot}{top}{time.time()}".encode()).hexdigest()[:20] + ".jpg"
        im.save(os.path.join(CARDS, name), "JPEG", quality=95, subsampling=0)
        return WEBAPP_URL + "cards/" + name
    except Exception as e:
        log.info("results card: %s", e)
        return None

def close_event(ci):
    with db_lock:
        ev = db.execute("SELECT chat_id, closed, pin_mid FROM raid_events WHERE ci=?", (ci,)).fetchone()
        if not ev or ev[1]:
            return
        bkey = raid_boss_of(ci, -1)
        bname = RAID_BOSSES[bkey][0]
        db.execute("UPDATE raid_events SET closed=1 WHERE ci=?", (ci,))
        top = db.execute("""SELECT h.uid, p.name, p.username, h.dmg FROM raid_hits h LEFT JOIN players p ON p.id=h.uid
                            WHERE h.ci=? AND h.week=-1 AND h.dmg>0 ORDER BY h.dmg DESC LIMIT 10""", (ci,)).fetchall()
        tot = db.execute("SELECT COALESCE(SUM(dmg),0) FROM raid_hits WHERE ci=? AND week=-1", (ci,)).fetchone()[0]
        fighters = db.execute("SELECT COUNT(*) FROM raid_hits WHERE ci=? AND week=-1 AND dmg>0", (ci,)).fetchone()[0]
        db.commit()
    medal = ("🥇", "🥈", "🥉")
    lines = "\n".join((f"{medal[i]} <b>{mention(u, n, un)}</b> — <b>{d:,}</b>" if i < 3 else f"{i + 1}. {mention(u, n, un)} — {d:,}").replace(",", " ")
                      for i, (u, n, un, d) in enumerate(top)) or "—"
    if ev[2]:
        tg_try("unpinChatMessage", chat_id=ev[0], message_id=ev[2])
    if top:
        u, n, un, d = top[0]
        cap = (f"🏆 <b>Итоги битвы: {html_esc(bname)} уходит!</b>\n\n"
               f"Чемпион чата — {mention(u, n, un)}: <b>{_fmt(d)}</b> урона 👑\n"
               f"Весь чат нанёс <b>{_fmt(tot)}</b> урона, бойцов: {fighters}.\n\n{lines}\n\n"
               f"Спасибо всем за бой! Нового босса призывает админ — /boss")
    else:
        cap = f"🔥 <b>{html_esc(bname)} уходит.</b> В этот раз его никто не ударил — в следующий раз зовите всех!"
    pic = results_card(bkey, bname, tot, top, fighters) if top else None
    r = tg_try("sendPhoto", chat_id=ev[0], photo=pic or bot_card("end_" + bkey), caption=cap[:1024], parse_mode="HTML")
    if not r.get("ok"):
        tg_try("sendMessage", chat_id=ev[0], parse_mode="HTML", text=cap)

def _is_chat_admin(chat_id, uid):
    try:
        return tg("getChatMember", chat_id=chat_id, user_id=uid)["result"]["status"] in ("creator", "administrator")
    except Exception:
        return False

def _boss_btn(chat_id):
    return [{"text": "⚔️ Бить босса", "url": app_link("rg_" + str(chat_id).replace("-", "m"))}]

# pictures for the bot's messages, drawn from the game's art: public/bot/*.jpg (the ?v= makes Telegram take a new picture after a change)
BOT_CARDS_V = "4"
def bot_card(name):
    return WEBAPP_URL + "bot/" + name + ".jpg?v=" + BOT_CARDS_V

def startgroup_link():
    """Add the bot to a group, asked straight away for the right to pin (the group's admin sees the switch already on)."""
    return f"https://t.me/{BOT_USERNAME}?startgroup=boss&admin=pin_messages"

def _boss_running(ci):
    """Caller holds db_lock. Hours left of the running event, or None."""
    old = db.execute("SELECT ends, closed FROM raid_events WHERE ci=?", (ci,)).fetchone()
    if old and not old[1] and old[0] > time.time():
        return max(1, int((old[0] - time.time()) // 3600))
    return None

BOSS_HOURS = ((6, "6 ч"), (12, "12 ч"), (24, "24 ч"), (72, "3 дня"), (168, "7 дней"))

def _boss_menu(chat_id, ci):
    """The panel: who is in the chat now, or whom to call. Returns (picture, caption, keyboard)."""
    with db_lock:
        left = _boss_running(ci)
        key = raid_boss_of(ci, -1) if left else ""
    if left:
        return ("boss_" + key, f"🔥 {RAID_BOSSES[key][0]} уже в чате, осталось ~{left} ч.",
                {"inline_keyboard": [_boss_btn(chat_id), [{"text": "⛔ Закончить сейчас", "callback_data": "bs:stop"}]]})
    k = list(RAID_BOSSES)
    bt = [{"text": RAID_BOSSES[b][0], "callback_data": "bs:b:" + b} for b in k] + [{"text": "🎲 Случайный", "callback_data": "bs:b:rnd"}]
    rows = [bt[i:i + 2] for i in range(0, len(bt), 2)]
    if req_off(chat_id):
        rows.append([{"text": "🔔 Разрешить запросы игроков", "callback_data": "bs:on"}])
    return ("menu", "👹 <b>Кого призываем в чат?</b>\n\nБосс бессмертен: весь чат бьёт его наперегонки, у каждого 3 попытки в день. "
                    "В конце бот покажет лучших.\n\nПризывает админ чата. Если ты не админ — нажми на босса, и я позову админов.",
            {"inline_keyboard": rows})

def _time_rows(b):
    return [[{"text": t, "callback_data": f"bs:t:{b}:{h}"} for h, t in BOSS_HOURS[:3]],
            [{"text": t, "callback_data": f"bs:t:{b}:{h}"} for h, t in BOSS_HOURS[3:]],
            [{"text": "← Назад", "callback_data": "bs:back"}]]

_panel_mid = {}
def send_panel(chat_id, ci):
    card, cap, kb = _boss_menu(chat_id, ci)
    old = _panel_mid.pop(chat_id, None)
    if old:
        tg_try("deleteMessage", chat_id=chat_id, message_id=old)
    r = tg_try("sendPhoto", chat_id=chat_id, photo=bot_card(card), caption=cap, parse_mode="HTML", reply_markup=kb)
    if not r.get("ok"):
        r = tg_try("sendMessage", chat_id=chat_id, text=cap, parse_mode="HTML", reply_markup=kb)
    mid = (r.get("result") or {}).get("message_id")
    if mid:
        _panel_mid[chat_id] = mid

def panel_edit(chat_id, mid, card, cap, kb):
    """Turn the panel into another picture and buttons; an old text-only panel is replaced by a new one."""
    r = tg_try("editMessageMedia", chat_id=chat_id, message_id=mid, reply_markup=kb,
               media={"type": "photo", "media": bot_card(card), "caption": cap, "parse_mode": "HTML"})
    if r.get("ok") or "not modified" in str(r.get("description", "")):
        return
    tg_try("deleteMessage", chat_id=chat_id, message_id=mid)
    r = tg_try("sendPhoto", chat_id=chat_id, photo=bot_card(card), caption=cap, parse_mode="HTML", reply_markup=kb)
    if not r.get("ok"):
        tg_try("sendMessage", chat_id=chat_id, text=cap, parse_mode="HTML", reply_markup=kb)

def _can_pin(chat_id):
    try:
        m = tg("getChatMember", chat_id=chat_id, user_id=BOT_ID)["result"]
        return m.get("status") == "creator" or (m.get("status") == "administrator" and m.get("can_pin_messages"))
    except Exception:
        return False

PIN_ASK = ("📌 Чтобы все в чате получили уведомление о боссе, сделайте меня админом с правом "
           "<b>«Закреплять сообщения»</b>: настройки чата → Администраторы → еБашня. Больше ничего не нужно.")

def start_event(chat, frm, boss, hours):
    chat_id, ci = chat["id"], "g" + str(chat["id"])
    if boss not in RAID_BOSSES:
        boss = random.choice(list(RAID_BOSSES))
    with db_lock:
        if _boss_running(ci):
            return False
        db.execute("DELETE FROM raid_hits WHERE ci=? AND week=-1", (ci,))
        # (tries are per player, per chat, per day: a new boss does not give them back — calling and ending bosses is no way to farm)
        db.execute("INSERT OR REPLACE INTO raid_events(ci, chat_id, by_uid, ends, lvl, closed, title, boss, pin_mid) VALUES(?,?,?,?,?,0,?,?,NULL)",
                   (ci, chat_id, frm.get("id"), time.time() + hours * 3600, 1, (chat.get("title") or "Ивент чата")[:40], boss))
        db.commit()
    req_clear(chat_id)
    _panel_mid.pop(chat_id, None)
    dur = dict(BOSS_HOURS).get(hours, f"{hours} ч")
    cap = (f"🔥 <b>{html_esc(display_name(frm))} призывает {html_esc(RAID_BOSSES[boss][1])} на {dur}!</b>\n\n"
           f"Он бессмертен: кто набьёт больше урона? У каждого 3 попытки в день по 40 секунд, награда — сразу после каждого боя. "
           f"В конце бот покажет лучших.\n\n👇 Жми «Бить босса» — игра откроется сразу у этого босса.")
    kb = {"inline_keyboard": [_boss_btn(chat_id)]}
    r = tg_try("sendPhoto", chat_id=chat_id, photo=bot_card("boss_" + boss), caption=cap, parse_mode="HTML", reply_markup=kb)
    if not r.get("ok"):
        r = tg_try("sendMessage", chat_id=chat_id, text=cap, parse_mode="HTML", reply_markup=kb)
    mid = (r.get("result") or {}).get("message_id")
    # pinned with a notification: everyone in the chat hears that the boss has come
    if mid:
        p = tg_try("pinChatMessage", chat_id=chat_id, message_id=mid, disable_notification=False)
        if p.get("ok"):
            with db_lock:
                db.execute("UPDATE raid_events SET pin_mid=? WHERE ci=?", (mid, ci))
                db.commit()
        else:
            tg_try("sendMessage", chat_id=chat_id, text=PIN_ASK, parse_mode="HTML")
    return True

# Requests of players who are not admins. Not to turn into spam:
#  - a chat has at most one open request; another player's press only adds them to it (the message is edited, nobody is pinged again);
#  - a new request at most every 3 hours per chat, and one per player per day;
#  - the request disappears when an admin calls a boss, or after 6 hours;
#  - the admins can switch requests off with one button (and on again in the panel).
REQ_LIFE, REQ_GAP, REQ_USER_GAP = 6 * 3600, 3 * 3600, 24 * 3600
def _kv(k, v=None, delete=False):
    with db_lock:
        if delete:
            db.execute("DELETE FROM kv WHERE k=?", (k,)); db.commit(); return None
        if v is None:
            r = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
            try:
                return json.loads(r[0]) if r else None
            except ValueError:
                return None
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (k, json.dumps(v, ensure_ascii=False))); db.commit()

def req_off(chat_id):
    return bool(_kv(f"bsoff:{chat_id}"))

def req_clear(chat_id):
    """An admin answered (or the request grew old): the request message goes away."""
    q = _kv(f"bsreq:{chat_id}")
    if q:
        if q.get("mid"):
            tg_try("deleteMessage", chat_id=chat_id, message_id=q["mid"])
        _kv(f"bsreq:{chat_id}", delete=True)

def _req_caption(q):
    n = len(q["who"])
    names = ", ".join(html_esc(x) for x in q["names"][:5]) + (f" и ещё {n - 5}" if n > 5 else "")
    bname = RAID_BOSSES[q["boss"]][1] if q["boss"] in RAID_BOSSES else "босса"
    return (f"🙋 <b>Игроки просят призвать в чат {html_esc(bname)}</b>\n"
            f"Хотят: {names}" + (f" ({n})" if n > 1 else "") + "\n\n"
            f"{q.get('ping') or 'Админы'}, выберите, на сколько его позвать — или нажмите «Не просить», чтобы запросы больше не приходили.")

def ask_admins(chat_id, frm, boss):
    """A player who is not an admin pressed a boss. Returns the line for the player's pop-up."""
    if req_off(chat_id):
        return "Админы этого чата отключили запросы. Попроси их призвать босса самих."
    now, uid = time.time(), frm.get("id")
    q = _kv(f"bsreq:{chat_id}")
    if q and now - q.get("ts", 0) > REQ_LIFE:
        req_clear(chat_id); q = None
    if q:
        if uid in q["who"]:
            return "Ты уже в запросе — ждём админов."
        q["who"].append(uid); q["names"].append(display_name(frm))
        _kv(f"bsreq:{chat_id}", q)
        tg_try("editMessageCaption", chat_id=chat_id, message_id=q["mid"], caption=_req_caption(q), parse_mode="HTML",
               reply_markup=_req_kb(q["boss"]))
        return f"Добавил тебя к запросу — уже {len(q['who'])} хотят босса."
    last = _kv(f"bslast:{chat_id}") or {}
    if now - last.get("ts", 0) < REQ_GAP:
        return "Запрос в этом чате уже был недавно. Попробуй позже или попроси админа."
    if now - (last.get("u") or {}).get(str(uid), 0) < REQ_USER_GAP:
        return "Ты уже просил сегодня. Новый запрос — завтра."
    try:
        adm = [m["user"] for m in tg("getChatAdministrators", chat_id=chat_id)["result"] if not m["user"].get("is_bot")][:5]
    except Exception:
        adm = []
    q = {"boss": boss if boss in RAID_BOSSES or boss == "rnd" else "rnd", "who": [uid], "names": [display_name(frm)], "ts": now,
         "ping": " ".join(mention(a["id"], a.get("first_name") or "админ", a.get("username")) for a in adm)}
    card = "boss_" + q["boss"] if q["boss"] in RAID_BOSSES else "menu"
    r = tg_try("sendPhoto", chat_id=chat_id, photo=bot_card(card), caption=_req_caption(q), parse_mode="HTML", reply_markup=_req_kb(q["boss"]))
    if not r.get("ok"):
        r = tg_try("sendMessage", chat_id=chat_id, text=_req_caption(q), parse_mode="HTML", reply_markup=_req_kb(q["boss"]))
    q["mid"] = (r.get("result") or {}).get("message_id")
    _kv(f"bsreq:{chat_id}", q)
    us = {k: v for k, v in (last.get("u") or {}).items() if now - v < REQ_USER_GAP}
    us[str(uid)] = now
    _kv(f"bslast:{chat_id}", {"ts": now, "u": us})
    return "Призывает админ чата — я позвал админов 👇"

def _req_kb(boss):
    rows = _time_rows(boss)[:2]
    return {"inline_keyboard": rows + [[{"text": "🔕 Не просить", "callback_data": "bs:off"}]]}

_panel_at = {}
def boss_command(msg):
    """/boss in a group (or the bot's own /start boss when it is added): the panel with pictures.
    Anyone can open it; the buttons call the boss for an admin, and call the admins for anyone else.
    The old typed form still works for admins: «/boss 12 дерув», «/boss стоп»."""
    chat, frm = msg["chat"], msg.get("from") or {}
    chat_id, ci = chat["id"], "g" + str(chat["id"])
    words = [w.lower() for w in (msg.get("text") or "").split()[1:] if w.lower() not in ("boss", "raid")]
    if words and _is_chat_admin(chat_id, frm.get("id")):
        if any(w in ("стоп", "stop", "конец", "end") for w in words):
            with db_lock:
                run = db.execute("SELECT 1 FROM raid_events WHERE ci=? AND closed=0", (ci,)).fetchone()
            if run:
                close_event(ci)
                return
        else:
            hours, boss = 24, None
            for w in words:
                if w.isdigit():
                    hours = max(1, min(168, int(w)))
                else:
                    boss = next((k for k, v in RAID_BOSSES.items() if any(w.startswith(x) for x in v[2])), boss)
            if start_event(chat, frm, boss or "rnd", hours):
                return
    gap = 20 if _is_chat_admin(chat_id, frm.get("id")) else 600   # anyone may open the panel, but not flood the chat with it
    if time.time() - _panel_at.get(chat_id, 0) < gap:
        return
    _panel_at[chat_id] = time.time()
    send_panel(chat_id, ci)

def boss_callback(cq):
    """The buttons of the panel: bs:b:<boss> → the time, bs:t:<boss>:<hours> → the boss comes, bs:stop, bs:back."""
    m = cq.get("message") or {}
    chat, frm = m.get("chat") or {}, cq.get("from") or {}
    chat_id, mid, ci = chat.get("id"), m.get("message_id"), "g" + str(chat.get("id"))
    parts = (cq.get("data") or "").split(":")
    if not _is_chat_admin(chat_id, frm.get("id")):
        if parts[1] in ("b", "t"):
            line = ask_admins(chat_id, frm, parts[2] if len(parts) > 2 else "rnd")
        else:
            line = "Эта кнопка — для админов чата."
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text=line, show_alert=True)
        return
    if parts[1] == "off":
        _kv(f"bsoff:{chat_id}", 1)
        req_clear(chat_id)
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Запросы игроков отключены. Включить — в панели /boss.", show_alert=True)
        return
    if parts[1] == "on":
        _kv(f"bsoff:{chat_id}", delete=True)
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Игроки снова могут просить босса")
        card, cap, kb = _boss_menu(chat_id, ci)
        panel_edit(chat_id, mid, card, cap, kb)
        return
    if parts[1] == "b":
        b = parts[2]
        name = "Случайный босс" if b == "rnd" else RAID_BOSSES.get(b, ("?",))[0]
        tg_try("answerCallbackQuery", callback_query_id=cq["id"])
        panel_edit(chat_id, mid, "menu" if b == "rnd" else "boss_" + b, f"👹 <b>{html_esc(name)}</b>. На сколько призываем?", {"inline_keyboard": _time_rows(b)})
        return
    if parts[1] == "t":
        hours = as_int(parts[3], 1, 168)      # (before v208 this read «at least 24»: 6 and 12 hours became a day)
        ok = start_event(chat, frm, parts[2], hours)
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Босс призван!" if ok else "Босс уже в чате")
        tg_try("deleteMessage", chat_id=chat_id, message_id=mid)
        if not ok:
            send_panel(chat_id, ci)
        return
    if parts[1] == "stop":
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Босс уходит")
        tg_try("deleteMessage", chat_id=chat_id, message_id=mid)
        close_event(ci)
        return
    tg_try("answerCallbackQuery", callback_query_id=cq["id"])
    card, cap, kb = _boss_menu(chat_id, ci)
    panel_edit(chat_id, mid, card, cap, kb)

def bot_joined(msg):
    """The bot was added to a group: hello, the right to pin (so everyone hears about the boss), and the panel straight away."""
    chat_id = msg["chat"]["id"]
    text = ("Привет! Я еБашня 🔥\n\nАдмины чата могут призвать сюда общего босса — весь чат бьёт его наперегонки, "
            "а я покажу лучших. Выбирай босса прямо здесь 👇")
    if not _can_pin(chat_id):
        text += "\n\n" + PIN_ASK
    tg_try("sendMessage", chat_id=chat_id, text=text, parse_mode="HTML")
    _panel_at[chat_id] = time.time()
    send_panel(chat_id, "g" + str(chat_id))

def bot_rights(upd):
    """my_chat_member: the bot was made an admin with the right to pin — say thanks once."""
    ch, new, old = upd.get("chat") or {}, upd.get("new_chat_member") or {}, upd.get("old_chat_member") or {}
    if ch.get("type") not in ("group", "supergroup"):
        return
    could = old.get("status") == "creator" or (old.get("status") == "administrator" and old.get("can_pin_messages"))
    can = new.get("status") == "administrator" and new.get("can_pin_messages")
    if can and not could:
        tg_try("sendMessage", chat_id=ch["id"], text="📌 Спасибо! Теперь буду закреплять босса — весь чат получит уведомление, когда он придёт.")

# ---------------------------------------------------------------- admin notice shown to everyone above the room
REST_DEFAULT = 300            # v233: seconds of rest after a fight until the owner sets another value in the admin panel
def rest_seconds():
    """Caller may or may not hold db_lock: reads only."""
    r = db.execute("SELECT v FROM kv WHERE k='rest_s'").fetchone()
    try:
        return max(0, min(86400, int(r[0]))) if r else REST_DEFAULT
    except (ValueError, TypeError):
        return REST_DEFAULT

def notice_get():
    with db_lock:
        r = db.execute("SELECT v FROM kv WHERE k='notice'").fetchone()
        rest = rest_seconds()
    try:
        n = json.loads(r[0]) if r else None
    except ValueError:
        n = None
    if not n or n.get("until", 0) < time.time():
        return 200, {"text": "", "rest": rest}
    return 200, {"text": n.get("text", ""), "ts": n.get("ts", 0), "rest": rest}

def rest_cfg_set(user, body):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    try:
        sec = int(round(float(body.get("sec"))))
    except (ValueError, TypeError):
        return 400, {"ok": False, "reason": "число"}
    if not 0 <= sec <= 86400:
        return 400, {"ok": False, "reason": "от 0 до 24 ч"}
    with db_lock:
        old = rest_seconds()
        if old != sec:
            _kv_set("rest_prev", json.dumps({"s": old, "t": time.time()}))   # v257: phones not yet reloaded keep the old rest
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('rest_s', ?)", (str(sec),))
        db.commit()
    log.info("rest set by %s: %s s", user["id"], sec)
    return 200, {"ok": True, "sec": sec}

def notice_set(user, body):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    text = str(body.get("text", "")).strip()[:140]
    hours = max(0.1, min(720.0, float(body.get("hours") or 24)))
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('notice', ?)",
                   (json.dumps({"text": text, "ts": time.time(), "until": time.time() + hours * 3600}, ensure_ascii=False),))
        db.commit()
    log.info("notice set by %s: %r for %sh", user["id"], text, hours)
    return 200, {"ok": True}


# ---------------------------------------------------------------- season: an end date and prizes the owner announces
# The table is never reset: when the date passes, the three highest players win, the bot names them, and the owner starts the next season.
def _season():
    r = db.execute("SELECT v FROM kv WHERE k='season'").fetchone()
    try:
        return json.loads(r[0]) if r else None
    except ValueError:
        return None

def season_get():
    with db_lock:
        S = _season()
    if not S:
        return 200, {"season": None}
    return 200, {"season": {k: S.get(k) for k in ("n", "ends", "prizes", "note", "done", "winners")}}

SEASON_PLACES = 10

import re as _re
NFT_IMG_RE = _re.compile(r"^[a-z0-9]{2,40}-\d{1,7}$")
NFT_IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "nftimg")
_nft_lock = threading.Lock()

def nft_img(n):
    """Fragment keeps a picture of every gift at nft.fragment.com/gift/<name>-<number>.webp; we fetch it once."""
    f = os.path.join(NFT_IMG_DIR, n + ".webp")
    try:
        with open(f, "rb") as fh:
            return fh.read()
    except OSError:
        pass
    with _nft_lock:
        try:
            req = urllib.request.Request(f"https://nft.fragment.com/gift/{n}.webp", headers={"User-Agent": "Mozilla/5.0 (compatible; EmberspireBot)"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = r.read(3_000_000)
            if len(data) < 100 or data[:4] != b"RIFF":
                return None
            os.makedirs(NFT_IMG_DIR, exist_ok=True)
            with open(f + ".tmp", "wb") as fh:
                fh.write(data)
            os.replace(f + ".tmp", f)
            return data
        except Exception as e:
            log.info("nft img %s: %s", n, e)
            return None

def season_set(user, body):
    """Admin: {ends: unix seconds, prizes: [3 texts], note, new: true to start the next season}."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        S = _season() or {"n": 0}
        if body.get("new") or not S.get("n"):
            S = {"n": int(S.get("n") or 0) + 1}
        ends = float(body.get("ends") or 0)
        if ends < time.time() + 60:
            return 200, {"ok": False, "reason": "date"}
        # up to 10 prize places; a prize is a text, an NFT link (t.me/nft/…) or a picture link — the game shows those as a picture
        prizes = [str(x).strip()[:300] for x in (body.get("prizes") or [])][:SEASON_PLACES]
        while len(prizes) > 3 and not prizes[-1]:
            prizes.pop()
        S.update(ends=ends, prizes=prizes + [""] * (3 - len(prizes)), note=str(body.get("note") or "")[:140], done=False, winners=None)
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('season', ?)", (json.dumps(S, ensure_ascii=False),))
        db.commit()
    log.info("season %s set by %s until %s", S["n"], user["id"], ends)
    return 200, {"ok": True, "season": S}

def season_close():
    """The date has passed: the best take the prizes (three, or as many places as have prizes); the bot tells the groups, the winners and the owner."""
    with db_lock:
        S = _season()
        if not S or S.get("done") or not S.get("ends") or S["ends"] > time.time():
            return
        places = max(3, len(S.get("prizes") or []))
        top = db.execute("""SELECT id, name, username, room FROM players WHERE flagged=0 AND room>0
                            ORDER BY room DESC, reached ASC LIMIT ?""", (places,)).fetchall()
        S["done"] = True
        S["winners"] = [{"name": n, "room": r} for _i, n, _u, r in top]
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('season', ?)", (json.dumps(S, ensure_ascii=False),))
        chats = [r[0] for r in db.execute("SELECT DISTINCT chat_id FROM raid_events WHERE chat_id IS NOT NULL").fetchall()]
        db.commit()
    medals = ["🥇", "🥈", "🥉"] + [f"{i}." for i in range(4, 11)]
    pz = (S.get("prizes") or []) + [""] * 10
    lines = "\n".join(f"{medals[i]} {mention(u, n, un)} — этаж {r}" + (f" · {html_esc(pz[i])}" if pz[i] else "")
                      for i, (u, n, un, r) in enumerate(top)) or "—"
    text = f"🏆 Сезон {S['n']} окончен!\n\nЧемпионы башни:\n{lines}\n\nПоздравляем! Таблица остаётся — следующий сезон скоро."
    for cid in set(chats) | set(ADMIN_IDS) | ({CHANNEL} if CHANNEL else set()):
        try:
            tg("sendMessage", chat_id=cid, text=text, parse_mode="HTML")
        except Exception as e:
            log.info("season post to %s: %s", cid, e)
    for i, (u, n, un, r) in enumerate(top):
        _tell(u, f"🏆 Ты занял {i + 1} место в сезоне {S['n']} Ебашни!" + (f"\nПриз: {pz[i]}" if pz[i] else "") +
              "\nОрганизатор свяжется с тобой.", ("Войти в башню", ""))

# ---------------------------------------------------------------- cloud save
# one copy per Telegram user: the copy that has played more wins, ties go to the newer one
# ---------------------------------------------------------------- one device at a time
# Every launch of the game has its own session id. Loading the save claims the account for that launch;
# from then on only it may write the save, and the device that played before gets «the game is open elsewhere».
db.execute("CREATE TABLE IF NOT EXISTS sessions(uid INTEGER PRIMARY KEY, sid TEXT, dev TEXT, ts REAL)")
db.commit()
SESSION_LEGACY = 180    # an old copy of the game (no session id) may still write while nobody has claimed the account this long

def _clean_id(v):
    v = str(v or "")[:40]
    return v if v.replace("-", "").replace("_", "").isalnum() else ""

def _session_ok(uid, sid):
    """Caller holds db_lock. True when this launch may write the save."""
    r = db.execute("SELECT sid, ts FROM sessions WHERE uid=?", (uid,)).fetchone()
    if not sid:
        return not r or time.time() - (r[1] or 0) > SESSION_LEGACY
    return not r or r[0] == sid

def session_ping(user, body):
    sid = _clean_id(body.get("sid"))
    with db_lock:
        r = db.execute("SELECT sid FROM sessions WHERE uid=?", (user["id"],)).fetchone()
        if r and sid and r[0] != sid:
            return 200, {"ok": False, "taken": True}
        if sid:
            db.execute("INSERT OR REPLACE INTO sessions(uid, sid, dev, ts) VALUES(?,?,?,?)",
                       (user["id"], sid, _clean_id(body.get("dev")), time.time()))
            db.commit()
    return 200, {"ok": True}

def save_get(user, q=None):
    q = q or {}
    sid, dev = _clean_id((q.get("sid") or [""])[0]), _clean_id((q.get("dev") or [""])[0])
    with db_lock:
        if sid:
            # this launch takes the account over: the other device is told at its next save or ping
            db.execute("INSERT OR REPLACE INTO sessions(uid, sid, dev, ts) VALUES(?,?,?,?)", (user["id"], sid, dev, time.time()))
            db.commit()
        r = db.execute("SELECT data, score, ts FROM saves WHERE uid=?", (user["id"],)).fetchone()
        w = _wipe_of(user["id"])
        last_dev = _kv_get(f"sdev:{user['id']}", "") or ""
    out = {"wipe": w} if w else {}
    out["dev"] = last_dev
    if not r:
        return 200, out
    try:
        return 200, dict(out, save=json.loads(r[0]), score=r[1], ts=r[2])
    except ValueError:
        return 200, out

# ---------------------------------------------------------------- wipes by the owner: one player (/сброс @ник) or everyone (admin panel)
# A wipe is a mark in time (ms). Any save of an older generation is refused and the game on the phone starts over by itself.
# Stars, bought skips and the class change stay: they were paid for.
def _wipe_of(uid):
    """Caller holds db_lock. v256: one player's wipe lives in kv («wipe:<uid>», ms). In PostgreSQL players.wipe_at is a
    TIMESTAMP: the mark in milliseconds became a date tens of thousands of years ahead that can't be read back, so the
    wipe was never seen — the phone sent the old hero again and the server took him. players.wipe_at is still read for
    marks made by the old SQLite server."""
    a = db.execute("SELECT v FROM kv WHERE k='wipe_all'").fetchone()
    k = db.execute("SELECT v FROM kv WHERE k=?", (f"wipe:{uid}",)).fetchone()
    w = max(float(a[0]) if a and a[0] else 0, float(k[0]) if k and k[0] else 0)
    if not k:
        try:
            b = db.execute("SELECT wipe_at FROM players WHERE id=?", (uid,)).fetchone()
            w = max(w, float(b[0] or 0) if b else 0)
        except (TypeError, ValueError):
            pass
    return w


_WIPE_COLS = "room=0, level=1, kills=0, bosses=0, wins=0, reached=NULL"

# everything the game shows about a player goes with the wipe: raid damage and places in every chat, tries, quests,
# group rewards, duels, ghosts. Kept: stars and what was bought with them, NFT gifts, referrals, the fight log for /stats.
_WIPE_TABLES = [("raid_stats", "uid"), ("raid_hits", "uid"), ("raid_tries", "uid"), ("raid_tries_c", "uid"),
                ("quest_claims", "uid"), ("gr_claims", "uid"), ("ghost_offers", "uid")]

def _wipe_rows(uid):
    """Caller holds db_lock. uid None = everyone."""
    for t, col in _WIPE_TABLES:
        if uid is None:
            db.execute(f"DELETE FROM {t}")
        else:
            db.execute(f"DELETE FROM {t} WHERE {col}=?", (uid,))
    if uid is None:
        db.execute("DELETE FROM duels")
        db.execute("DELETE FROM raids WHERE week>=0")      # weekly chat bosses start again at full health
        db.execute("DELETE FROM kv WHERE k LIKE 'qb:%'")
    else:
        db.execute("DELETE FROM duels WHERE from_uid=? OR to_uid=?", (uid, uid))

def wipe_player(uid):
    ts = time.time() * 1000
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"wipe:{uid}", str(ts)))
        db.execute(f"UPDATE players SET {_WIPE_COLS} WHERE id=?", (uid,))
        db.execute("DELETE FROM saves WHERE uid=?", (uid,))
        db.execute("DELETE FROM kv WHERE k LIKE ?", (f"qb:{uid}:%",))
        db.execute("DELETE FROM ac_state WHERE uid=?", (uid,))
        _wipe_rows(uid)
        db.commit()
    log.warning("wipe: player %s", uid)

def wipe_all():
    ts = time.time() * 1000
    with db_lock:
        n = db.execute("SELECT COUNT(*) FROM saves").fetchone()[0]
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('wipe_all', ?)", (str(ts),))
        db.execute(f"UPDATE players SET {_WIPE_COLS}")
        db.execute("DELETE FROM saves")
        db.execute("DELETE FROM kv WHERE k LIKE 'qb:%'")
        db.execute("DELETE FROM ac_state")
        _wipe_rows(None)
        db.commit()
    log.warning("wipe: EVERYONE (%s saves)", n)
    return n

# ---------------------------------------------------------------- v238 partner program
PARTNER_GIFT = {"skips": 5, "cores": 1, "weapon": 2}   # v247: a partner's newcomer: rest skips, cores, a weapon of this rarity (2 = blue)
PARTNER_NEW_DAYS = 3                 # who may become a partner's referral: a player seen for the first time within these days
PARTNER_CODE_ABC = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

def _epoch(v):
    """first_seen is REAL in SQLite and TIMESTAMP behind the PostgreSQL adapter."""
    if v is None:
        return 0
    if hasattr(v, "timestamp"):
        return v.timestamp()
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0

def _pcode(c):
    c = str(c or "").strip().upper().replace(" ", "")
    return c if 3 <= len(c) <= 16 and all(ch.isalnum() or ch == "_" for ch in c) and c.isascii() else ""

def partner_credit(uid, n):
    """Caller holds db_lock. A referral paid n stars (n<0: a refund): his partner gets pct % of it."""
    r = db.execute("SELECT partner FROM partner_refs WHERE ref=?", (uid,)).fetchone()
    if not r:
        return
    p = db.execute("SELECT pct, active FROM partners WHERE uid=?", (r[0],)).fetchone()
    pct = (p[0] or 0) if p and p[1] else 0
    c = int(n) * int(pct)                 # n stars * pct % = hundredths of a star
    db.execute("UPDATE partner_refs SET spent=spent+?, earned_c=earned_c+? WHERE ref=?", (int(n), c, uid))
    if c:
        db.execute("UPDATE partners SET earned_c=earned_c+? WHERE uid=?", (c, r[0]))
    log.info("partner %s: referral %s paid %s, %s%% -> %+.2f", r[0], uid, n, pct, c / 100)

def partner_attach(uid, code, is_new=False):
    """A new player joins a partner by link or code. Once, for good; an old player can't be claimed."""
    code = _pcode(code)
    if not code:
        return {"ok": False, "reason": "Нет такого кода"}
    with db_lock:
        p = db.execute("SELECT uid, active FROM partners WHERE code=?", (code,)).fetchone()
        if not p or not p[1]:
            return {"ok": False, "reason": "Нет такого кода"}
        if p[0] == uid:
            return {"ok": False, "reason": "Это твой собственный код"}
        if db.execute("SELECT 1 FROM partner_refs WHERE ref=?", (uid,)).fetchone():
            return {"ok": False, "reason": "Код уже введён раньше"}
        me = db.execute("SELECT first_seen FROM players WHERE id=?", (uid,)).fetchone()
        if not is_new and (not me or time.time() - _epoch(me[0]) > PARTNER_NEW_DAYS * 86400):
            return {"ok": False, "reason": f"Код можно ввести только в первые {PARTNER_NEW_DAYS} дня игры"}
        db.execute("INSERT OR IGNORE INTO partner_refs(ref, partner, joined, spent, earned_c) VALUES(?,?,?,?,?)", (uid, p[0], int(time.time()), 0, 0))
        # v247: the newcomer gets a gift once (here: rest skips on the server balance; the core and a blue weapon come in the game)
        db.execute("UPDATE players SET skips=skips+? WHERE id=?", (PARTNER_GIFT["skips"], uid))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, 0, "partner-welcome-skips", PARTNER_GIFT["skips"], time.time()))
        _ecr_add(uid, c=PARTNER_GIFT["cores"], i=1)
        db.commit()
        nm = db.execute("SELECT name FROM players WHERE id=?", (p[0],)).fetchone()
    log.info("partner %s: new referral %s (code %s)", p[0], uid, code)
    return {"ok": True, "name": (nm[0] if nm else "") or "партнёр", "gift": dict(PARTNER_GIFT)}

def partner_attach_api(user, body):
    if not rate_ok(user["id"], "pcode"):
        return SLOW(user["id"], "pcode")
    r = partner_attach(user["id"], body.get("code"))
    return 200, r

def partner_info(user):
    uid = user["id"]
    with db_lock:
        p = db.execute("SELECT code, pct, active, earned_c, paid_c FROM partners WHERE uid=?", (uid,)).fetchone()
        mine = db.execute("SELECT partner FROM partner_refs WHERE ref=?", (uid,)).fetchone()
        me = db.execute("SELECT first_seen FROM players WHERE id=?", (uid,)).fetchone()
        out = {"ok": True, "partner": None, "joined": None,
               "can_enter": not mine and not p and bool(me) and time.time() - _epoch(me[0]) <= PARTNER_NEW_DAYS * 86400,
               "days": PARTNER_NEW_DAYS}
        if mine:
            nm = db.execute("SELECT name FROM players WHERE id=?", (mine[0],)).fetchone()
            out["joined"] = (nm[0] if nm else "") or "партнёр"
        if p and p[2]:
            n, spent = db.execute("SELECT COUNT(*), COALESCE(SUM(spent),0) FROM partner_refs WHERE partner=?", (uid,)).fetchone()
            payers = db.execute("SELECT COUNT(*) FROM partner_refs WHERE partner=? AND spent>0", (uid,)).fetchone()[0]
            top = db.execute("""SELECT pl.name, r.spent, r.earned_c, r.joined FROM partner_refs r LEFT JOIN players pl ON pl.id=r.ref
                                WHERE r.partner=? ORDER BY r.spent DESC, r.joined DESC LIMIT 30""", (uid,)).fetchall()
            out["partner"] = {"code": p[0] or "", "link": app_link("p_" + p[0]) if p[0] else "", "pct": p[1] or 0,
                              "refs": n, "payers": payers, "spent": spent, "earned": (p[3] or 0) / 100, "paid": (p[4] or 0) / 100,
                              "due": ((p[3] or 0) - (p[4] or 0)) / 100,
                              "wd": _pwd_get(uid), "wd_min": PARTNER_WD_MIN,
                              "top": [{"name": a or "Игрок", "spent": b or 0, "earned": (c or 0) / 100, "at": (d or 0) * 1000} for a, b, c, d in top]}
    return 200, out

PARTNER_PAGE = 20

def partner_refs(user, qs):
    """v269: every referral of a partner, a page at a time: ?page=0.. &sort=spent|new &q=part of the name.
    An admin may look at any partner's list with ?uid=."""
    uid = user["id"]
    if uid in ADMIN_IDS and (qs.get("uid") or [""])[0]:
        uid = as_int(qs["uid"][0], 0, 10**15)
    page = as_int((qs.get("page") or ["0"])[0], 0, 100000)
    order = "r.joined DESC" if (qs.get("sort") or [""])[0] == "new" else "r.spent DESC, r.joined DESC"
    q = str((qs.get("q") or [""])[0]).strip().lstrip("@").lower()[:32]
    with db_lock:
        p = db.execute("SELECT active FROM partners WHERE uid=?", (uid,)).fetchone()
        if not p or (not p[0] and user["id"] not in ADMIN_IDS):
            return 403, {"ok": False}
        rows = db.execute(f"""SELECT pl.name AS nm, pl.username AS un, pl.room AS rm, r.spent AS sp, r.earned_c AS ec, r.joined AS jn
                              FROM partner_refs r LEFT JOIN players pl ON pl.id=r.ref WHERE r.partner=? ORDER BY {order}""", (uid,)).fetchall()
    if q:     # matched here, not in SQL: SQLite's LOWER() leaves Cyrillic as it is
        rows = [x for x in rows if q in (x[0] or "").lower() or q in (x[1] or "").lower()]
    total = len(rows)
    rows = rows[page * PARTNER_PAGE:(page + 1) * PARTNER_PAGE]
    return 200, {"ok": True, "total": total, "page": page, "per": PARTNER_PAGE,
                 "rows": [{"name": a or (("@" + b) if b else "Игрок"), "room": c or 0, "spent": d or 0, "earned": (e or 0) / 100,
                           "at": (f or 0) * 1000} for a, b, c, d, e, f in rows]}

def partner_code(user):
    """The partner presses «Сгенерировать код»: once; after that his code and link stay the same."""
    with db_lock:
        p = db.execute("SELECT code, active FROM partners WHERE uid=?", (user["id"],)).fetchone()
        if not p or not p[1]:
            return 403, {"ok": False}
        code = p[0]
        if not code:
            for _ in range(50):
                c = "".join(random.choice(PARTNER_CODE_ABC) for _ in range(6))
                if not db.execute("SELECT 1 FROM partners WHERE code=?", (c,)).fetchone():
                    code = c
                    break
            db.execute("UPDATE partners SET code=? WHERE uid=?", (code, user["id"]))
            db.commit()
    return 200, {"ok": True, "code": code, "link": app_link("p_" + code)}

# v248: the partner presses «Вывести»: a request is noted and the owners get a message; they pay by hand and mark it (admin_partner_pay)
PARTNER_WD_MIN = 1          # stars: less than this can't be asked for
PARTNER_WD_AGAIN = 86400    # the same request reminds the owners again only after a day

def _star(c):
    v = round((c or 0) / 100, 2)
    return str(int(v)) if v == int(v) else f"{v:.2f}"

def _pwd_get(uid):
    """Caller holds db_lock. The pending withdrawal request: {"amount": stars, "at": ms} or None."""
    try:
        w = json.loads(_kv_get(f"pwd:{uid}", "") or "null")
        return {"amount": w["c"] / 100, "at": int(w["t"] * 1000)} if w else None
    except (ValueError, KeyError, TypeError):
        return None

def partner_withdraw(user):
    uid = user["id"]
    if not rate_ok(uid, "pwd"):
        return SLOW(uid, "pwd")
    now = time.time()
    with db_lock:
        p = db.execute("SELECT earned_c, paid_c, active, pct FROM partners WHERE uid=?", (uid,)).fetchone()
        if not p or not p[2]:
            return 403, {"ok": False, "reason": "Партнёрка не открыта"}
        due = (p[0] or 0) - (p[1] or 0)
        if due < PARTNER_WD_MIN * 100:
            return 200, {"ok": False, "reason": f"Вывести можно от {PARTNER_WD_MIN} ⭐"}
        try:
            old = json.loads(_kv_get(f"pwd:{uid}", "") or "null")
        except ValueError:
            old = None
        if old and old.get("c") == due and now - old.get("t", 0) < PARTNER_WD_AGAIN:
            return 200, {"ok": True, "wd": _pwd_get(uid), "already": 1}
        _kv_set(f"pwd:{uid}", json.dumps({"c": due, "t": now}))
        pl = db.execute("SELECT name, username FROM players WHERE id=?", (uid,)).fetchone()
        n, spent = db.execute("SELECT COUNT(*), COALESCE(SUM(spent),0) FROM partner_refs WHERE partner=?", (uid,)).fetchone()
        db.commit()
        wd = _pwd_get(uid)
    name, un = (pl[0] if pl else "") or "Партнёр", (pl[1] if pl else "") or ""
    txt = (f"💸 Партнёр {name}{' @' + un if un else ''} (id {uid}) хочет вывести {_star(due)} ⭐\n\n"
           f"Процент: {p[3] or 0}% · рефералов: {n} · они потратили: {spent} ⭐\n"
           f"Заработано: {_star(p[0])} ⭐ · выплачено: {_star(p[1])} ⭐\n\n"
           "После выплаты отметь её: игра → ⚙ Меню → Партнёры → «Отметить выплату».")
    def send():
        for a in ADMIN_IDS:
            try:
                tg("sendMessage", chat_id=a, text=txt)
            except Exception as e:
                log.info("partner withdraw notice: %s", e)
    threading.Thread(target=send, daemon=True).start()
    log.info("partner %s asks to withdraw %s", uid, _star(due))
    return 200, {"ok": True, "wd": wd}

def admin_partners(user):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        rows = db.execute("""SELECT p.uid, pl.name, pl.username, p.code, p.pct, p.active, p.earned_c, p.paid_c, p.gave FROM partners p
                             LEFT JOIN players pl ON pl.id=p.uid ORDER BY p.active DESC, p.earned_c DESC""").fetchall()
        res = []
        for uid, name, un, code, pct, act, ec, pc, gave in rows:
            n, spent = db.execute("SELECT COUNT(*), COALESCE(SUM(spent),0) FROM partner_refs WHERE partner=?", (uid,)).fetchone()
            res.append({"id": uid, "name": name or "", "username": un or "", "code": code or "", "pct": pct or 0, "active": bool(act),
                        "refs": n, "spent": spent, "earned": (ec or 0) / 100, "paid": (pc or 0) / 100, "due": ((ec or 0) - (pc or 0)) / 100,
                        "gave": (gave or 0) * 1000, "wd": _pwd_get(uid)})
    return 200, {"ok": True, "list": res}

def admin_partner_set(user, body):
    """Grant the partner program to a player, change his percent, his code, or switch it off (active=0)."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        r = find_player(body.get("who"))
        if not r:
            return 404, {"ok": False, "reason": "Игрок не найден (id или @ник; он должен хоть раз открыть игру)"}
        uid = r[0]
        cur = db.execute("SELECT pct, active, code FROM partners WHERE uid=?", (uid,)).fetchone()
        pct = as_int(body.get("pct"), 0, 100) if body.get("pct") is not None else (cur[0] if cur else 10)
        act = (1 if body.get("active") else 0) if body.get("active") is not None else (cur[1] if cur else 1)
        code = cur[2] if cur else ""
        if body.get("code"):
            c = _pcode(body.get("code"))
            if not c:
                return 400, {"ok": False, "reason": "Код: 3–16 латинских букв/цифр"}
            o = db.execute("SELECT uid FROM partners WHERE code=?", (c,)).fetchone()
            if o and o[0] != uid:
                return 400, {"ok": False, "reason": "Такой код уже у другого партнёра"}
            code = c
        if body.get("code_del"):
            code = ""        # v255: the old link and code stop working; his referrals stay his; he can make a new code
        if cur:
            db.execute("UPDATE partners SET pct=?, active=?, code=? WHERE uid=?", (pct, act, code, uid))
        else:
            db.execute("INSERT INTO partners(uid, code, pct, active, gave, earned_c, paid_c) VALUES(?,?,?,?,?,?,?)",
                       (uid, code, pct, act, int(time.time()), 0, 0))
        db.commit()
    log.info("admin %s: partner %s pct=%s active=%s code=%s", user["id"], uid, pct, act, code)
    return 200, {"ok": True, "id": uid, "pct": pct, "active": bool(act), "code": code}

def admin_partner_pay(user, body):
    """Owners paid a partner by hand: note it, the «к выплате» goes down."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    try:
        amt = round(float(str(body.get("amount")).replace(",", ".")) * 100)
    except (TypeError, ValueError):
        return 400, {"ok": False, "reason": "Сумма"}
    if not -10**9 < amt < 10**9 or not amt:
        return 400, {"ok": False, "reason": "Сумма"}
    with db_lock:
        r = find_player(body.get("who"))
        if not r or not db.execute("SELECT 1 FROM partners WHERE uid=?", (r[0],)).fetchone():
            return 404, {"ok": False, "reason": "Это не партнёр"}
        db.execute("UPDATE partners SET paid_c=paid_c+? WHERE uid=?", (amt, r[0]))
        db.execute("INSERT INTO partner_pays(uid, amount_c, at_t, by_uid) VALUES(?,?,?,?)", (r[0], amt, int(time.time()), user["id"]))
        db.execute("DELETE FROM kv WHERE k=?", (f"pwd:{r[0]}",))          # v248: a payment answers his withdrawal request
        e = db.execute("SELECT earned_c, paid_c FROM partners WHERE uid=?", (r[0],)).fetchone()
        if amt > 0:
            _tell(r[0], f"💸 Админы отметили выплату партнёрки: {_star(amt)} ⭐. К выплате осталось: {_star((e[0] or 0) - (e[1] or 0))} ⭐.")
        db.commit()
    log.info("admin %s: partner %s paid %+.2f", user["id"], r[0], amt / 100)
    return 200, {"ok": True}

def find_player(q):
    """@username, username or a numeric id. Caller holds db_lock."""
    q = str(q or "").strip().lstrip("@")
    if not q:
        return None
    if q.isdigit():
        r = db.execute("SELECT id, name, username, room, level FROM players WHERE id=?", (int(q),)).fetchone()
        if r:
            return r
    return db.execute("SELECT id, name, username, room, level FROM players WHERE lower(username)=lower(?)", (q,)).fetchone()

def admin_wipe(user, body):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    if body.get("all"):
        if str(body.get("confirm") or "").strip().upper() != "СБРОС":
            return 400, {"ok": False, "reason": "confirm"}
        return 200, {"ok": True, "n": wipe_all()}
    with db_lock:
        r = find_player(body.get("who"))
    if not r:
        return 404, {"ok": False, "reason": "not found"}
    wipe_player(r[0])
    return 200, {"ok": True, "name": r[1], "username": r[2], "room": r[3]}

def admin_player(user, qs):
    """v219 admin panel: one player's card by @nick or id."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        r = find_player((qs.get("who") or [""])[0])
        if not r:
            return 404, {"ok": False, "reason": "not found"}
        uid = r[0]
        x = db.execute("SELECT name, username, cls, room, level, stars, skips, seen, first_seen, flagged FROM players WHERE id=?", (uid,)).fetchone()
        given = db.execute("SELECT COALESCE(SUM(n),0) FROM star_ledger WHERE uid=? AND what='admin-skips'", (uid,)).fetchone()[0]
        bought = db.execute("SELECT COALESCE(SUM(n),0) FROM star_ledger WHERE uid=? AND what='skips'", (uid,)).fetchone()[0]
        # v250: the full picture for the owners: the hero as the server holds him, real payments, where stars went, raids, anti-cheat
        sv = _save_of(uid)
        pays = db.execute("SELECT n, ts, refunded FROM star_pay WHERE uid=?", (uid,)).fetchall()
        # the adapter returns rows as dicts (RealDictCursor) and turns them into tuples by values():
        # without aliases every COALESCE would be named "coalesce" and overwrite the others, leaving fewer columns
        led = db.execute("SELECT what, COALESCE(SUM(delta),0) AS delta_sum, COALESCE(SUM(n),0) AS n_sum, COUNT(*) AS cnt FROM star_ledger WHERE uid=? GROUP BY what", (uid,)).fetchall()
        rd = db.execute("SELECT COALESCE(SUM(dmg),0) AS dmg_sum, COALESCE(MAX(best),0) AS best_max, COALESCE(SUM(hits),0) AS hits_sum, COUNT(*) AS cnt FROM raid_stats WHERE uid=?", (uid,)).fetchone()
        ac = db.execute("SELECT status, reasons FROM ac_flags WHERE uid=?", (uid,)).fetchone()
        pr = db.execute("SELECT pl.name, pl.username FROM partner_refs r LEFT JOIN players pl ON pl.id=r.partner WHERE r.ref=?", (uid,)).fetchone()
        sv_at = db.execute("SELECT ts FROM saves WHERE uid=?", (uid,)).fetchone()
    paid = [(as_int(n, 0, 10**9), _epoch(t), bool(rf)) for n, t, rf in pays]
    try:
        acr = json.loads(ac[1]) if ac and ac[1] else []
    except ValueError:
        acr = []
    return 200, {"ok": True, "p": {"id": uid, "name": x[0], "username": x[1], "cls": x[2], "room": x[3], "level": x[4], "stars": x[5] or 0,
                                   "skips": x[6] or 0, "seen": x[7] or 0, "first": x[8] or 0, "flagged": x[9] or 0,
                                   "given": given, "bought": bought,
                                   "save": sv, "save_at": (lambda t: t / 1000 if t > 1e11 else t)(_epoch(sv_at[0])) if sv_at else 0,
                                   "paid": {"stars": sum(n for n, t, rf in paid if not rf), "count": sum(1 for n, t, rf in paid if not rf),
                                            "refunded": sum(n for n, t, rf in paid if rf), "last": max([t for n, t, rf in paid] or [0])},
                                   "ledger": [{"what": w, "delta": as_int(d, -10**12, 10**12), "n": as_int(n, -10**12, 10**12), "times": c} for w, d, n, c in led],
                                   "raid": {"dmg": rd[0] or 0, "best": rd[1] or 0, "hits": rd[2] or 0, "chats": rd[3] or 0},
                                   "ac": {"status": ac[0], "reasons": acr} if ac else None,
                                   "partner": ((pr[0] or "") + (" @" + pr[1] if pr[1] else "")).strip() if pr else None}}

def admin_skips(user, body):
    """v219 admin panel: give (or take back, n<0) rest skips; the player may be told in the bot."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    n = as_int(body.get("n"), -100000, 100000)
    if not n:
        return 400, {"ok": False, "reason": "n"}
    with db_lock:
        r = find_player(body.get("who"))
        if not r:
            return 404, {"ok": False, "reason": "not found"}
        uid = r[0]
        db.execute("UPDATE players SET skips=MAX(0, skips+?) WHERE id=?", (n, uid))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, 0, "admin-skips", n, time.time()))
        db.commit()
        left = db.execute("SELECT skips FROM players WHERE id=?", (uid,)).fetchone()[0]
    log.info("admin %s: skips %+d to %s", user["id"], n, uid)
    if body.get("tell") and n > 0:
        try:
            tg("sendMessage", chat_id=uid, text=f"🎁 Тебе начислено пропусков отдыха: {n}. Теперь их {left} — герой может драться без отдыха.",
               reply_markup={"inline_keyboard": [[{"text": "Войти в башню", "web_app": {"url": WEBAPP_URL}}]]})
        except Exception as e:
            log.info("skips note to %s not sent: %s", uid, e)
    return 200, {"ok": True, "skips": left, "n": n, "name": r[1], "username": r[2]}

def wipe_command(msg):
    """/сброс @ник (or id): the owner sees who it is and confirms with a button."""
    chat = msg["chat"]["id"]
    if (msg.get("from") or {}).get("id") not in ADMIN_IDS:
        return
    arg = (msg.get("text") or "").split(maxsplit=1)
    if len(arg) < 2:
        tg_try("sendMessage", chat_id=chat, text="Напиши так: /сброс @ник или /сброс 123456789 (id игрока).\nСбросить всех — кнопкой в админке игры.")
        return
    with db_lock:
        r = find_player(arg[1])
    if not r:
        tg_try("sendMessage", chat_id=chat, text=f"Игрок {arg[1]} не найден. Ник ищется только у тех, кто хоть раз открывал игру; можно указать id.")
        return
    uid, name, un, room, lvl = r
    tg_try("sendMessage", chat_id=chat, parse_mode="HTML",
           text=f"Сбросить прогресс {mention(uid, name, un)} ({html_esc(name or '')}, id {uid})?\nСейчас: этаж {room}, уровень {lvl}.\n\nГерой, вещи и этажи пропадут, из топа он уйдёт. Звёзды и пропуски останутся.",
           reply_markup={"inline_keyboard": [[{"text": "Сбросить", "callback_data": f"wp:go:{uid}"}, {"text": "Отмена", "callback_data": f"wp:no:{uid}"}]]})

def wipe_callback(cq):
    me = (cq.get("from") or {}).get("id")
    m = cq.get("message") or {}
    chat, mid = m.get("chat", {}).get("id"), m.get("message_id")
    if me not in ADMIN_IDS:
        tg_try("answerCallbackQuery", callback_query_id=cq["id"])
        return
    _, act, uid = (cq.get("data") or "").split(":", 2)
    if act != "go":
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Отменено")
        tg_try("editMessageText", chat_id=chat, message_id=mid, text="Сброс отменён.")
        return
    wipe_player(int(uid))
    tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Сброшено")
    tg_try("editMessageText", chat_id=chat, message_id=mid, text=f"Готово: прогресс игрока id {uid} сброшен. При следующем входе (или в течение пары секунд, если он сейчас в игре) он начнёт с первого этажа.")

def _save_gen(d):
    try:
        if isinstance(d, str):
            d = json.loads(d)
        g = float(d.get("gen") or 0)
        return min(g, time.time() * 1000 + 60000)
    except Exception:
        return 0

def _restart_hero(uid, new, old_raw):
    """A «Новая игра»: the tower records follow the new hero (the leaderboard and the podium drop the old floor),
    and today's quests keep the fights already won today. Caller holds db_lock."""
    st = new.get("st") or {}
    room = as_int(new.get("maxCleared"), 0, 10**7)
    db.execute("""UPDATE players SET room=?, level=?, kills=?, bosses=?, wins=?, cls=?, reached=?, updated=? WHERE id=?""",
               (room, as_int(new.get("level"), 1, 10000), as_int(st.get("kills")), as_int(st.get("bosses")), as_int(st.get("wins")),
                str(new.get("cls") or "")[:20], time.time(), time.time(), uid))
    try:
        old = json.loads(old_raw) if old_raw else {}
    except Exception:
        old = {}
    k = f"qb:{uid}:{q_day()}"
    r = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    if r:
        done_today = max(0, as_int((old.get("st") or {}).get("wins"), 0, 10**9) - as_int(r[0], -10**9))
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (k, str(as_int(st.get("wins"), 0, 10**9) - done_today)))
    db.execute("DELETE FROM ac_state WHERE uid=?", (uid,))
    log.info("hero restarted by %s: floor %s", uid, room)

# ---- v251 economy check: wealth can't grow faster than it can be earned
# wealth = gold + what the bag would sell for (crafting turns gold into things worth less, selling turns things into the same gold,
# so neither raises it). Between two saves it may grow by: the fights fought (each at most a boss's gold and a legendary item of
# the floor), what the server itself paid (chat bosses, group bosses, duels, quests, the wheel of luck, gifts — counted in
# ecr:<uid>) and a margin per hour for small things the phone pays alone (the daily wheel, chests). Cores likewise.
ECO_SLACK_H = 10        # fights' worth of wealth per hour of real time on top
ECO_HARD_X = 6          # this many times the allowance (and at least ECO_HARD_MIN fights' worth) is refused outright
ECO_HARD_MIN = 25
_RVAL = (1, 2, 4, 8, 16)

def _ecr_add(uid, g=0, c=0, i=0, u=0):
    """Caller holds db_lock. Gold, cores, items and «gold units» of the wheel the server handed out, each with its time:
    a check counts what was paid from an hour before the previous save on, so a payment the phone books a save later
    is never missed (counting one twice only makes the check kinder)."""
    try:
        e = json.loads(_kv_get(f"ecr:{uid}", "") or "[]")
    except ValueError:
        e = []
    if not isinstance(e, list):
        e = []
    now = time.time()
    e = [x for x in e if isinstance(x, list) and len(x) == 5 and now - x[0] < 2 * 86400][-400:]
    e.append([now, max(0, int(g or 0)), max(0, int(c or 0)), max(0, int(i or 0)), max(0, int(u or 0))])
    _kv_set(f"ecr:{uid}", json.dumps(e))

def _ecr_since(uid, t0):
    try:
        e = json.loads(_kv_get(f"ecr:{uid}", "") or "[]")
    except ValueError:
        e = []
    tot = [0, 0, 0, 0]
    for x in e if isinstance(e, list) else []:
        if isinstance(x, list) and len(x) == 5 and x[0] >= t0:
            for k in range(4):
                tot[k] += x[k + 1]
    return tot

def _eco_of(sv):
    inv = sv.get("inv") if isinstance(sv.get("inv"), list) else []
    w = 0
    for it in inv:
        if isinstance(it, dict):
            try:
                w += round((3 + float(it.get("ilvl") or 0) * 1.25) * _RVAL[max(0, min(4, int(it.get("rarity") or 0)))])
            except (TypeError, ValueError):
                pass
    mats = sv.get("mats") if isinstance(sv.get("mats"), dict) else {}
    st = sv.get("st") if isinstance(sv.get("st"), dict) else {}
    uids = [as_int(it.get("uid"), 0, 10**12) for it in inv if isinstance(it, dict)]
    return {"w": as_int(sv.get("gold"), -10**15, 10**15) + w, "c": as_int(mats.get("core"), 0, 10**12), "n": len(uids),
            "mu": max(uids or [0]), "f": as_int(st.get("wins"), 0, 10**9) + as_int(st.get("losses"), 0, 10**9),
            "room": as_int(sv.get("maxCleared"), 0, 10**6)}

def _eco_check(uid, old, new):
    """Caller holds db_lock. Returns (hard message | None, soft message | None) for one save following another."""
    now = time.time()
    try:
        prev = json.loads(_kv_get(f"eco:{uid}", "") or "null")
    except ValueError:
        prev = None
    a, b = _eco_of(old), _eco_of(new)
    snap = {"t": now}
    # the very first look, and an old game turning its long-gone local stars into cores once: nothing to compare
    if new.get("starsMig") and not old.get("starsMig"):
        _kv_set(f"eco:{uid}", json.dumps(snap))
        return None, None
    if not isinstance(prev, dict):
        prev = {"t": now - 3600}         # the first look at this player: as if his last save were an hour ago
    dt = max(0.0, now - (prev.get("t") or now))
    dg, dc, di, du = _ecr_since(uid, (prev.get("t") or now) - 3600)
    room = max(a["room"], b["room"]) + 1
    # the very best one fight can bring, everything lucky at once: a boss's gold on the best room type (×1.5) with +300% gold
    # from gear, doubled by the «×2» of the wheel after it; a legendary dropping from the fight and another from the wheel
    gold_f = (8 + room * 3.2) * 0.65 * 1.15 * 4 * 1.5 * 4 * 2
    item_f = (3 + (room + 5) * 1.25) * 16
    per = gold_f + 2 * item_f
    # fights as the save counts them, not limited by the time since the last save: a phone that played offline brings them all
    # at once. Wins written in by hand are the anti-cheat's «+N побед за M мин» rule's business.
    fights = max(0, b["f"] - a["f"])
    allow_w = (fights + 3) * per + dg + di * item_f * 1.3 + du * gold_f + dt / 3600 * ECO_SLACK_H * per
    gained = b["w"] - a["w"]
    new_items = 0
    if isinstance(new.get("inv"), list):
        new_items = sum(1 for it in new["inv"] if isinstance(it, dict) and as_int(it.get("uid"), 0, 10**12) > a["mu"])
    removed = max(0, a["n"] - (b["n"] - new_items))
    allow_c = (fights + 3) * 7 + dc + removed * 3 + dt / 3600 * 20 + 20      # a floor boss gives up to 6
    gc = b["c"] - a["c"]
    _kv_set(f"eco:{uid}", json.dumps(snap))
    def fmt(v):
        return f"{int(v):,}".replace(",", " ")
    span = _ac_dur(dt) if dt >= 1 else "мгновенно"
    # the allowance already assumes every fight was the luckiest possible; only many times more than that is refused.
    # Anything in between is only written to the log: an honest player is never refused or put on the anti-cheat list for it.
    if gained > allow_w:
        msg = f"богатство +{fmt(gained)} за {span} ({fights:.0f} боёв), можно до {fmt(allow_w)}"
        if gained > ECO_HARD_X * allow_w and gained > ECO_HARD_MIN * per:
            return msg, None
        return None, msg
    if gc > allow_c:
        msg = f"ядер +{fmt(gc)} за {span}, можно до {fmt(allow_c)}"
        if gc > ECO_HARD_X * allow_c and gc > 200:
            return msg, None
        return None, msg
    return None, None

# ---- v257 pace check: wins, floors and levels can't grow faster than fights can be fought
# A fight is followed by rest (rest_seconds() from level 20, from 60 s below — v247) unless a rest skip is spent, and every
# skip is spent on the server (star_ledger «skip-used»). So between two saves the fights (wins + losses) are at most
# time / rest + skips spent; the wheel's rare «Сброс отдыха» (1 in 100) and clocks are covered by ×1.5 and +10 on top.
# A floor needs a won fight, so floors are held by the same count (the save check keeps the record within wins + 5).
PACE_X, PACE_PLUS = 1.5, 10

def _rest_floor_s(level):
    """The shortest rest the game could have used lately for a hero of this level (seconds): today's setting, or the one
    before it if the owner changed it within a day — a phone that has not reloaded still uses the old one."""
    cfg = rest_seconds()
    try:
        prev = json.loads(_kv_get("rest_prev", "null") or "null")
        if prev and time.time() - prev.get("t", 0) < 86400:
            cfg = min(cfg, int(prev.get("s", cfg)))
    except (ValueError, TypeError):
        pass
    lo = min(60, cfg)
    step = max(0, min(8, (max(1, level) - 1) * 8 // 19))
    return lo + (cfg - lo) * step / 8

def _pace_check(uid, old, new, old_ts):
    """Caller holds db_lock. A refusal message, or None."""
    now = time.time()
    try:
        prev = json.loads(_kv_get(f"pace:{uid}", "null") or "null")
    except ValueError:
        prev = None
    _kv_set(f"pace:{uid}", json.dumps({"t": now}))
    t0 = prev.get("t") if isinstance(prev, dict) else None
    if not t0:
        # the first look: from the time the previous save was made (at least an hour back, at most a month)
        ot = (old_ts or 0) / 1000 if (old_ts or 0) > 1e11 else (old_ts or 0)
        t0 = now - max(3600, min(30 * 86400, now - ot if ot else 3600))
    dt = max(0.0, now - t0)
    a, b = _eco_of(old), _eco_of(new)
    lv = as_int(old.get("level"), 1, 10**6)
    rest = _rest_floor_s(lv)
    if rest < 20:
        return None                     # the owner turned rest (almost) off: nothing to hold the pace by
    used = db.execute("SELECT COALESCE(SUM(n),0) AS used FROM star_ledger WHERE uid=? AND what='skip-used' AND ts>?",
                      (uid, t0 - 120)).fetchone()[0] or 0
    allow = dt / rest * PACE_X + int(used) + PACE_PLUS
    fights = b["f"] - a["f"]
    floors = b["room"] - a["room"]
    levels = as_int(new.get("level"), 1, 10**6) - lv
    def span():
        return ("за " + _ac_dur(dt)) if dt >= 1 else "мгновенно"
    if fights > allow:
        return f"боёв +{fights} {span()}, можно не больше {int(allow)}"
    if floors > allow + 5:
        return f"этажей +{floors} {span()}, можно не больше {int(allow) + 5}"
    if levels > allow * 5 + 5:
        return f"уровней +{levels} {span()}"
    return None

_eco_soft = {}        # uid -> why the server refused his save; the anti-cheat check puts it on the list
REFUSE_TELL_GAP = 3600   # the owners hear about one player's refused saves at most once an hour

def _refused(uid, why):
    """Caller holds db_lock. A save was refused: the anti-cheat list gets the player with the reason, the owners get a message."""
    _eco_soft[uid] = "сервер не принял сохранение: " + why
    _kv_set(f"refused:{uid}", json.dumps({"t": time.time(), "why": why}, ensure_ascii=False))   # v257: for good (friend rewards)
    now = time.time()
    k = f"acn:{uid}"
    try:
        last = float(_kv_get(k, "0") or 0)
    except ValueError:
        last = 0
    if now - last < REFUSE_TELL_GAP:
        return
    _kv_set(k, str(now))
    pl = db.execute("SELECT name, username FROM players WHERE id=?", (uid,)).fetchone()
    name, un = (pl[0] if pl else "") or "Игрок", (pl[1] if pl else "") or ""
    txt = (f"🛡 Сервер не принял сохранение\n{name}{' @' + un if un else ''} (id {uid}): {why}.\n\n"
           "Герой возвращён к последнему честному сохранению, игрок записан в Анти-чит (⚙ Меню → Анти-чит).")
    def send():
        for a in ADMIN_IDS:
            try:
                tg("sendMessage", chat_id=a, text=txt)
            except Exception as e:
                log.info("refused-save notice: %s", e)
    threading.Thread(target=send, daemon=True).start()

def _save_impossible(d):
    """v246: a save no honest game can make is refused outright, not only reported. Only rules without exceptions:
    one skill point per level (skills + mastery), and every floor is a won fight (the game itself keeps the record
    at most at its wins since v224; 5 of slack for very old saves). Returns why, or None."""
    try:
        lv = int(d.get("level") or 1)
        sk = d.get("skills") or {}
        spent = sum(int(v) for v in sk.values() if isinstance(v, (int, float)) and v > 0) if isinstance(sk, dict) else 0
        if spent > lv:
            return f"навыков вложено {spent} при уровне {lv}"
        st = d.get("st") or {}
        floor, wins = int(d.get("maxCleared") or 0), int((st.get("wins") if isinstance(st, dict) else 0) or 0)
        if floor > wins + 5:
            return f"рекорд {floor} при {wins} победах"
    except (TypeError, ValueError):
        return "сохранение не читается"
    return None

def save_put(user, body):
    data = body.get("save")
    if not isinstance(data, dict):
        return 400, {"ok": False}
    raw = json.dumps(data, ensure_ascii=False)
    try:
        score = float(body.get("score") or 0)
        ts = min(float(body.get("ts") or 0), time.time() * 1000 + 60000)
    except (ValueError, TypeError):
        return 400, {"ok": False}
    sid, dev = _clean_id(body.get("sid")), _clean_id(body.get("dev"))
    with db_lock:
        if not _session_ok(user["id"], sid):
            return 200, {"ok": 0, "taken": True}
        _qbase(user["id"]); _qbase_f(user["id"], "ekills"); _qbase_f(user["id"], "bkills")          # today's starting point for the daily quests, taken from the save before it changes
        cur = db.execute("SELECT score, ts, data FROM saves WHERE uid=?", (user["id"],)).fetchone()
        # «Новая игра» starts a new generation of the hero: a newer generation replaces the old save whatever its score,
        # and an older one (a phone that still holds the hero from before the restart) can no longer overwrite it
        gen = _save_gen(data)
        cur_gen = _save_gen(cur[2]) if cur else 0
        w = _wipe_of(user["id"])
        if w and gen < w:
            return 200, {"ok": 0, "wipe": w}
        if cur and gen < cur_gen:
            return 200, {"ok": 0, "score": cur[0], "gen": cur_gen}
        if cur and gen == cur_gen and (cur[0] > score or (cur[0] == score and cur[1] > ts)):
            return 200, {"ok": 0, "score": cur[0]}
        bad = _save_impossible(data)
        if bad:
            log.warning("save refused for %s: %s", user["id"], bad)
            _refused(user["id"], bad)
            db.commit()
            ac_enqueue(user["id"], time.time())          # the anti-cheat list gets him too
            # the copy the server holds is no better (saved before this rule): there is nothing honest to go back to
            srv_bad = bool(cur and _save_impossible(json.loads(cur[2]) if isinstance(cur[2], str) else {}))
            return 200, {"ok": 0, "bad": bad, "stuck": 1 if srv_bad else 0}
        if cur and gen == cur_gen:
            try:
                old = json.loads(cur[2]) if isinstance(cur[2], str) else None
            except ValueError:
                old = None
            if isinstance(old, dict):
                hard, soft = _eco_check(user["id"], old, data)
                if hard:
                    db.commit()
                    log.warning("save refused for %s: %s", user["id"], hard)
                    _refused(user["id"], hard)
                    db.commit()
                    ac_enqueue(user["id"], time.time())
                    return 200, {"ok": 0, "bad": hard, "stuck": 0}
                if soft:
                    log.info("economy (only noted): %s %s", user["id"], soft)
                fast = _pace_check(user["id"], old, data, cur[1])
                if fast:
                    log.warning("save refused for %s: %s", user["id"], fast)
                    _refused(user["id"], fast)
                    db.commit()
                    ac_enqueue(user["id"], time.time())
                    return 200, {"ok": 0, "bad": fast, "stuck": 0}
        if cur and gen > cur_gen:
            _restart_hero(user["id"], data, cur[2])
        db.execute("INSERT OR REPLACE INTO saves(uid, data, score, ts) VALUES(?,?,?,?)", (user["id"], raw, score, ts))
        # v222: the top shows the class the hero plays now — a class change without a new record used to leave the old one there
        nc = str(data.get("cls") or "")
        if nc in CLS_RU:
            pc = db.execute("SELECT cls FROM players WHERE id=?", (user["id"],)).fetchone()
            if pc and _cls_key(pc[0] or "") != nc:
                db.execute("UPDATE players SET cls=? WHERE id=?", (CLS_RU[nc], user["id"]))
        if dev:
            _kv_set(f"sdev:{user['id']}", dev)       # which device wrote last: another device starting up takes this save as it is
        if sid:
            db.execute("UPDATE sessions SET ts=? WHERE uid=? AND sid=?", (time.time(), user["id"], sid))
        if not cur:
            _qbase(user["id"]); _qbase_f(user["id"], "ekills"); _qbase_f(user["id"], "bkills")      # the very first save: today's quests count from it
        db.commit()
    ac_enqueue(user["id"], time.time())
    return 200, {"ok": 1}

# ---------------------------------------------------------------- reminders
def notify_set(user, body):
    on = 1 if body.get("on") else 0
    with db_lock:
        db.execute("UPDATE players SET notify=?, notify_off=?, can_pm=CASE WHEN ?=1 THEN 1 ELSE can_pm END WHERE id=?", (on, 1 - on, on, user["id"]))
        db.commit()
    return 200, {"ok": True}

def rest_set(user, body):
    at = as_int(body.get("at"), 0, 10**14) / 1000.0
    with db_lock:
        now = time.time()
        db.execute("UPDATE players SET rest_at=? WHERE id=?", (max(at, now) if now - 120 < at < now + 86400 else 0, user["id"]))
        db.commit()
    return 200, {"ok": True}

def reminder_loop():
    while True:
        time.sleep(15)
        now = time.time()
        try:
            with db_lock:
                # only those away for a while, at most once per REMIND_EVERY; the game reports rest_at whenever it is closed
                # rest_at / reminded are TIMESTAMP columns: the numeric bounds go through the adapter's to_timestamp() wrapper,
                # so they must be bound parameters (rest_at>? with 0), not literals — "rest_at>0" is invalid in PostgreSQL.
                # v255: only rest_at is compared in SQL; seen and reminded are checked here. In PostgreSQL they are TIMESTAMP
                # columns that may be NULL (a player made by the bot's migration has no «reminded» yet), and «NULL < x» is
                # never true there — such players were never reminded.
                rows = db.execute("""SELECT id, room, seen, reminded FROM players WHERE notify=1 AND can_pm=1 AND rest_at>? AND rest_at<=?""",
                                  (0, now)).fetchall()
                due = [(uid, room) for uid, room, seen, rem in rows
                       if (_epoch(seen) or 0) <= now - REMIND_AWAY and (_epoch(rem) or 0) < now - REMIND_EVERY]
                for (uid, _r) in due:
                    db.execute("UPDATE players SET reminded=?, rest_at=? WHERE id=?", (now, 0, uid))
                db.commit()
            for (uid, room) in due:
                try:
                    tg("sendMessage", chat_id=uid, text="⚔️ Герой отдохнул и готов к бою!" + (f" Комната {room + 1} ждёт." if room else " Башня ждёт!"),
                       reply_markup={"inline_keyboard": [[{"text": "Войти в башню", "web_app": {"url": WEBAPP_URL}}]]})
                except Exception as e:
                    log.info("reminder to %s not sent: %s", uid, e)
        except Exception as e:
            log.warning("reminder loop: %s", e)

def share_photo_file_id(uid, jpeg):
    """Put the JPEG on Telegram's servers and return file_id. sendPhoto by URL often yields a black
    placeholder because Telegram cannot fetch WEBAPP_URL/cards/ (localhost, HTTP, or a proxy that
    only serves the Mini App). file_id does not need a public URL. The bot-chat copy is deleted."""
    r = tg_multipart("sendPhoto", {"photo": ("card.jpg", jpeg, "image/jpeg")},
                     chat_id=uid, disable_notification=True)
    if not r.get("ok"):
        log.warning("share upload sendPhoto not ok: %s", r)
        return None
    msg = r.get("result") or {}
    sizes = msg.get("photo") or []
    fid = sizes[-1].get("file_id") if sizes else None
    mid = msg.get("message_id")
    if mid:
        d = tg_try("deleteMessage", chat_id=uid, message_id=mid)
        if not d.get("ok"):
            log.info("share upload delete: %s", d)
    return fid

# ---------------------------------------------------------------- challenge card shared to a chat
def _card_k(im):
    """The game draws a chat card on a small pixel grid; it is enlarged by a whole number to about 1200 px wide
    (240 wide ×5 from the old versions, 400 wide ×3 since v266), so every pixel stays a clean square."""
    return max(1, min(5, 1200 // max(1, im.width)))

def share_prepare(user, body):
    """Turn the game's card into a JPEG Telegram already has (file_id), then prepare a message with the button."""
    if not rate_ok(user["id"], "share"):
        return SLOW(user["id"], "share")
    text, image, link = str(body.get("text", ""))[:900], str(body.get("image", "")), str(body.get("link", ""))
    log.info("share_prepare from %s: link=%s image_prefix=%s text_len=%d webapp=%s",
             user["id"], link[:60], image[:30], len(text), (WEBAPP_URL or "")[:60])
    if not link.startswith("https://t.me/") or not image.startswith("data:image/"):
        log.warning("share_prepare rejected: link_ok=%s image_ok=%s", link.startswith("https://t.me/"), image.startswith("data:image/"))
        return 400, {"ok": False}
    try:
        from PIL import Image
    except ImportError:
        log.warning("share_prepare: python3-pil is not installed")
        return 503, {"ok": False, "reason": "python3-pil is not installed"}
    try:
        raw = base64.b64decode(image.split(",", 1)[1], validate=True)
        if len(raw) > 400_000:
            log.warning("share_prepare: image too big (%d bytes)", len(raw))
            return 413, {"ok": False}
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        if im.width > 1000 or im.height > 1000:
            log.warning("share_prepare: image too large %dx%d", im.width, im.height)
            return 413, {"ok": False}
        k = _card_k(im)
        im = im.resize((im.width * k, im.height * k), Image.NEAREST)
        name = hashlib.sha256(raw).hexdigest()[:24] + ".jpg"
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=95, subsampling=0)
        jpeg = buf.getvalue()
        with open(os.path.join(CARDS, name), "wb") as fh:
            fh.write(jpeg)
        log.info("share_prepare: card saved %s (%dx%d jpeg=%d from %d png)", name, im.width, im.height, len(jpeg), len(raw))
    except Exception as e:
        log.info("bad card from %s: %s", user["id"], e)
        return 400, {"ok": False}
    url = WEBAPP_URL + "cards/" + name
    did = str(body.get("duel") or "")
    rid = ("duel_" + did) if did.isalnum() and len(did) <= 16 else name[:24]
    btn_text = {"duel": "⚔️ Принять вызов", "gr": "🛡 Вступить в группу"}.get(body.get("button"), "Войти в башню")
    kb = {"inline_keyboard": [[{"text": btn_text, "url": link}]]}
    fid = share_photo_file_id(user["id"], jpeg)
    if fid:
        result = {"type": "photo", "id": rid, "photo_file_id": fid, "caption": text, "reply_markup": kb}
        log.info("share_prepare: using photo_file_id")
    else:
        result = {"type": "photo", "id": rid, "photo_url": url, "thumbnail_url": url,
                  "photo_width": im.width, "photo_height": im.height, "caption": text, "reply_markup": kb}
        log.warning("share_prepare: no file_id, falling back to photo_url=%s", url)
    try:
        r = tg("savePreparedInlineMessage", user_id=user["id"], result=result,
               allow_user_chats=True, allow_group_chats=True, allow_channel_chats=True, allow_bot_chats=False)
        if r.get("ok"):
            log.info("share_prepare: savePreparedInlineMessage ok, id=%s", r["result"]["id"])
            return 200, {"id": r["result"]["id"]}
        log.warning("savePreparedInlineMessage not ok: %s", r)
    except Exception as e:
        log.warning("savePreparedInlineMessage: %s", e)
    # Fallback: the pretty share needs inline mode + a fresh Telegram client. If either is missing,
    # send the photo + button straight to the player's own chat with the bot — they can forward it.
    try:
        r = tg_multipart("sendPhoto", {"photo": ("card.jpg", jpeg, "image/jpeg")},
                         chat_id=user["id"], caption=text, reply_markup=kb)
        if r.get("ok"):
            log.info("share fallback: sent card to user %s", user["id"])
            return 200, {"ok": True, "sent": True}
        log.warning("share fallback sendPhoto not ok: %s", r)
    except Exception as e:
        log.warning("share fallback sendPhoto: %s", e)
    return 502, {"ok": False, "reason": "tg"}

def cards_cleanup():
    cutoff = time.time() - 14 * 86400
    for n in os.listdir(CARDS):
        p = os.path.join(CARDS, n)
        try:
            if os.path.getmtime(p) < cutoff:
                os.remove(p)
        except OSError:
            pass


# ---------------------------------------------------------------- duels
# Anyone can be challenged at any moment: the heroes fight as their latest cloud saves have them dressed and trained.
# The fight itself is the game's own engine (duel_engine.js runs the page's logic script with Node.js).
import subprocess, shutil
db.execute("""CREATE TABLE IF NOT EXISTS duels(id TEXT PRIMARY KEY, from_uid INTEGER, from_snap TEXT, created REAL,
              to_uid INTEGER, to_snap TEXT, result TEXT, done_at REAL, from_claimed INTEGER DEFAULT 0)""")
for col, typ in [("kind", "TEXT DEFAULT 'link'"), ("declined", "INTEGER DEFAULT 0")]:
    try:
        db.execute(f"ALTER TABLE duels ADD COLUMN {col} {typ}")
    except sqlite3.OperationalError:
        pass
try:
    db.execute("ALTER TABLE players ADD COLUMN dtag TEXT")
except sqlite3.OperationalError:
    pass
db.execute("CREATE INDEX IF NOT EXISTS duels_from ON duels(from_uid, created)")
db.execute("CREATE INDEX IF NOT EXISTS duels_to ON duels(to_uid, done_at)")
db.execute("UPDATE duels SET from_claimed=1 WHERE kind='direct' AND result IS NOT NULL AND from_claimed=0 AND done_at<?", (1793000000,))
db.execute("CREATE TABLE IF NOT EXISTS duel_paid(uid INTEGER, day INTEGER, n INTEGER, PRIMARY KEY(uid, day))")
db.commit()
# ---------------------------------------------------------------- anti-spam (v194)
# In memory, per player: how many times an action was done in a sliding window. A restart forgets it, which is fine.
import collections
_rl_lock = threading.Lock()
_rl_hits = collections.defaultdict(collections.deque)
RL = {                       # action: (times, seconds)
    "post": (150, 60),       # any request that changes something: far above what playing needs
    "duel_new": (10, 3600), "duel_direct": (1, 15), "duel_answer": (30, 60),
    "gr_new": (6, 600), "gr_join": (20, 60), "gr_public": (8, 600), "gr_start": (10, 60), "gr_kick": (20, 60),
    "share": (12, 60), "duel_card": (12, 60), "ghost": (20, 60), "pcode": (8, 60), "pwd": (4, 60),
    "gr_notify": (3, 3600),
    "skip": (150, 60),       # v216: rest skips on their own (autofarm catching up spends about one a second)  # a host may call players by bot message to three groups an hour (admins too)
}
def rate_ok(uid, key, now=None):
    """True and counted when the player may do this now; False when he has done it too often lately."""
    if uid in ADMIN_IDS and key != "gr_notify":
        return True
    n, sec = RL[key]
    now = now or time.time()
    with _rl_lock:
        q = _rl_hits[(uid, key)]
        while q and now - q[0] > sec:
            q.popleft()
        if len(q) >= n:
            return False
        q.append(now)
        if len(_rl_hits) > 200_000:          # a forgotten-player sweep, so memory never grows without bound
            for k in [k for k, v in _rl_hits.items() if not v or now - v[-1] > 3600]:
                del _rl_hits[k]
        return True

def rate_wait(uid, key):
    n, sec = RL[key]
    with _rl_lock:
        q = _rl_hits.get((uid, key))
        return max(1, int(sec - (time.time() - q[0]))) if q else 1

SLOW = lambda uid, key: (200, {"ok": False, "reason": "slow", "wait": rate_wait(uid, key)})
DUEL_PM_PER_DAY = 10         # challenge messages one player gets from the bot a day; past that the challenge waits in the game

DUEL_OPEN_MAX = 3            # open challenge links per player
DUEL_CANCEL_AFTER = 3600     # v240: a challenge nobody answered can be taken back by its author after an hour
DUEL_TTL = 3 * 86400         # an unanswered link expires
DUEL_PAID_PER_DAY = 5        # duels a day that pay gold (to each player)
DUEL_DIRECT_PER_DAY = 15     # direct challenges a player may throw a day
DUEL_SAME_GAP = 3600         # the same opponent once an hour
ENGINE = os.path.join(HERE, "duel_engine.js")
NODE = shutil.which("node") or shutil.which("nodejs")

def engine(q):
    if not NODE:
        log.warning("duels need Node.js: apt install -y nodejs")
        return None
    try:
        p = subprocess.run([NODE, ENGINE], input=json.dumps(q).encode(), capture_output=True, timeout=40)
        r = json.loads(p.stdout.decode() or "{}")
    except Exception as e:
        log.warning("duel engine: %s", e)
        return None
    if r.get("error"):
        log.warning("duel engine: %s", r["error"])
        return None
    return r

def _save_of(uid):
    r = db.execute("SELECT data FROM saves WHERE uid=?", (uid,)).fetchone()
    try:
        sv = json.loads(r[0]) if r else None
    except ValueError:
        sv = None
    return sv if isinstance(sv, dict) and sv.get("cls") and isinstance(sv.get("inv"), list) else None

def _look(sv):
    eq, inv = sv.get("eq") or {}, sv.get("inv") or []
    out = {"cls": str(sv.get("cls", "knight"))[:16]}
    if out["cls"] == "mage":
        out["p"] = str(sv.get("path") or "")[:16]      # v272: fire or ice is drawn from his own path, not the viewer's
    for k, slot in (("w", "weapon"), ("a", "armor"), ("h", "helmet"), ("b", "boots")):
        it = next((i for i in inv if isinstance(i, dict) and i.get("slot") == slot and eq.get(slot) == i.get("uid")), None)
        if it:
            out[k] = {"tid": str(it.get("tid", ""))[:32], "r": as_int(it.get("rarity"), 0, 5)}
    return out

def _card(uid, sv, st=None):
    p = db.execute("SELECT name, room FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок", 0)
    c = {"name": p[0], "room": p[1], "cls": str(sv.get("cls", "knight"))[:16], "level": as_int(sv.get("level"), 1, 100000), "look": _look(sv),
         "tag": _tag(uid)}
    if st:
        c.update(power=st.get("power", 0), hp=st.get("hp", 0))
    return c

def _tag(uid):
    r = db.execute("SELECT dtag FROM players WHERE id=?", (uid,)).fetchone()
    if r and r[0]:
        return r[0]
    t = base64.urlsafe_b64encode(os.urandom(6)).decode().replace("-", "x").replace("_", "y")
    db.execute("UPDATE players SET dtag=? WHERE id=?", (t, uid))
    return t

def _pay(uid, room, won):
    """Gold for the first duels of the day; the counter is per player."""
    day = day_id()
    n = (db.execute("SELECT n FROM duel_paid WHERE uid=? AND day=?", (uid, day)).fetchone() or (0,))[0]
    if n >= DUEL_PAID_PER_DAY:
        return 0
    db.execute("INSERT OR REPLACE INTO duel_paid(uid, day, n) VALUES(?,?,?)", (uid, day, n + 1))
    room = max(1, room)
    v = int((60 + room * 9) if won else (20 + room * 3))
    _ecr_add(uid, g=v)
    return v

# ---------------------------------------------------------------- anti-cheat
# The game runs on the phone, so the server checks what it receives. A long-running Node worker (ac_worker.js) applies the
# game's own rules: skill points, item levels and stats against the most the game can make, and whether the hero can really
# beat the boss of a floor it claims. The server adds what only it knows: real time between saves.
# A suspect gets a record in ac_flags. In 'watch' mode nothing happens to the player, the owner just sees the list;
# in 'enforce' mode the suspect leaves the leaderboard and the season, and can't duel, haunt floors or hit raid bosses.
import queue, select
AC_WORKER = os.path.join(HERE, "ac_worker.js")
AC_SEC_PER_WIN = float(os.environ.get("AC_SEC_PER_WIN", "1.0"))   # no fight is won faster than this, even by a monster of a hero
AC_WIN_SLACK = 60
AC_CANWIN_STEP = 50                                                  # re-check the boss each time the record grows this much
AC_VER = "1"
db.execute("""CREATE TABLE IF NOT EXISTS ac_flags(uid INTEGER PRIMARY KEY, ts REAL, status TEXT, reasons TEXT,
  kinds TEXT, cleared TEXT DEFAULT '', notified REAL DEFAULT 0, info TEXT)""")
db.execute("CREATE TABLE IF NOT EXISTS ac_state(uid INTEGER PRIMARY KEY, wins INTEGER, ts REAL, checked INTEGER DEFAULT 0)")
db.commit()

class _ACWorker:
    def __init__(self):
        self.p, self.lock = None, threading.Lock()
    def _start(self):
        self.p = subprocess.Popen([NODE, AC_WORKER], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, cwd=HERE)
    def call(self, q, timeout=60):
        if not NODE:
            return None
        with self.lock:
            for attempt in (0, 1):
                try:
                    if not self.p or self.p.poll() is not None:
                        self._start()
                    self.p.stdin.write((json.dumps(q) + "\n").encode())
                    self.p.stdin.flush()
                    r, _w, _x = select.select([self.p.stdout], [], [], timeout)
                    if not r:
                        raise TimeoutError("worker timeout")
                    line = self.p.stdout.readline()
                    if not line:
                        raise EOFError("worker gone")
                    out = json.loads(line.decode())
                    if out.get("error"):
                        log.warning("ac worker: %s", out["error"])
                        return None
                    return out
                except Exception as e:
                    log.warning("ac worker (%s): %s", attempt, e)
                    try:
                        self.p.kill()
                    except Exception:
                        pass
                    self.p = None
            return None
AC = _ACWorker()
ac_queue = queue.PriorityQueue()        # (due time, uid)
_ac_waiting = set()
AC_MIN_GAP = 30          # v232: one player is checked at most once per this many seconds (a save comes every 6 s)
_ac_last, _ac_ts = {}, {}

def ac_mode():
    r = db.execute("SELECT v FROM kv WHERE k='ac_mode'").fetchone()
    return r[0] if r and r[0] in ("watch", "enforce") else "watch"

def ac_enqueue(uid, ts):
    _ac_ts[uid] = ts                     # the check reads the newest save anyway: its time is the one that counts
    if uid not in _ac_waiting:
        _ac_waiting.add(uid)
        ac_queue.put((_ac_last.get(uid, 0) + AC_MIN_GAP, uid))

def _ac_dur(sec):
    return (f"{int(sec // 3600)} ч {int(sec % 3600 // 60)} мин" if sec >= 3600 else
            f"{int(sec // 60)} мин" if sec >= 60 else f"{max(1, int(sec))} с")

def ac_check(uid, recv_ts, retro=False):
    """Checks the stored save of one player; returns the list of issues found (also stored and reported)."""
    with db_lock:
        sv = _save_of(uid)
        stt = db.execute("SELECT wins, ts, checked FROM ac_state WHERE uid=?", (uid,)).fetchone()
    if not sv:
        return []
    r = AC.call({"op": "check", "save": sv})
    if not r:
        return []
    issues = list(r.get("issues") or [])
    eco = _eco_soft.pop(uid, None)
    if eco:
        issues.append({"k": "refused", "hard": True, "msg": eco})
    wins, floor = int(r.get("wins") or 0), int(r.get("floor") or 0)
    # real time: wins can't grow faster than one per AC_SEC_PER_WIN seconds
    if stt and not retro:
        dw, dt = wins - (stt[0] or 0), recv_ts - (stt[1] or recv_ts)
        if dw > dt / AC_SEC_PER_WIN + AC_WIN_SLACK:
            issues.append({"k": "speed", "hard": True, "msg": f"+{dw} побед за {_ac_dur(dt)}"})
    checked = stt[2] if stt else 0
    # the boss of the claimed floor, tried with the real engine; a fail is checked again lower before it counts
    if floor >= 50 and floor >= (checked or 0) + AC_CANWIN_STEP:
        w = AC.call({"op": "canwin", "save": sv, "room": floor, "seeds": 4}, timeout=120)
        if w and not w.get("wins"):
            low = AC.call({"op": "canwin", "save": sv, "room": int(floor * 0.7), "seeds": 4}, timeout=120)
            hard = bool(low and not low.get("wins") and low.get("room", 0) >= 50)
            issues.append({"k": "canwin", "hard": hard,
                           "msg": f"герой не проходит босса {w['room']} этажа" + (f" и даже {low['room']}" if hard else "")})
        if w:
            checked = floor
    with db_lock:
        db.execute("INSERT OR REPLACE INTO ac_state(uid, wins, ts, checked) VALUES(?,?,?,?)", (uid, wins, recv_ts, checked))
        db.commit()
    ac_record(uid, issues, {"power": r.get("power"), "level": r.get("level"), "floor": floor, "wins": wins})
    return issues

def ac_record(uid, issues, info):
    hard = [i for i in issues if i.get("hard")]
    soft = [i for i in issues if not i.get("hard")]
    if soft:
        log.info("ac soft %s: %s", uid, "; ".join(i["msg"] for i in soft))
    if not hard:
        return
    log.warning("ac HARD %s: %s", uid, "; ".join(i["msg"] for i in hard))
    if uid in ADMIN_IDS:
        return                           # the owner's tests (floor jumps, given items) are not cheating
    kinds = sorted({i["k"] for i in hard})
    now = time.time()
    with db_lock:
        row = db.execute("SELECT status, reasons, cleared, notified FROM ac_flags WHERE uid=?", (uid,)).fetchone()
        if row and row[0] == "cleared" and set(kinds) <= set((row[2] or "").split(",")):
            return                       # the owner already looked at exactly this and let it go
        old = json.loads(row[1]) if row and row[1] else []
        msgs = [i["msg"] for i in hard]
        reasons = (msgs + [m for m in old if m not in msgs])[:8]
        status = "banned" if row and row[0] == "banned" else "open"
        notify = not row or row[0] == "cleared"          # "notified" keeps the moment the suspicion appeared
        db.execute("""INSERT INTO ac_flags(uid, ts, status, reasons, kinds, cleared, notified, info) VALUES(?,?,?,?,?,?,?,?)
                      ON CONFLICT(uid) DO UPDATE SET ts=excluded.ts, status=excluded.status, reasons=excluded.reasons,
                      kinds=excluded.kinds, notified=excluded.notified, info=excluded.info""",
                   (uid, now, status, json.dumps(reasons, ensure_ascii=False), ",".join(kinds), row[2] if row else "",
                    now if notify else (row[3] if row else 0), json.dumps(info)))
        if ac_mode() == "enforce" or status == "banned":
            db.execute("UPDATE players SET flagged=1 WHERE id=?", (uid,))
        p = db.execute("SELECT name, username, room FROM players WHERE id=?", (uid,)).fetchone()
        mode = ac_mode()
        db.commit()
    # no message per player: the owner gets one summary a day (ac_digest_loop)

AC_DIGEST_HOUR = int(os.environ.get("AC_DIGEST_HOUR", "12"))      # local hour of the daily summary
AC_TZ = float(os.environ.get("AC_TZ", "3"))                         # owner's time zone, hours from UTC

def ac_digest():
    """One message: who was newly suspected since the last summary, and how many are still waiting for a decision."""
    with db_lock:
        r = db.execute("SELECT v FROM kv WHERE k='ac_digest_ts'").fetchone()
        since = float(r[0]) if r else 0.0
        new = db.execute("""SELECT f.uid, f.reasons, p.name, p.username, p.room FROM ac_flags f LEFT JOIN players p ON p.id=f.uid
                            WHERE f.status='open' AND f.notified>? ORDER BY p.room DESC LIMIT 20""", (since,)).fetchall()
        n_open = db.execute("SELECT COUNT(*) FROM ac_flags WHERE status='open'").fetchone()[0]
        mode = ac_mode()
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('ac_digest_ts', ?)", (str(time.time()),))
        db.commit()
    lines = [f"• {mention(u, n or 'Игрок', un)} (этаж {rm or 0}): " + html_esc("; ".join(json.loads(rs or "[]")[:2]))
             for u, rs, n, un, rm in new]
    txt = ("🛡 Анти-чит за сутки\n\n" +
           (f"Новых подозрительных: {len(new)}\n" + "\n".join(lines) if new else "Новых подозрительных нет.") +
           f"\n\nВсего ждут решения: {n_open}." +
           ("\nРежим наблюдения: игроки ничего не замечают." if mode == "watch" else "\nРежим наказания: подозреваемые скрыты из топа и дуэлей.") +
           ("\nРешить: игра → ⚙ Меню → Анти-чит." if n_open else ""))
    for a in ADMIN_IDS:
        try:
            tg("sendMessage", chat_id=a, text=txt, parse_mode="HTML")
        except Exception as e:
            log.info("ac digest: %s", e)

def ac_digest_loop():
    while True:
        try:
            lt = time.gmtime(time.time() + AC_TZ * 3600)
            day = time.strftime("%Y-%m-%d", lt)
            if lt.tm_hour >= AC_DIGEST_HOUR:
                with db_lock:
                    r = db.execute("SELECT v FROM kv WHERE k='ac_digest_day'").fetchone()
                    due = not r or r[0] != day
                    if due:
                        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('ac_digest_day', ?)", (day,))
                        db.commit()
                if due:
                    ac_digest()
        except Exception as e:
            log.warning("ac digest: %s", e)
        time.sleep(60)

def ac_loop():
    while True:
        due, uid = ac_queue.get()
        wait = due - time.time()
        if wait > 0:
            ac_queue.put((due, uid))
            time.sleep(min(wait, 0.5))
            continue
        _ac_waiting.discard(uid)
        ts = _ac_ts.get(uid) or time.time()
        _ac_last[uid] = time.time()
        try:
            ac_check(uid, ts)
        except Exception as e:
            log.warning("ac check %s: %s", uid, e)

def ac_scan():
    """Once per rules version: every stored hero is checked; the owner gets one summary instead of a message per player."""
    time.sleep(20)
    with db_lock:
        r = db.execute("SELECT v FROM kv WHERE k='ac_scan'").fetchone()
        if r and r[0] == AC_VER:
            return
        uids = [x[0] for x in db.execute("SELECT uid FROM saves")]
    ac_record.quiet = True
    found = []
    try:
        for uid in uids:
            try:
                iss = [i for i in ac_check(uid, time.time(), retro=True) if i.get("hard")]
                if iss and uid not in ADMIN_IDS:
                    found.append((uid, iss))
            except Exception as e:
                log.warning("ac scan %s: %s", uid, e)
    finally:
        ac_record.quiet = False
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('ac_scan', ?)", (AC_VER,))
        names = {u: db.execute("SELECT name, username, room FROM players WHERE id=?", (u,)).fetchone() for u, _ in found}
        db.commit()
    lines = []
    for u, iss in found[:25]:
        p = names.get(u) or ("Игрок", None, 0)
        lines.append(f"• {mention(u, p[0], p[1])} (этаж {p[2]}): " + html_esc("; ".join(i["msg"] for i in iss[:2])))
    txt = (f"🛡 Анти-чит проверил всех игроков ({len(uids)}).\n" +
           (f"Подозрительных: {len(found)}\n" + "\n".join(lines) if found else "Подозрительных нет.") +
           "\n\nСейчас режим наблюдения: игроки ничего не заметили. Список и решения: игра → ⚙ Меню → Анти-чит.")
    for a in ADMIN_IDS:
        try:
            tg("sendMessage", chat_id=a, text=txt, parse_mode="HTML")
        except Exception as e:
            log.info("ac summary: %s", e)

def ac_admin_get(user):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        rows = db.execute("""SELECT f.uid, f.ts, f.status, f.reasons, f.info, p.name, p.username, p.room, p.cls FROM ac_flags f
                             LEFT JOIN players p ON p.id=f.uid ORDER BY CASE f.status WHEN 'open' THEN 0 WHEN 'banned' THEN 1 ELSE 2 END, f.ts DESC
                             LIMIT 60""").fetchall()
        mode = ac_mode()
    out = []
    for uid, ts, st, rs, info, name, un, room, cls in rows:
        out.append({"uid": uid, "ts": ts, "status": st, "reasons": json.loads(rs or "[]"), "info": json.loads(info or "{}"),
                    "name": name or "Игрок", "username": un, "room": room or 0, "cls": cls})
    return 200, {"ok": True, "mode": mode, "rows": out}

def ac_admin_set(user, body):
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    act, uid = str(body.get("action", "")), as_int(body.get("uid"), 0, 10**13)
    with db_lock:
        if act == "mode":
            mode = "enforce" if body.get("mode") == "enforce" else "watch"
            db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('ac_mode', ?)", (mode,))
            db.execute("UPDATE players SET flagged=0 WHERE id IN (SELECT uid FROM ac_flags WHERE status<>'banned')")
            if mode == "enforce":
                db.execute("UPDATE players SET flagged=1 WHERE id IN (SELECT uid FROM ac_flags WHERE status='open')")
            db.execute("UPDATE players SET flagged=1 WHERE id IN (SELECT uid FROM ac_flags WHERE status='banned')")
        elif act == "clear":
            db.execute("UPDATE ac_flags SET status='cleared', cleared=kinds WHERE uid=?", (uid,))
            db.execute("UPDATE players SET flagged=0 WHERE id=?", (uid,))
        elif act == "ban":
            # v258: «Скрыть» from a player's card works for anyone, not only for someone the anti-cheat already listed
            if not db.execute("SELECT 1 FROM ac_flags WHERE uid=?", (uid,)).fetchone():
                db.execute("INSERT INTO ac_flags(uid, ts, status, reasons, kinds, cleared, notified, info) VALUES(?,?,?,?,?,?,?,?)",
                           (uid, int(time.time()), "banned", json.dumps(["скрыт админом из карточки игрока"], ensure_ascii=False),
                            "admin", "", int(time.time()), "{}"))
            db.execute("UPDATE ac_flags SET status='banned' WHERE uid=?", (uid,))
            db.execute("UPDATE players SET flagged=1 WHERE id=?", (uid,))
        elif act == "rescan":
            db.execute("DELETE FROM kv WHERE k='ac_scan'")
            db.execute("UPDATE ac_state SET checked=0")
        else:
            return 400, {"ok": False}
        db.commit()
    log.info("ac admin %s: %s %s", user["id"], act, uid or body.get("mode"))
    if act == "rescan":
        threading.Thread(target=ac_scan, daemon=True).start()
    return ac_admin_get(user)

def is_flagged(uid):
    r = db.execute("SELECT flagged FROM players WHERE id=?", (uid,)).fetchone()
    return bool(r and r[0])

def _fight(a_uid, b_uid, seed):
    """a is the side that challenged (left), b the one who answered or was called (right)."""
    sa, sb = _save_of(a_uid), _save_of(b_uid)
    if not sa or not sb:
        return None, "nosave"
    if is_flagged(a_uid) or is_flagged(b_uid):
        return None, "review"
    r = engine({"mode": "fight", "a": sa, "b": sb, "seed": seed})
    if not r:
        return None, "engine"
    st = r.pop("stats", [{}, {}])
    r["from"], r["to"] = _card(a_uid, sa, st[0]), _card(b_uid, sb, st[1])
    return r, None

def _duel_pm(uid, txt, btn=None):
    """btn = (text, start param). v241: a group message had «Посмотреть дуэль» — now each message gets its own button."""
    bt, sp = btn or ("Посмотреть дуэль", "duels")
    try:
        tg("sendMessage", chat_id=uid, text=txt,
           reply_markup={"inline_keyboard": [[{"text": bt, "url": app_link(sp) if sp else app_link()}]]})
    except Exception as e:
        log.info("duel pm to %s: %s", uid, e)

def _tell(uid, txt, btn=None):
    pm = db.execute("SELECT can_pm FROM players WHERE id=?", (uid,)).fetchone()
    if pm and pm[0]:
        threading.Thread(target=_duel_pm, args=(uid, txt, btn), daemon=True).start()

def _seed(did):
    return int(hashlib.sha256(did.encode()).hexdigest()[:7], 16)   # fits a 32-bit int for the engine

def duel_new(user, body):
    now = time.time()
    if not rate_ok(user["id"], "duel_new", now):
        return SLOW(user["id"], "duel_new")
    with db_lock:
        if is_flagged(user["id"]):
            return 200, {"ok": False, "reason": "review"}
        if not _save_of(user["id"]):
            return 200, {"ok": False, "reason": "nosave"}
        n = db.execute("SELECT COUNT(*) FROM duels WHERE from_uid=? AND to_uid IS NULL AND kind='link' AND declined=0 AND result IS NULL AND created>?",
                       (user["id"], now - DUEL_TTL)).fetchone()[0]
        if n >= DUEL_OPEN_MAX:
            return 200, {"ok": False, "reason": "many", "max": DUEL_OPEN_MAX}
        did = base64.urlsafe_b64encode(os.urandom(6)).decode().replace("-", "x").replace("_", "y")
        db.execute("INSERT INTO duels(id, from_uid, from_snap, created, kind) VALUES(?,?,?,?, 'link')", (did, user["id"], "{}", now))
        db.commit()
    return 200, {"ok": True, "id": did, "link": app_link("duel_" + did)}

def _duel_res(res, fsnap, tsnap):
    """A finished fight; the very first duels kept the heroes' cards apart from the result."""
    try:
        R = json.loads(res)
    except ValueError:
        R = {"win": 0, "log": []}
    for k, raw in (("from", fsnap), ("to", tsnap)):
        if not isinstance(R.get(k), dict):
            try:
                R[k] = json.loads(raw or "{}") or {"name": "Игрок"}
            except ValueError:
                R[k] = {"name": "Игрок"}
    R.setdefault("win", 0)
    return R

def duel_get(user, did):
    did = str(did)[:16]
    uid = user["id"]
    with db_lock:
        r = db.execute("SELECT from_uid, created, to_uid, result, kind, declined FROM duels WHERE id=?", (did,)).fetchone()
        if not r:
            return 404, {"ok": False, "reason": "none"}
        fu, created, tu, res, kind, declined = r
        if res:
            sn = db.execute("SELECT from_snap, to_snap FROM duels WHERE id=?", (did,)).fetchone()
            R = _duel_res(res, sn[0], sn[1])
            side = 0 if fu == uid else 1 if tu == uid else -1
            return 200, {"ok": True, "id": did, "status": "done", "from": R.get("from"), "to": R.get("to"), "result": R, "side": side}
        if declined:
            st = "cancelled" if declined == 2 else "declined"
        elif created < time.time() - DUEL_TTL:
            st = "expired"
        elif fu == uid:
            st = "mine"
        elif kind == "direct" and tu != uid:
            st = "notyou"          # a personal challenge: only the one who was called can answer it
        else:
            st = "open"
        sv = _save_of(fu)
    stats = engine({"mode": "stats", "saves": [sv]}) if sv else None
    with db_lock:
        card = _card(fu, sv, (stats or {}).get("stats", [{}])[0]) if sv else {"name": "Игрок"}
        db.commit()
    return 200, {"ok": True, "id": did, "status": st, "from": card, "kind": kind}


def _duel_msgs(did):
    with db_lock:
        a = db.execute("SELECT v FROM kv WHERE k=?", ("dmsg:" + did,)).fetchone()
        b = db.execute("SELECT v FROM kv WHERE k=?", ("dpm:" + did,)).fetchone()
    return (json.loads(a[0]) if a else []), (json.loads(b[0]) if b else None)

def _duel_caption(R):
    w, l = (R["from"], R["to"]) if R["win"] == 0 else (R["to"], R["from"])
    cls = {"knight": "Рыцарь", "gunner": "Стрелок", "necro": "Некромант", "assassin": "Ассасин", "gladiator": "Гладиатор", "mage": "Маг", "samurai": "Самурай"}.get(w.get("cls"), "Герой")
    return f"🏆 Победитель дуэли: {w.get('name', 'Игрок')} ({cls}, {w.get('level', '?')} ур.)\n⚔️ {w.get('name', 'Игрок')} против {l.get('name', 'Игрок')}"

def duel_announce(did, R, photo=None):
    """Turn the invitation in the chat (the card) and in private messages into the result."""
    inl, pm = _duel_msgs(did)
    cap = _duel_caption(R)
    kb = {"inline_keyboard": [[{"text": "👁 Посмотреть бой", "url": app_link("duel_" + did)}]]}
    for imid in inl:
        try:
            if photo:
                tg("editMessageMedia", inline_message_id=imid, media={"type": "photo", "media": photo, "caption": cap}, reply_markup=kb)
            else:
                tg("editMessageCaption", inline_message_id=imid, caption=cap, reply_markup=kb)
        except Exception as e:
            log.info("duel card edit: %s", e)
    if pm and not photo:
        try:
            tg("editMessageText", chat_id=pm[0], message_id=pm[1], text="⚔️ Дуэль окончена!\n" + cap, reply_markup=kb)
        except Exception as e:
            log.info("duel pm edit: %s", e)

def duel_card(user, body):
    """The winner's card drawn by the game replaces the challenge picture in the chat."""
    if not rate_ok(user["id"], "duel_card"):
        return SLOW(user["id"], "duel_card")
    did, image = str(body.get("id", ""))[:16], str(body.get("image", ""))
    with db_lock:
        r = db.execute("SELECT from_uid, to_uid, result FROM duels WHERE id=?", (did,)).fetchone()
    if not r or not r[2] or user["id"] not in (r[0], r[1]) or not image.startswith("data:image/png;base64,"):
        return 200, {"ok": False}
    try:
        from PIL import Image
        raw = base64.b64decode(image.split(",", 1)[1], validate=True)
        if len(raw) > 400_000:
            return 413, {"ok": False}
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        if im.width > 1000 or im.height > 1000:
            return 413, {"ok": False}
        k = _card_k(im)
        im = im.resize((im.width * k, im.height * k), Image.NEAREST)
        name = hashlib.sha256(raw).hexdigest()[:24] + ".jpg"
        im.save(os.path.join(CARDS, name), "JPEG", quality=95, subsampling=0)
    except Exception as e:
        log.info("bad duel card: %s", e)
        return 400, {"ok": False}
    R = json.loads(r[2])
    if _duel_msgs(did)[0]:
        threading.Thread(target=duel_announce, args=(did, R, WEBAPP_URL + "cards/" + name), daemon=True).start()
    return 200, {"ok": True}

def duel_accept(user, body):
    """The fight happens only here: when the one who was challenged says yes."""
    if not rate_ok(user["id"], "duel_answer"):
        return SLOW(user["id"], "duel_answer")
    did, uid = str(body.get("id", ""))[:16], user["id"]
    with db_lock:
        r = db.execute("SELECT from_uid, created, to_uid, result, kind, declined FROM duels WHERE id=?", (did,)).fetchone()
        if not r:
            return 404, {"ok": False, "reason": "none"}
        fu, created, tu, res, kind, declined = r
        if res or (kind != "direct" and tu):
            return 200, {"ok": False, "reason": "taken"}
        if declined:
            return 200, {"ok": False, "reason": "cancelled" if declined == 2 else "declined"}
        if fu == uid:
            return 200, {"ok": False, "reason": "self"}
        if kind == "direct" and tu != uid:
            return 200, {"ok": False, "reason": "notyou"}
        if created < time.time() - DUEL_TTL:
            return 200, {"ok": False, "reason": "expired"}
        if kind != "direct":
            db.execute("UPDATE duels SET to_uid=? WHERE id=? AND to_uid IS NULL", (uid, did))   # taken: nobody else can answer
            db.commit()
        R, err = _fight(fu, uid, _seed(did))
        if not R:
            if kind != "direct":
                db.execute("UPDATE duels SET to_uid=NULL WHERE id=?", (did,))
                db.commit()
            return 200, {"ok": False, "reason": err}
        won = R["win"] == 1
        gold = _pay(uid, _player_room(uid), won)
        db.execute("UPDATE duels SET result=?, done_at=? WHERE id=?", (json.dumps(R), time.time(), did))
        db.commit()
        name = R["to"]["name"]
    _tell(fu, f"⚔️ {name} принял твой вызов на дуэль — " + ("ты проиграл. Отомсти!" if won else "ты победил! 🏆")
          + "\nОткрой игру, чтобы посмотреть бой и забрать награду.")
    threading.Thread(target=duel_announce, args=(did, R), daemon=True).start()
    return 200, {"ok": True, "id": did, "from": R["from"], "to": R["to"], "result": R, "side": 1, "reward": {"gold": gold}}

def duel_decline(user, body):
    if not rate_ok(user["id"], "duel_answer"):
        return SLOW(user["id"], "duel_answer")
    did, uid = str(body.get("id", ""))[:16], user["id"]
    with db_lock:
        r = db.execute("SELECT from_uid, to_uid, result, kind FROM duels WHERE id=?", (did,)).fetchone()
        if not r or r[2] or r[3] != "direct" or r[1] != uid:
            return 200, {"ok": False}
        db.execute("UPDATE duels SET declined=1, done_at=? WHERE id=?", (time.time(), did))
        db.commit()
        fu = r[0]
        name = (db.execute("SELECT name FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок",))[0]
    _tell(fu, f"🛡 {name} отказался от дуэли.")
    return 200, {"ok": True}

def duel_cancel(user, body):
    """v240: the author takes back his challenge (a link in a chat or a personal one) that waited an hour or more without
    an answer. It frees a place among the 3 open links; the link then says the challenge was cancelled."""
    if not rate_ok(user["id"], "duel_answer"):
        return SLOW(user["id"], "duel_answer")
    did, uid, now = str(body.get("id", ""))[:16], user["id"], time.time()
    with db_lock:
        r = db.execute("SELECT from_uid, to_uid, result, kind, declined, created FROM duels WHERE id=?", (did,)).fetchone()
        if not r or r[0] != uid or r[2] or r[4] or r[3] == "ghost":
            return 200, {"ok": False, "reason": "none"}
        if now - (r[5] or 0) < DUEL_CANCEL_AFTER:
            return 200, {"ok": False, "reason": "early", "left": int(DUEL_CANCEL_AFTER - (now - (r[5] or 0)))}
        db.execute("UPDATE duels SET declined=2, done_at=? WHERE id=? AND result IS NULL", (now, did))
        db.commit()
        pm = db.execute("SELECT v FROM kv WHERE k=?", ("dpm:" + did,)).fetchone()
    if pm:      # the personal invite in the bot chat goes away too
        try:
            c, m = json.loads(pm[0])
            threading.Thread(target=lambda: tg("deleteMessage", chat_id=c, message_id=m), daemon=True).start()
        except Exception:
            pass
    log.info("duel %s cancelled by its author %s", did, uid)
    return 200, {"ok": True}

def duel_direct(user, body):
    """A personal challenge to a player (from the leaderboard or a past duel). Nothing happens until they accept."""
    tag, now, uid = str(body.get("tag", ""))[:16], time.time(), user["id"]
    if not rate_ok(uid, "duel_direct", now):
        return SLOW(uid, "duel_direct")
    with db_lock:
        if is_flagged(user["id"]):
            return 200, {"ok": False, "reason": "review"}
        t = db.execute("SELECT id FROM players WHERE dtag=?", (tag,)).fetchone()
        if not t:
            return 404, {"ok": False, "reason": "none"}
        tid = t[0]
        if tid == uid:
            return 200, {"ok": False, "reason": "self"}
        if not _save_of(uid):
            return 200, {"ok": False, "reason": "nosave_me"}
        n = db.execute("SELECT COUNT(*) FROM duels WHERE from_uid=? AND kind='direct' AND created>=?", (uid, day_id() * 86400)).fetchone()[0]
        if n >= DUEL_DIRECT_PER_DAY:
            return 200, {"ok": False, "reason": "limit", "max": DUEL_DIRECT_PER_DAY}
        if db.execute("""SELECT 1 FROM duels WHERE from_uid=? AND to_uid=? AND kind='direct' AND result IS NULL AND declined=0
                         AND created>?""", (uid, tid, now - DUEL_TTL)).fetchone():
            return 200, {"ok": False, "reason": "pending"}
        did = base64.urlsafe_b64encode(os.urandom(6)).decode().replace("-", "x").replace("_", "y")
        db.execute("INSERT INTO duels(id, from_uid, from_snap, created, to_uid, kind) VALUES(?,?,?,?,?, 'direct')", (did, uid, "{}", now, tid))
        db.commit()
        name = (db.execute("SELECT name FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок",))[0]
        tname = (db.execute("SELECT name FROM players WHERE id=?", (tid,)).fetchone() or ("Игрок",))[0]
        pm = (db.execute("SELECT can_pm FROM players WHERE id=?", (tid,)).fetchone() or (0,))[0]
        if pm and db.execute("SELECT COUNT(*) FROM duels WHERE to_uid=? AND kind='direct' AND created>=?", (tid, now - 86400)).fetchone()[0] > DUEL_PM_PER_DAY:
            pm = 0
    if pm:
        threading.Thread(target=_duel_invite_pm, args=(tid, name, did), daemon=True).start()
    return 200, {"ok": True, "id": did, "to": tname}

def _duel_invite_pm(uid, name, did):
    try:
        r = tg("sendMessage", chat_id=uid, text=f"⚔️ {name} вызывает тебя на дуэль! Примешь вызов?",
               reply_markup={"inline_keyboard": [[{"text": "⚔️ Ответить на вызов", "url": app_link("duel_" + did)}]]})
        with db_lock:
            db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", ("dpm:" + did, json.dumps([uid, r["result"]["message_id"]])))
            db.commit()
    except Exception as e:
        log.info("duel invite pm to %s: %s", uid, e)

def duel_mine(user):
    """Everything about my duels: challenges waiting for me, mine waiting for an answer, and the history."""
    uid, now = user["id"], time.time()
    with db_lock:
        rows = db.execute("""SELECT id, from_uid, to_uid, result, done_at, from_claimed, created, kind, declined, from_snap, to_snap FROM duels
                             WHERE (from_uid=? OR to_uid=?) AND created>? ORDER BY COALESCE(done_at, created) DESC LIMIT 60""",
                          (uid, uid, now - 30 * 86400)).fetchall()
        name = lambda i: (db.execute("SELECT name FROM players WHERE id=?", (i,)).fetchone() or ("Игрок",))[0]
        cls = lambda i: (db.execute("SELECT cls FROM players WHERE id=?", (i,)).fetchone() or ("",))[0]
        gold, fresh, hist, inc, out, opened = 0, [], [], [], [], 0
        for did, fu, tu, res, done, claimed, created, kind, declined, fsnap, tsnap in rows:
            mine = fu == uid
            other = tu if mine else fu
            alive = created > now - DUEL_TTL
            if not res:
                if declined == 2 and kind != "direct":
                    pass                            # v240: a link its author took back just disappears
                elif declined:
                    hist.append({"id": did, "vs": name(other), "cls": cls(other), "state": "cancelled" if declined == 2 else "declined", "mine": mine,
                                 "at": int((done or created) * 1000), "tag": _tag(other)})
                elif not alive:
                    if kind == "direct":
                        hist.append({"id": did, "vs": name(other), "cls": cls(other), "state": "expired", "mine": mine, "at": int(created * 1000), "tag": _tag(other)})
                elif mine:
                    opened += 1 if kind != "direct" else 0
                    out.append({"id": did, "vs": name(other) if other else None, "kind": kind, "at": int(created * 1000),
                                "cancel_in": max(0, int(DUEL_CANCEL_AFTER - (now - created)))})
                elif kind == "direct" and tu == uid:
                    inc.append({"id": did, "vs": name(fu), "cls": cls(fu), "at": int(created * 1000)})
                continue
            R = _duel_res(res, fsnap, tsnap)
            won = (R["win"] == 0) == mine
            oc = (R["to"] if mine else R["from"]) or {}
            hist.append({"id": did, "vs": oc.get("name", "Игрок"), "cls": oc.get("cls"), "state": "won" if won else "lost", "won": won,
                         "mine": mine, "at": int(done * 1000), "tag": _tag(other), "kind": kind, "room": R.get("room")})
            if kind == "ghost":
                if not mine and not claimed:    # my ghost fought while I was away
                    g = _ghost_gold(uid, R.get("room") or _player_room(uid), won)
                    gold += g
                    fresh.append({"id": did, "vs": oc.get("name", "Игрок"), "won": won, "gold": g, "ghost": 1})
                    db.execute("UPDATE duels SET from_claimed=1 WHERE id=?", (did,))
                continue
            if mine and not claimed:            # I threw the challenge: my gold comes when I open the game
                g = _pay(uid, _player_room(uid), won)
                gold += g
                fresh.append({"id": did, "vs": oc.get("name", "Игрок"), "won": won, "gold": g})
                db.execute("UPDATE duels SET from_claimed=1 WHERE id=?", (did,))
        db.commit()
    wins = sum(1 for d in hist if d["state"] == "won" and d.get("kind") != "ghost")
    losses = sum(1 for d in hist if d["state"] == "lost" and d.get("kind") != "ghost")
    return 200, {"ok": True, "open": opened, "max": DUEL_OPEN_MAX, "incoming": inc, "outgoing": out, "history": hist[:30],
                 "recent": [h for h in hist if h["state"] in ("won", "lost")][:12], "fresh": fresh, "gold": gold, "wins": wins, "losses": losses}


# ---------------------------------------------------------------- ghosts: players stand on the floor where they stopped
# Climbing the tower you may meet another player on that very floor, dressed and trained as they are now.
# The same player is offered to you at most once a day, wherever either of you goes, so a climbing ghost never follows you up.
db.execute("CREATE TABLE IF NOT EXISTS ghost_offers(uid INTEGER, gid INTEGER, room INTEGER, ts REAL, PRIMARY KEY(uid, gid))")
db.commit()
GHOST_GAP = 86400            # one meeting with the same player a day
GHOST_PAID_PER_DAY = 10      # the ghost's owner is paid for at most this many fights a day

def ghost_find(user, room):
    uid, now, room = user["id"], time.time(), as_int(room, 1, 10**6)
    with db_lock:
        rows = db.execute("""SELECT p.id FROM players p JOIN saves s ON s.uid=p.id
                             WHERE p.room+1=? AND p.id<>? AND p.flagged=0 AND p.id NOT IN
                               (SELECT gid FROM ghost_offers WHERE uid=? AND ts>? AND room<>?)""",
                          (room, uid, uid, now - GHOST_GAP, room)).fetchall()
        if not rows:
            return 200, {"ok": True, "ghost": None}
        import random
        gid = random.choice(rows)[0]
        sv = _save_of(gid)
        if not sv:
            return 200, {"ok": True, "ghost": None}
        db.execute("INSERT OR REPLACE INTO ghost_offers(uid, gid, room, ts) VALUES(?,?,?,?)", (uid, gid, room, now))
        db.commit()
    st = engine({"mode": "stats", "saves": [sv]})
    with db_lock:
        card = _card(gid, sv, (st or {}).get("stats", [{}])[0])
        db.commit()
    return 200, {"ok": True, "ghost": card}

def _ghost_gold(uid, room, won):
    day = -day_id()          # its own daily counter, apart from duels
    n = (db.execute("SELECT n FROM duel_paid WHERE uid=? AND day=?", (uid, day)).fetchone() or (0,))[0]
    if n >= GHOST_PAID_PER_DAY:
        return 0
    db.execute("INSERT OR REPLACE INTO duel_paid(uid, day, n) VALUES(?,?,?)", (uid, day, n + 1))
    room = max(1, room)
    v = int((30 + room * 3) if won else (10 + room))
    _ecr_add(uid, g=v)
    return v

def ghost_fight(user, body):
    if not rate_ok(user["id"], "ghost"):
        return SLOW(user["id"], "ghost")
    uid, tag, now = user["id"], str(body.get("tag", ""))[:16], time.time()
    with db_lock:
        t = db.execute("SELECT id FROM players WHERE dtag=?", (tag,)).fetchone()
        if not t:
            return 200, {"ok": False, "reason": "none"}
        gid = t[0]
        off = db.execute("SELECT room, ts FROM ghost_offers WHERE uid=? AND gid=?", (uid, gid)).fetchone()
        if not off or now - off[1] > 2 * 3600:
            return 200, {"ok": False, "reason": "expired"}
        if db.execute("SELECT 1 FROM duels WHERE kind='ghost' AND from_uid=? AND to_uid=? AND created>?", (uid, gid, off[1] - 1)).fetchone():
            return 200, {"ok": False, "reason": "taken"}          # one fight per meeting
        did = base64.urlsafe_b64encode(os.urandom(6)).decode().replace("-", "x").replace("_", "y")
        R, err = _fight(uid, gid, _seed(did))
        if not R:
            return 200, {"ok": False, "reason": err}
        R["room"] = off[0]
        db.execute("""INSERT INTO duels(id, from_uid, from_snap, created, to_uid, to_snap, result, done_at, kind)
                      VALUES(?,?,?,?,?,?,?,?, 'ghost')""", (did, uid, "{}", now, gid, "{}", json.dumps(R), now))
        db.commit()
        me = R["from"]["name"]
    ghost_won = R["win"] == 1
    _tell(gid, f"👻 {me} встретил твоего призрака на {off[0]} этаже — " + ("призрак победил! 🏆" if ghost_won else "и одолел его.")
          + "\nЗагляни в игру: за бой призрака тебе положено немного золота.")
    return 200, {"ok": True, "id": did, "from": R["from"], "to": R["to"], "result": R, "side": 0, "room": off[0]}

# ---------------------------------------------------------------- stars: bought by the player, never earned in the game
# The balance lives only here, so it can't be edited on the phone. Every change is written to star_ledger.
# Stars are bought with real Telegram Stars (1 ★ in the game = 1 Telegram Star): the game asks for an invoice link
# (createInvoiceLink, currency XTR), Telegram takes the payment, the bot answers the pre-checkout and its successful_payment
# adds the stars (once per telegram_payment_charge_id). STARS_TEST=1 brings back the free test button for everyone;
# the owners always have it (the «+50 звёзд» debug button) to test without paying.
STARS_TEST = os.environ.get("STARS_TEST", "0") == "1"   # only the default: the owners switch it in the game (kv stars_test)

def _stars_test():
    r = db.execute("SELECT v FROM kv WHERE k='stars_test'").fetchone()
    return STARS_TEST if r is None else r[0] == "1"

def stars_mode(user, body):
    """Owners: {test: true} — buying is free for everyone (testers); {test: false} — real Telegram Stars."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('stars_test', ?)", ("1" if body.get("test") else "0",))
        db.commit()
        st = _stars_state(user["id"])
    log.info("stars mode by %s: %s", user["id"], "test" if st["test"] else "real")
    return 200, dict(st, ok=True)
STAR_INVOICE_MAX = 2500
STAR_PACKS = (10, 25, 50, 100, 250, 500)
PRICE = {"reset": 5, "path": 10, "class": 25, "luck": 1}      # rest skips cost 1 star each, 1..100 at a time; autofarm runs on skips, not sold
_pc = {r[1] for r in db.execute("PRAGMA table_info(players)")}
for col, decl in [("stars", "INTEGER DEFAULT 0"), ("skips", "INTEGER DEFAULT 0"), ("class_changes", "INTEGER DEFAULT 0"), ("autofarm", "INTEGER DEFAULT 0")]:
    if col not in _pc:
        db.execute(f"ALTER TABLE players ADD COLUMN {col} {decl}")
db.execute("""CREATE TABLE IF NOT EXISTS star_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, delta INTEGER,
  what TEXT, n INTEGER, ts REAL)""")
db.execute("""CREATE TABLE IF NOT EXISTS star_pay(charge TEXT PRIMARY KEY, uid INTEGER, n INTEGER, payload TEXT, ts REAL,
  refunded INTEGER DEFAULT 0)""")
db.commit()

def _stars_state(uid):
    r = db.execute("SELECT stars, skips, class_changes, autofarm FROM players WHERE id=?", (uid,)).fetchone() or (0, 0, 0, 0)
    return {"balance": r[0] or 0, "skips": r[1] or 0, "class_free": (r[2] or 0) == 0, "autofarm": bool(r[3]), "prices": PRICE,
            "packs": list(STAR_PACKS), "test": _stars_test(), "free_reset": _free_reset(uid)}

def _free_reset(uid):
    r = db.execute("SELECT v FROM kv WHERE k=?", (f"rstfree:{uid}",)).fetchone()
    fr = json.loads(r[0]) if r else None
    return fr if fr and fr.get("until", 0) > time.time() else None

def stars_get(user):
    with db_lock:
        return 200, _stars_state(user["id"])

def stars_topup(user, body):
    """TEST STUB: adds a pack without payment. Off in release (STARS_TEST=0), where only a paid invoice adds stars."""
    n = as_int(body.get("n"), 0, 100000)
    with db_lock:
        test = _stars_test()
    if not test and user["id"] not in ADMIN_IDS:
        return 403, {"ok": False, "reason": "payments"}
    if n not in STAR_PACKS:
        return 400, {"ok": False, "reason": "pack"}
    with db_lock:
        db.execute("UPDATE players SET stars=stars+? WHERE id=?", (n, user["id"]))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], n, "topup-test", n, time.time()))
        db.commit()
        st = _stars_state(user["id"])
    log.info("stars test top-up %s +%s", user["id"], n)
    return 200, dict(st, ok=True)

def stars_invoice(user, body):
    """{n}: a Telegram Stars invoice link for n stars (a pack, or exactly what a purchase is short of)."""
    n = as_int(body.get("n"), 0, STAR_INVOICE_MAX)
    if n < 1:
        return 400, {"ok": False, "reason": "pack"}
    payload = f"st:{user['id']}:{n}:{int(time.time())}"
    try:
        r = tg("createInvoiceLink", title=f"{n} звёзд для еБашни",
               description="Звёзды на счёт героя: пропуски отдыха и автофарм, удача, сброс навыков и пути.",
               payload=payload, provider_token="", currency="XTR", prices=[{"label": f"{n} звёзд", "amount": n}])
    except Exception as e:
        log.warning("createInvoiceLink: %s", e)
        return 200, {"ok": False, "reason": "tg"}
    if not r.get("ok"):
        log.warning("createInvoiceLink: %s", r)
        return 200, {"ok": False, "reason": "tg"}
    return 200, {"ok": True, "link": r["result"], "n": n}

def _star_payload(p):
    try:
        k, uid, n, _ = str(p).split(":")
        return (int(uid), int(n)) if k == "st" else None
    except Exception:
        return None

def stars_precheckout(q):
    """Telegram asks right before taking the money: the invoice must be ours and for this player. Answered within 10 s."""
    pl, fr = _star_payload(q.get("invoice_payload")), (q.get("from") or {}).get("id")
    ok = bool(pl) and pl[0] == fr and pl[1] == q.get("total_amount") and q.get("currency") == "XTR"
    if ok:
        with db_lock:
            ok = db.execute("SELECT 1 FROM players WHERE id=?", (fr,)).fetchone() is not None
    tg("answerPreCheckoutQuery", pre_checkout_query_id=q["id"], ok=ok,
       **({} if ok else {"error_message": "Не получилось оформить покупку. Открой игру заново и попробуй ещё раз."}))

def stars_paid(msg):
    """The money is taken: the stars go on the player's account, once per charge id."""
    sp, fr = msg["successful_payment"], (msg.get("from") or {}).get("id")
    pl, charge = _star_payload(sp.get("invoice_payload")), sp.get("telegram_payment_charge_id")
    n = int(sp.get("total_amount") or 0)
    if not pl or not charge or sp.get("currency") != "XTR":
        log.warning("strange payment %s from %s", sp, fr)
        return
    uid = pl[0]
    with db_lock:
        if db.execute("SELECT 1 FROM star_pay WHERE charge=?", (charge,)).fetchone():
            return
        db.execute("INSERT INTO star_pay(charge, uid, n, payload, ts) VALUES(?,?,?,?,?)", (charge, uid, n, sp.get("invoice_payload"), time.time()))
        db.execute("UPDATE players SET stars=stars+? WHERE id=?", (n, uid))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, n, "topup", n, time.time()))
        partner_credit(uid, n)
        db.commit()
    log.info("stars paid: %s +%s (%s)", uid, n, charge)
    try:
        tg("sendMessage", chat_id=msg["chat"]["id"], text=f"Оплата прошла: +{n} ★ на счёт героя. Возвращайся в башню!",
           reply_markup={"inline_keyboard": [[{"text": "Войти в башню", "web_app": {"url": WEBAPP_URL}}]]})
    except Exception as e:
        log.info("paid note: %s", e)

def refund_command(msg):
    """Owners: /refund <charge id> — gives the Telegram Stars back and takes the stars off the account (it may go below 0)."""
    if (msg.get("from") or {}).get("id") not in ADMIN_IDS:
        return
    parts, chat = (msg.get("text") or "").split(), msg["chat"]["id"]
    if len(parts) < 2:
        with db_lock:
            rows = db.execute("SELECT charge, uid, n, ts, refunded FROM star_pay ORDER BY ts DESC LIMIT 50").fetchall()
        lines = [f"{time.strftime('%d.%m %H:%M', time.localtime(r[3]))} · id {r[1]} · {r[2]} ★{' · возврат' if r[4] else ''}\n{r[0]}" for r in rows]
        # a Telegram message holds 4096 characters: 50 purchases go out in several messages
        parts, cur = [], "Последние покупки звёзд (до 50):"
        for ln in lines or ["пока нет"]:
            if len(cur) + len(ln) + 2 > 3800:
                parts.append(cur)
                cur = ""
            cur += "\n\n" + ln
        parts.append(cur + "\n\nВернуть: /refund <id платежа>")
        for t in parts:
            tg("sendMessage", chat_id=chat, text=t.strip())
        return
    charge = parts[1]
    with db_lock:
        r = db.execute("SELECT uid, n, refunded FROM star_pay WHERE charge=?", (charge,)).fetchone()
    if not r:
        tg("sendMessage", chat_id=chat, text="Такого платежа нет.")
        return
    if r[2]:
        tg("sendMessage", chat_id=chat, text="Этот платёж уже возвращён.")
        return
    res = tg("refundStarPayment", user_id=r[0], telegram_payment_charge_id=charge)
    if not res.get("ok"):
        tg("sendMessage", chat_id=chat, text=f"Telegram не вернул: {res.get('description')}")
        return
    with db_lock:
        db.execute("UPDATE star_pay SET refunded=1 WHERE charge=?", (charge,))
        db.execute("UPDATE players SET stars=stars-? WHERE id=?", (r[1], r[0]))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (r[0], -r[1], "refund", r[1], time.time()))
        partner_credit(r[0], -r[1])
        db.commit()
    tg("sendMessage", chat_id=chat, text=f"Вернул {r[1]} ★ игроку {r[0]}.")

def stars_buy(user, body):
    """{item: skips (n 1..100) | reset | path | class | luck}. Takes the stars and gives the right; the game applies it."""
    item, uid = str(body.get("item", "")), user["id"]
    with db_lock:
        r = db.execute("SELECT stars, skips, class_changes FROM players WHERE id=?", (uid,)).fetchone() or (0, 0, 0)
        bal = r[0] or 0
        n = 1
        if item == "skips":
            n = as_int(body.get("n"), 1, 100)
            cost = n
        elif item == "class":
            cost = 0 if (r[2] or 0) == 0 else PRICE["class"]
        elif item == "reset":
            # «Умения» and «Мастерство» are reset apart; after a paid one the other is free for a day, once
            kind = "mastery" if body.get("kind") == "mastery" else "skills"
            k = f"rstfree:{uid}"
            fr = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
            fr = json.loads(fr[0]) if fr else None
            if fr and fr.get("kind") == kind and fr.get("until", 0) > time.time():
                cost = 0
                db.execute("DELETE FROM kv WHERE k=?", (k,))
            else:
                cost = PRICE["reset"]
                if bal >= cost:
                    db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)",
                               (k, json.dumps({"kind": "skills" if kind == "mastery" else "mastery", "until": time.time() + 86400})))
        elif item in PRICE:
            cost = PRICE[item]
        else:
            return 400, {"ok": False, "reason": "item"}
        if bal < cost:
            return 200, dict(_stars_state(uid), ok=False, reason="balance", need=cost)
        db.execute("UPDATE players SET stars=stars-? WHERE id=?", (cost, uid))
        if item == "skips":
            db.execute("UPDATE players SET skips=skips+? WHERE id=?", (n, uid))
        if item == "class":
            db.execute("UPDATE players SET class_changes=class_changes+1 WHERE id=?", (uid,))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, -cost, item, n, time.time()))
        db.commit()
        st = _stars_state(uid)
    return 200, dict(st, ok=True, item=item, n=n, cost=cost)

# ---------------------------------------------------------------- «Удача»: the shop's slot machine for stars
# The server rolls and pays: stars go out, rest skips come in here; gold, cores and items are written into the save by the
# game from the answer. Prizes are only things of the game. 2★ a spin, ×10 for 20★, no daily limit.
LUCK_TABLE = [("jack", 1), ("stars", 4), ("cherry", 5), ("bag", 5), ("pair", 45), ("none", 40)]
LUCK_SYMS = ["cherry", "bag", "star", "seven", "blade", "shield", "card", "dice"]
LUCK_LIMIT = 10**9   # no daily limit any more (kept as a number for old games that still show «left»)
_lrng = random.SystemRandom()

def _luck_one():
    x, k = _lrng.random() * 100, "none"
    for kk, w in LUCK_TABLE:
        x -= w
        if x <= 0:
            k = kk
            break
    def other(ex):
        while True:
            s = _lrng.choice(LUCK_SYMS)
            if s not in ex:
                return s
    if k == "jack":
        syms, prize = ["seven"] * 3, {"item": 4, "skips": 10}
    elif k == "stars":
        syms, prize = ["star"] * 3, {"item": 3}
    elif k == "cherry":
        syms, prize = ["cherry"] * 3, {"skips": 3}
    elif k == "bag":
        syms, prize = ["bag"] * 3, {"cores": 5}
    elif k == "pair":
        a = other([]); b = other([a]); syms = [a, a, a]; syms[_lrng.randrange(3)] = b
        prize = {"gold": 5} if _lrng.random() < 0.5 else {"cores": 1}
    else:
        a = other([]); b = other([a]); c = other([a, b]); syms = [a, b, c]; prize = {"gold": 1}
    return {"k": k, "syms": syms, "prize": prize}

def luck_spin(user, body):
    n = 10 if as_int(body.get("n"), 1, 10) >= 10 else 1
    cost, uid, day = (20 if n == 10 else 2), user["id"], day_id()
    with db_lock:
        bal = (db.execute("SELECT stars FROM players WHERE id=?", (uid,)).fetchone() or (0,))[0] or 0
        k = f"luck:{uid}:{day}"
        used = as_int((db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone() or ("0",))[0])
        if used + n > LUCK_LIMIT:
            return 200, dict(_stars_state(uid), ok=False, reason="limit", left=LUCK_LIMIT - used)
        if bal < cost:
            return 200, dict(_stars_state(uid), ok=False, reason="balance", need=cost, left=LUCK_LIMIT - used)
        res = [_luck_one() for _ in range(n)]
        skips = sum(r["prize"].get("skips", 0) for r in res)
        db.execute("UPDATE players SET stars=stars-?, skips=skips+? WHERE id=?", (cost, skips, uid))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, -cost, "luck", n, time.time()))
        if skips:
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, 0, "luck-skips", skips, time.time()))
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (k, str(used + n)))
        _ecr_add(uid, c=sum(r["prize"].get("cores", 0) for r in res), i=sum(1 for r in res if r["prize"].get("item")),
                 u=sum(r["prize"].get("gold", 0) for r in res))
        db.commit()
        st = _stars_state(uid)
    if any(r["k"] == "jack" for r in res):
        log.info("luck jackpot for %s", uid)
    return 200, dict(st, ok=True, results=res, cost=cost, left=LUCK_LIMIT - used - n)

def luck_info(user):
    with db_lock:
        used = as_int((db.execute("SELECT v FROM kv WHERE k=?", (f"luck:{user['id']}:{day_id()}",)).fetchone() or ("0",))[0])
    return 200, {"left": LUCK_LIMIT - used, "limit": LUCK_LIMIT}

def stars_skip(user, body=None):
    """One bought rest skip is used: the hero may fight right now.
    v216: the game sends a one-time key {n}; the same key again (a retry after a lost answer) is answered «ok» without a
    second charge. Skips have their own rate limit (autofarm catching up spends one a second), apart from the general one."""
    uid, key = user["id"], str((body or {}).get("n") or "")[:40]
    if not rate_ok(uid, "skip"):
        with db_lock:
            st = _stars_state(uid)
        return 200, dict(st, ok=False, reason="slow")
    with db_lock:
        if key:
            r = db.execute("SELECT v FROM kv WHERE k=?", (f"skipn:{uid}",)).fetchone()
            if r and r[0] == key:
                return 200, dict(_stars_state(uid), ok=True, again=True)
        cur = db.execute("UPDATE players SET skips=skips-1 WHERE id=? AND skips>0", (uid,))
        ok = cur.rowcount == 1
        if ok:
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, 0, "skip-used", 1, time.time()))
            if key:
                db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"skipn:{uid}", key))
        db.commit()
        st = _stars_state(uid)
    return 200, dict(st, ok=ok)

# ---------------------------------------------------------------- quests: the «Задания» tab
# Daily ones reset at midnight in AC_TZ (Moscow by default), achievements are once per player.
# Progress is counted here from what the server already knows, so a claim can't be faked from the phone.
# Rewards scale with the player's floor: G is about ten fights of gold, X about five fights of experience.
db.execute("CREATE TABLE IF NOT EXISTS quest_claims(uid INTEGER, qid TEXT, period INTEGER, ts REAL, PRIMARY KEY(uid, qid, period))")
db.commit()
QUESTS = [
    # id, daily, title, goal, reward {skips, G, X, cores}
    ("d_login",   1, "Зайти в игру",                    1,   {"skips": 1, "G": 1, "X": 1}),
    ("d_win10",   1, "Пройти 10 комнат за сегодня",     10,  {"skips": 1, "G": 2, "X": 1}),
    ("d_win30",   1, "Пройти 30 комнат за сегодня",     30,  {"skips": 2, "G": 4, "X": 2}),
    ("d_duel",    1, "Сыграть дуэль",                   1,   {"G": 2, "X": 1, "cores": 1}),
    ("d_elite5",  1, "Пройти 5 элитных этажей",         5,   {"skips": 1, "G": 3, "X": 2, "cores": 1}),
    ("d_boss2",   1, "Убить 2 боссов",                  2,   {"skips": 2, "G": 5, "X": 4, "cores": 2}),
    ("d_share",   1, "Позвать друга: кто-то зашёл по твоей ссылке", 1, {"skips": 1, "G": 2, "X": 1, "cores": 1}),
    # v239: was the one-time «a_skip10»; daily now, so buying is worth it every day (100 stays a one-time achievement)
    ("d_skip10",  1, "Купить 10 пропусков отдыха за сегодня", 10, {"skips": 5, "G": 10, "X": 3, "cores": 2}),
    ("a_invite1", 0, "Пригласить друга",                1,   {"skips": 3, "G": 5, "X": 2}),
    ("a_invite3", 0, "Пригласить трёх друзей",          3,   {"skips": 10, "G": 10, "X": 5, "cores": 3}),
    ("a_skip1",   0, "Купить пропуск отдыха",           1,   {"skips": 3, "G": 5, "X": 2, "cores": 1}),
    ("a_skip100", 0, "Купить 100 пропусков отдыха",     100, {"skips": 20, "G": 30, "X": 10, "cores": 5}),
    ("a_duel10",  0, "Выиграть 10 дуэлей",              10,  {"skips": 5, "G": 10, "X": 5, "cores": 3}),
    ("a_channel", 0, "Подписаться на канал eBashnya (@yourebashnya)", 1,   {"skips": 3, "G": 5, "X": 2, "cores": 1}),
]
QMAP = {q[0]: q for q in QUESTS}

def q_day(now=None):
    return int(((now or time.time()) + AC_TZ * 3600) // 86400)

def q_day_start(d):
    return d * 86400 - AC_TZ * 3600

def _qbase_f(uid, field):
    """Like _qbase, for another counter of the save (st.ekills, st.bkills). Caller holds db_lock."""
    k = f"qb:{uid}:{q_day()}:{field}"
    r = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    if r:
        return as_int(r[0], -10**9)
    sv = _save_of(uid)
    if not sv:
        return None
    v = as_int((sv.get("st") or {}).get(field), 0, 10**9)
    db.execute("INSERT OR IGNORE INTO kv(k, v) VALUES(?,?)", (k, str(v)))
    return v

def _qbase(uid):
    """Won fights at the start of today (from the save): the daily «rooms» quests count from here. Caller holds db_lock."""
    k = f"qb:{uid}:{q_day()}"
    r = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    if r:
        return as_int(r[0], -10**9)
    sv = _save_of(uid)
    if not sv:
        return None             # no save yet: the first one that arrives becomes the starting point
    w = as_int((sv.get("st") or {}).get("wins"), 0, 10**9)
    db.execute("INSERT OR IGNORE INTO kv(k, v) VALUES(?,?)", (k, str(w)))
    return w

def _q_reward(uid, rw):
    room = max(1, (db.execute("SELECT room FROM players WHERE id=?", (uid,)).fetchone() or (1,))[0] or 1)
    G = round((8 + room * 3.2) * 10)
    X = round((18 + room * 7 + room * room * 0.05) * 1)  # v191: one ordinary fight per unit (was 5)
    return {"skips": rw.get("skips", 0), "gold": G * rw.get("G", 0), "xp": X * rw.get("X", 0), "cores": rw.get("cores", 0)}

def _q_progress(uid):
    day = q_day()
    t0 = q_day_start(day)
    sv = _save_of(uid) or {}
    wins_now = as_int((sv.get("st") or {}).get("wins"), 0, 10**9)
    base = _qbase(uid)
    won_today = 0 if base is None else max(0, wins_now - base)
    duels_today = db.execute("""SELECT COUNT(*) FROM duels WHERE result IS NOT NULL AND done_at>=?
                                AND (from_uid=? OR to_uid=?)""", (t0, uid, uid)).fetchone()[0]
    invites = db.execute("SELECT COUNT(*) FROM players WHERE ref_by=?", (uid,)).fetchone()[0]
    bought = db.execute("SELECT COALESCE(SUM(n),0) FROM star_ledger WHERE uid=? AND what='skips'", (uid,)).fetchone()[0]
    bought_today = db.execute("SELECT COALESCE(SUM(n),0) FROM star_ledger WHERE uid=? AND what='skips' AND ts>=?", (uid, t0)).fetchone()[0]
    dw = 0
    for fu, res in db.execute("SELECT from_uid, result FROM duels WHERE result IS NOT NULL AND (from_uid=? OR to_uid=?)", (uid, uid)):
        try:
            win = json.loads(res).get("win")
        except (ValueError, AttributeError):
            continue
        if (fu == uid and win == 0) or (fu != uid and win == 1):
            dw += 1
    def today(field):
        b = _qbase_f(uid, field)
        return 0 if b is None else max(0, as_int((sv.get("st") or {}).get(field), 0, 10**9) - b)
    hits = db.execute("SELECT COUNT(*) FROM ref_hits WHERE inviter=? AND day=?", (uid, day)).fetchone()[0]
    chan = 1 if db.execute("SELECT 1 FROM kv WHERE k=?", (f"chan:{uid}",)).fetchone() else 0
    return {"d_login": 1, "d_win10": won_today, "d_win30": won_today, "d_duel": duels_today,
            "d_elite5": today("ekills"), "d_boss2": today("bkills"), "d_share": hits, "a_channel": chan,
            "a_invite1": invites, "a_invite3": invites, "a_skip1": bought, "d_skip10": bought_today, "a_skip100": bought, "a_duel10": dw}

def _q_list(uid):
    day = q_day()
    prog = _q_progress(uid)
    claimed = {(q, p) for q, p in db.execute("SELECT qid, period FROM quest_claims WHERE uid=? AND (period=? OR period=0)", (uid, day))}
    out = []
    for qid, daily, title, goal, rw in QUESTS:
        per = day if daily else 0
        n = prog.get(qid, 0)
        out.append({"id": qid, "daily": daily, "title": title, "goal": goal, "n": min(n, goal), "done": n >= goal,
                    "claimed": (qid, per) in claimed, "reward": _q_reward(uid, rw)})
        if qid == "a_channel" and n < goal:
            w = _chan_wait(uid)
            if w is not None:
                out[-1]["wait"] = w
    return {"quests": out, "resetAt": int(q_day_start(day + 1) * 1000), "wbase": _qbase(uid), "ebase": _qbase_f(uid, "ekills"), "bbase": _qbase_f(uid, "bkills")}

def quests_get(user):
    with db_lock:
        v = _q_list(user["id"])
        db.commit()
    return 200, v

CHANNEL = os.environ.get("CHANNEL", "").strip() or "@yourebashnya"

CHAN_WAIT = 300   # v219: a found subscription counts after 5 minutes and a second look — not for a tap on the link

def _chan_member(uid):
    """True / False from Telegram, None when the bot can't see the channel (it must be an admin there)."""
    try:
        if not CHANNEL:
            raise RuntimeError("CHANNEL is empty")
        r = tg("getChatMember", chat_id=CHANNEL, user_id=uid)
        if not r.get("ok"):
            raise RuntimeError(r.get("description") or "Telegram returned ok=false")
        member = r.get("result") or {}
        status = member.get("status")
        return status in ("member", "administrator", "creator") or (status == "restricted" and member.get("is_member") is True)
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode("utf-8")).get("description", str(e))
        except Exception:
            detail = str(e)
        log.warning("channel check for %s failed (CHANNEL=%r, bot must be channel admin): Telegram %s: %s",
                    uid, CHANNEL, e.code, detail)
        return None
    except Exception as e:
        log.warning("channel check for %s failed (CHANNEL=%r, bot must be channel admin): %s", uid, CHANNEL, e)
        return None

def check_channel_access():
    """Log a clear startup diagnostic when the configured channel cannot be checked."""
    if not BOT_ID:
        log.warning("channel check skipped: bot identity is not available")
        return
    try:
        r = tg("getChatMember", chat_id=CHANNEL, user_id=BOT_ID)
        if not r.get("ok"):
            raise RuntimeError(r.get("description") or "Telegram returned ok=false")
        status = (r.get("result") or {}).get("status")
        if status not in ("administrator", "creator"):
            log.error("CHANNEL check is not reliable: bot status in %r is %r; promote it to administrator",
                      CHANNEL, status)
        else:
            log.info("channel membership checks enabled for %s", CHANNEL)
    except Exception as e:
        log.error("CHANNEL check is unavailable for %r: %s; verify the channel username and make the bot an administrator",
                  CHANNEL, e)

def _chan_wait(uid):
    """Seconds left of the 5-minute check, or None. Caller holds db_lock."""
    r = db.execute("SELECT v FROM kv WHERE k=?", (f"chan_p:{uid}",)).fetchone()
    return None if not r else max(0, int(float(r[0]) + CHAN_WAIT - time.time()))

def quest_channel(user):
    """«Подписаться на канал»: the bot asks Telegram whether the player is in the channel. A subscription that is found
    starts a 5-minute wait («в процессе»); after it the bot looks again and only then the quest is done — a player who
    opened the channel and came back without subscribing, or unsubscribed at once, gets nothing."""
    uid = user["id"]
    with db_lock:
        if db.execute("SELECT 1 FROM kv WHERE k=?", (f"chan:{uid}",)).fetchone():
            return 200, {"ok": True}
    m = _chan_member(uid)
    if m is None:
        return 200, {"ok": False, "reason": "unchecked"}
    with db_lock:
        if not m:
            db.execute("DELETE FROM kv WHERE k=?", (f"chan_p:{uid}",))
            db.commit()
            return 200, {"ok": False, "reason": "not member"}
        left = _chan_wait(uid)
        if left is None:
            db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"chan_p:{uid}", str(time.time())))
            left = CHAN_WAIT
        if left > 0:
            db.commit()
            return 200, {"ok": False, "reason": "pending", "wait": left}
        db.execute("DELETE FROM kv WHERE k=?", (f"chan_p:{uid}",))
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"chan:{uid}", "1"))
        db.commit()
    return 200, {"ok": True}

def chan_loop():
    """The 5 minutes are up: look again; still subscribed — the quest is done and the bot says the reward waits,
    unsubscribed — the wait is dropped and the bot says so."""
    while True:
        time.sleep(20)
        try:
            with db_lock:
                due = [(int(k.split(":")[1]), float(v)) for k, v in db.execute("SELECT k, v FROM kv WHERE k LIKE 'chan_p:%'")
                       if float(v) + CHAN_WAIT <= time.time()]
            for uid, _ in due:
                m = _chan_member(uid)
                if m is None:
                    continue
                with db_lock:
                    db.execute("DELETE FROM kv WHERE k=?", (f"chan_p:{uid}",))
                    if m:
                        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"chan:{uid}", "1"))
                    db.commit()
                text = ("✅ Подписка на канал подтверждена! Награда за задание ждёт в игре: «Задания» → «Забрать»." if m else
                        "Подписки на канал не видно — задание «Подписаться на канал» не засчитано. Подпишись и нажми «Перейти» ещё раз.")
                try:
                    tg("sendMessage", chat_id=uid, text=text, reply_markup={"inline_keyboard": [[{"text": "Войти в башню", "web_app": {"url": WEBAPP_URL}}]]})
                except Exception as e:
                    log.info("channel note to %s not sent: %s", uid, e)
        except Exception as e:
            log.warning("chan loop: %s", e)

def quests_claim(user, body):
    qid = str(body.get("id", ""))
    q = QMAP.get(qid)
    if not q:
        return 400, {"ok": False, "reason": "quest"}
    uid = user["id"]
    if qid == "a_channel" and _chan_member(uid) is False:   # took the check and left the channel: back to the start
        with db_lock:
            db.execute("DELETE FROM kv WHERE k IN (?,?)", (f"chan:{uid}", f"chan_p:{uid}"))
            db.commit()
        return 200, {"ok": False, "reason": "left"}
    with db_lock:
        prog = _q_progress(uid)
        if prog.get(qid, 0) < q[3]:
            db.commit()
            return 200, {"ok": False, "reason": "not done"}
        per = q_day() if q[1] else 0
        cur = db.execute("INSERT OR IGNORE INTO quest_claims(uid, qid, period, ts) VALUES(?,?,?,?)", (uid, qid, per, time.time()))
        if cur.rowcount != 1:
            db.commit()
            return 200, {"ok": False, "reason": "claimed"}
        rw = _q_reward(uid, q[4])
        _ecr_add(uid, g=rw["gold"], c=rw["cores"])
        if rw["skips"]:
            db.execute("UPDATE players SET skips=skips+? WHERE id=?", (rw["skips"], uid))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (uid, 0, "quest-skips:" + qid, rw["skips"], time.time()))
        db.commit()
        v = _q_list(uid)
        st = _stars_state(uid)
        db.commit()
    return 200, dict(v, ok=True, id=qid, reward=rw, stars=st)


# ---------------------------------------------------------------- GROUP BOSS: 2–4 heroes against one boss, gathered by a link
# Boss levels 5, 10, 15, 20, then every 15 (must match the game). A hero may fight a boss from 2 levels below to 5 above it
# (from the 20th boss on: 5 below, 9 above); the boss is as strong as the group's average level within that range.
# Each boss level pays once a day per player (a lost fight does not use it up). The fight is computed here by the game's engine;
# everyone sees the same replay, and the reward waits on the server until the player picks it up.
GR_MAX, GR_TTL = 4, 2 * 3600
db.execute("""CREATE TABLE IF NOT EXISTS gr_lobby(id TEXT PRIMARY KEY, b INTEGER, host INTEGER, members TEXT, created REAL,
  status TEXT DEFAULT 'open', result TEXT, done_at REAL)""")
db.execute("""CREATE TABLE IF NOT EXISTS gr_claims(uid INTEGER, b INTEGER, day INTEGER, lobby TEXT, reward TEXT, claimed INTEGER DEFAULT 0,
  PRIMARY KEY(uid, b, day))""")
db.execute("CREATE INDEX IF NOT EXISTS gr_lobby_host ON gr_lobby(host, created)")
try:
    db.execute("ALTER TABLE gr_lobby ADD COLUMN public INTEGER DEFAULT 0")   # an open group anyone of a fitting level can find
except sqlite3.OperationalError:
    pass
db.commit()

def gr_levels(up_to):
    a = [5, 10, 15]
    b = 20
    while b <= up_to:
        a.append(b)
        b += 15
    return [x for x in a if x <= up_to]

def gr_lo(b):
    return 2 if b <= 15 else 5

def gr_hi(b):
    return 5 if b <= 15 else 9

def gr_win(b):
    return gr_hi(b)

def gr_for(lv):
    """From 2 levels below the boss to 5 above (from the 20th boss: 5 below, 9 above). Must match the game."""
    return [b for b in gr_levels(lv + 10) if b - gr_lo(b) <= lv <= b + gr_hi(b)]

# ---- telling players of a fitting level about an open group (v194)
GR_NAMES = ["Король Скелетов", "Королева пауков", "Огненный повелитель", "Минотавр", "Лич", "Король Пепла", "Призрак Принцессы",
            "Повелитель бездны", "Идейный", "Андре Охевич", "Павол Дерув"]          # the game's GR_TYPES order
GR_NOTE_MAX = 40             # players told about one group
GR_NOTE_GAP = 1800           # one player hears about a group at most once in 30 minutes…
GR_NOTE_DAY = 5              # …and five times a day
def gr_boss_name(b):
    return GR_NAMES[(len(gr_levels(b)) - 1) % len(GR_NAMES)]

def _gr_pick_note(L):
    """Who to tell (called under db_lock): fitting level, wrote to the bot, seen in the last week, not muted, not over the limits."""
    now, b = time.time(), L["b"]
    lo, hi = b - gr_lo(b), b + gr_hi(b)
    today = q_day()
    out = []
    rows = db.execute("""SELECT id FROM players WHERE can_pm=1 AND flagged=0 AND level BETWEEN ? AND ? AND seen>?
                         ORDER BY seen DESC LIMIT 400""", (lo, hi, now - 7 * 86400)).fetchall()
    for (pid,) in rows:
        if len(out) >= GR_NOTE_MAX:
            break
        if pid in L["members"] or db.execute("SELECT 1 FROM kv WHERE k=?", (f"grmute:{pid}",)).fetchone():
            continue
        c = db.execute("SELECT v FROM kv WHERE k=?", (f"grnc:{pid}",)).fetchone()
        c = json.loads(c[0]) if c else {"t": 0, "d": 0, "n": 0}
        if now - c.get("t", 0) < GR_NOTE_GAP or (c.get("d") == today and c.get("n", 0) >= GR_NOTE_DAY):
            continue
        lv, sv = _gr_level(pid)
        if not sv or b not in gr_for(lv) or _gr_won_today(pid, b):
            continue
        n = c.get("n", 0) + 1 if c.get("d") == today else 1
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"grnc:{pid}", json.dumps({"t": now, "d": today, "n": n})))
        out.append(pid)
    return out

def _gr_send_note(gid, b, host_name, free, who):
    text = (f"👥 {host_name} собирает группу на босса «{gr_boss_name(b)}» ({b} ур.).\n"
            f"Свободно мест: {free} из {GR_MAX}. Награда — по вкладу в урон.")
    kb = {"inline_keyboard": [[{"text": "⚔️ Вступить в группу", "url": app_link("gr_" + gid)}],
                              [{"text": "🔕 Не присылать о группах", "callback_data": "grm:off"}]]}
    sent = []
    for pid in who:
        r = tg_try("sendMessage", chat_id=pid, text=text, reply_markup=kb)
        if r and r.get("ok"):
            sent.append([pid, r["result"]["message_id"]])
        elif r and r.get("error_code") == 403:  # blocked the bot: stop writing to him
            with db_lock:
                db.execute("UPDATE players SET can_pm=0 WHERE id=?", (pid,))
                db.commit()
        time.sleep(0.05)                       # Telegram allows about 30 messages a second
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"grmsg:{gid}", json.dumps(sent)))
        db.commit()

def gr_note_done(gid, why):
    """The group went into battle or closed: the invitations lose their button."""
    with db_lock:
        r = db.execute("SELECT v FROM kv WHERE k=?", (f"grmsg:{gid}",)).fetchone()
        if not r:
            return
        db.execute("DELETE FROM kv WHERE k=?", (f"grmsg:{gid}",))
        db.commit()
    for pid, mid in json.loads(r[0]):
        tg_try("editMessageText", chat_id=pid, message_id=mid, text=why)
        time.sleep(0.05)

def gr_mute_callback(cq):
    uid, on = cq["from"]["id"], (cq.get("data") or "") == "grm:on"
    with db_lock:
        if on:
            db.execute("DELETE FROM kv WHERE k=?", (f"grmute:{uid}",))
        else:
            db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"grmute:{uid}", "1"))
        db.commit()
    tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Снова буду звать в группы" if on else "Больше не буду звать в группы")
    m = cq.get("message") or {}
    if m:
        btn = {"text": "🔔 Звать в группы снова", "callback_data": "grm:on"} if not on else {"text": "🔕 Не присылать о группах", "callback_data": "grm:off"}
        rows = [r for r in ((m.get("reply_markup") or {}).get("inline_keyboard") or []) if not any(str(x.get("callback_data", "")).startswith("grm:") for x in r)]
        tg_try("editMessageReplyMarkup", chat_id=m["chat"]["id"], message_id=m["message_id"], reply_markup={"inline_keyboard": rows + [[btn]]})

GR_BOT = 10**12
def _gr_save_of(m, host=None):
    """A test bot (admins only) has a negative id: -uid fights as a copy of that player's hero, below -GR_BOT as the host's."""
    if m >= 0:
        return _save_of(m)
    return _save_of(host) if -m >= GR_BOT else _save_of(-m)

def _gr_level(uid):
    sv = _save_of(uid)
    return (as_int(sv.get("level"), 1, 100000) if sv else 0), sv

# v244: «once a day» for group bosses and the chat boss's tries counts Moscow days (q_day), like the quests;
# with UTC days a boss beaten at 01:00 MSK could be beaten again the same evening
def _gr_won_today(uid, b):
    return db.execute("SELECT 1 FROM gr_claims WHERE uid=? AND b=? AND day=?", (uid, b, q_day())).fetchone() is not None

def _gr_row(gid):
    r = db.execute("SELECT id, b, host, members, created, status, result, done_at, public FROM gr_lobby WHERE id=?", (gid,)).fetchone()
    if not r:
        return None
    try:
        mem = json.loads(r[3] or "[]")
    except ValueError:
        mem = []
    return {"id": r[0], "b": r[1], "host": r[2], "members": mem, "created": r[4], "status": r[5], "result": r[6], "done_at": r[7], "public": r[8] or 0}

def _gr_view(L, uid, full=False):
    cards = []
    for m in L["members"]:
        sv = _gr_save_of(m, L["host"])
        src = m if m >= 0 else (L["host"] if -m >= GR_BOT else -m)
        c = _card(src, sv) if sv else {"name": "Игрок", "cls": "knight", "level": 1, "look": {"cls": "knight"}}
        if m < 0:
            c["name"] = "Бот · " + str(c.get("name", "Игрок"))
            c["bot"] = 1
            c.pop("tag", None)
        c["uid"] = m
        c["host"] = 1 if m == L["host"] else 0
        cards.append(c)
    v = {"ok": True, "id": L["id"], "b": L["b"], "status": L["status"], "members": cards, "host": L["host"] == uid,
         "me": L["members"].index(uid) if uid in L["members"] else -1, "link": app_link("gr_" + L["id"]),
         "max": GR_MAX, "expired": L["status"] == "open" and L["created"] < time.time() - GR_TTL, "public": L.get("public", 0),
         "lo": L["b"] - gr_lo(L["b"]), "hi": L["b"] + gr_hi(L["b"])}
    if L["status"] == "done" and L["result"]:
        try:
            R = json.loads(L["result"])
        except ValueError:
            R = None
        if R:
            if not full:
                R.pop("hs", None)
            v["result"] = R
            c = db.execute("SELECT reward, claimed FROM gr_claims WHERE uid=? AND lobby=?", (uid, L["id"])).fetchone()
            if c:
                v["claimed"] = bool(c[1])
    return v

def _gr_stale_close(L, why="Создатель группы перерос этого босса — группа закрыта."):
    """Caller holds db_lock. v241: an open group whose HOST no longer fits its boss (he levelled up past it) can never
    start: close it instead of letting players keep joining a group nobody can lead."""
    db.execute("UPDATE gr_lobby SET status='closed' WHERE id=? AND status='open'", (L["id"],))
    threading.Thread(target=gr_note_done, args=(L["id"], why), daemon=True).start()
    log.info("group %s (boss %s) closed: host %s no longer fits", L["id"], L["b"], L["host"])
    return [m for m in L["members"] if m > 0 and m != L["host"]]

def gr_new(user, body):
    if not rate_ok(user["id"], "gr_new"):
        return SLOW(user["id"], "gr_new")
    uid, b = user["id"], as_int(body.get("b"), 0, 100000)
    with db_lock:
        if is_flagged(uid):
            return 200, {"ok": False, "reason": "review"}
        lv, sv = _gr_level(uid)
        if not sv:
            return 200, {"ok": False, "reason": "nosave_me"}
        if b not in gr_for(lv):
            return 200, {"ok": False, "reason": "level"}
        if _gr_won_today(uid, b):
            return 200, {"ok": False, "reason": "today"}
        # one open group per host: an old one closes
        for (og,) in db.execute("SELECT id FROM gr_lobby WHERE host=? AND status='open'", (uid,)).fetchall():
            threading.Thread(target=gr_note_done, args=(og, "Эта группа закрыта."), daemon=True).start()
        db.execute("UPDATE gr_lobby SET status='closed' WHERE host=? AND status='open'", (uid,))
        gid = base64.urlsafe_b64encode(os.urandom(6)).decode().replace("-", "x").replace("_", "y")
        db.execute("INSERT INTO gr_lobby(id, b, host, members, created) VALUES(?,?,?,?,?)", (gid, b, uid, json.dumps([uid]), time.time()))
        db.commit()
        L = _gr_row(gid)
        v = _gr_view(L, uid)
        db.commit()
    return 200, v

def gr_get(user, gid):
    with db_lock:
        L = _gr_row(str(gid)[:16])
        if not L:
            return 404, {"ok": False, "reason": "none"}
        v = _gr_view(L, user["id"], full=True)
        db.commit()
    return 200, v

def gr_join(user, body):
    if not rate_ok(user["id"], "gr_join"):
        return SLOW(user["id"], "gr_join")
    uid, gid = user["id"], str(body.get("id", ""))[:16]
    with db_lock:
        L = _gr_row(gid)
        if not L:
            return 404, {"ok": False, "reason": "none"}
        if uid in L["members"]:
            v = _gr_view(L, uid); db.commit()
            return 200, v
        if L["status"] != "open":
            return 200, {"ok": False, "reason": "started" if L["status"] == "done" else "closed"}
        if L["created"] < time.time() - GR_TTL:
            return 200, {"ok": False, "reason": "expired"}
        if len(L["members"]) >= GR_MAX:
            return 200, {"ok": False, "reason": "full"}
        if is_flagged(uid):
            return 200, {"ok": False, "reason": "review"}
        lv, sv = _gr_level(uid)
        if not sv:
            return 200, {"ok": False, "reason": "nosave_me"}
        if L["b"] not in gr_for(lv):
            return 200, {"ok": False, "reason": "level", "b": L["b"], "lv": lv}
        if _gr_won_today(uid, L["b"]):
            return 200, {"ok": False, "reason": "today"}
        hlv, _ = _gr_level(L["host"])
        if L["host"] not in L["members"]:
            db.execute("UPDATE gr_lobby SET status='closed' WHERE id=? AND status='open'", (gid,))
            db.commit()
            return 200, {"ok": False, "reason": "closed"}
        if hlv and L["b"] not in gr_for(hlv):
            left = _gr_stale_close(L)
            db.commit()
            for m in left:
                _tell(m, f"🛡 Группа на босса {L['b']} уровня закрыта: её создатель уже перерос этого босса. Собери свою!", ("Открыть игру", ""))
            return 200, {"ok": False, "reason": "closed"}
        L["members"].append(uid)
        db.execute("UPDATE gr_lobby SET members=? WHERE id=?", (json.dumps(L["members"]), gid))
        db.commit()
        if len(L["members"]) >= GR_MAX:
            threading.Thread(target=gr_note_done, args=(gid, "👥 Эта группа уже собрана."), daemon=True).start()
        v = _gr_view(L, uid)
        db.commit()
        host = L["host"]
        name = (db.execute("SELECT name FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок",))[0]
    _tell(host, f"🛡 {name} вступил в твою группу на босса {L['b']} уровня ({len(L['members'])}/{GR_MAX}).", ("🛡 Открыть группу", "gr_" + gid))
    return 200, v

def gr_leave(user, body):
    uid, gid = user["id"], str(body.get("id", ""))[:16]
    with db_lock:
        L = _gr_row(gid)
        if not L or L["status"] != "open" or uid not in L["members"]:
            return 200, {"ok": True}
        if uid == L["host"]:
            db.execute("UPDATE gr_lobby SET status='closed' WHERE id=?", (gid,))
            threading.Thread(target=gr_note_done, args=(gid, "Эта группа закрыта."), daemon=True).start()
        else:
            L["members"].remove(uid)
            db.execute("UPDATE gr_lobby SET members=? WHERE id=?", (json.dumps(L["members"]), gid))
        db.commit()
    return 200, {"ok": True}

def gr_kick(user, body):
    if not rate_ok(user["id"], "gr_kick"):
        return SLOW(user["id"], "gr_kick")
    uid, gid, who = user["id"], str(body.get("id", ""))[:16], as_int(body.get("uid"), -10**15, 10**15)
    with db_lock:
        L = _gr_row(gid)
        if not L or L["status"] != "open" or uid != L["host"] or who == uid or who not in L["members"]:
            return 200, {"ok": False}
        L["members"].remove(who)
        db.execute("UPDATE gr_lobby SET members=? WHERE id=?", (json.dumps(L["members"]), gid))
        db.commit()
        v = _gr_view(L, uid)
        db.commit()
    return 200, v

def gr_bot(user, body):
    """Admins only, for testing: a bot joins the group as a copy of a real hero of a fitting level (or of the host)."""
    uid, gid = user["id"], str(body.get("id", ""))[:16]
    if uid not in ADMIN_IDS:
        return 403, {"ok": False, "reason": "admin"}
    with db_lock:
        L = _gr_row(gid)
        if not L or L["status"] != "open" or uid != L["host"]:
            return 200, {"ok": False, "reason": "closed"}
        if len(L["members"]) >= GR_MAX:
            return 200, {"ok": False, "reason": "full"}
        taken = {abs(m) for m in L["members"]}
        lo, hi = L["b"] - gr_lo(L["b"]), L["b"] + gr_hi(L["b"])
        rows = db.execute("SELECT p.id FROM players p JOIN saves s ON s.uid=p.id WHERE p.level BETWEEN ? AND ? ORDER BY RANDOM() LIMIT 40", (lo, hi)).fetchall()
        bot = None
        for (pid,) in rows:
            if pid in taken:
                continue
            lv, sv = _gr_level(pid)
            if sv and lo <= lv <= hi:
                bot = -pid
                break
        if bot is None:
            n = sum(1 for m in L["members"] if m <= -GR_BOT)
            bot = -(GR_BOT + n + 1)
        L["members"].append(bot)
        db.execute("UPDATE gr_lobby SET members=? WHERE id=?", (json.dumps(L["members"]), gid))
        db.commit()
        v = _gr_view(L, uid)
        db.commit()
    return 200, v

def gr_public(user, body):
    """The host shows the group to everyone of a fitting level (or hides it again)."""
    if not rate_ok(user["id"], "gr_public"):
        return SLOW(user["id"], "gr_public")
    uid, gid, on = user["id"], str(body.get("id", ""))[:16], 1 if body.get("on") else 0
    with db_lock:
        L = _gr_row(gid)
        if not L or L["status"] != "open" or uid != L["host"]:
            return 200, {"ok": False, "reason": "closed"}
        db.execute("UPDATE gr_lobby SET public=? WHERE id=?", (on, gid))
        db.commit()
        L["public"] = on
        v = _gr_view(L, uid)
        who, host_name = [], ""
        if on and not db.execute("SELECT 1 FROM kv WHERE k=?", (f"grn:{gid}",)).fetchone() and len(L["members"]) < GR_MAX:
            if rate_ok(uid, "gr_notify"):
                db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (f"grn:{gid}", "1"))
                who = _gr_pick_note(L)
                host_name = (db.execute("SELECT name FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок",))[0]
            else:
                v["notify_wait"] = rate_wait(uid, "gr_notify")
        db.commit()
    if who:
        threading.Thread(target=_gr_send_note, args=(gid, L["b"], host_name, GR_MAX - len(L["members"]), who), daemon=True).start()
    v["notified"] = len(who)
    return 200, v

def gr_list(user):
    """Open groups anyone may join: only bosses that fit the asker's level, not full, not his own, not one he beat today."""
    uid, day = user["id"], q_day()
    with db_lock:
        lv, _ = _gr_level(uid)
        fit = set(gr_for(lv)) if lv else set()
        won = {r[0] for r in db.execute("SELECT b FROM gr_claims WHERE uid=? AND day=?", (uid, day))}
        out = []
        for r in db.execute("SELECT id FROM gr_lobby WHERE public=1 AND status='open' AND created>? ORDER BY created DESC LIMIT 200",
                            (time.time() - GR_TTL,)).fetchall():
            L = _gr_row(r[0])
            if not L or L["b"] not in fit or L["b"] in won or uid in L["members"] or len(L["members"]) >= GR_MAX:
                continue
            hp = db.execute("SELECT name FROM players WHERE id=?", (L["host"],)).fetchone()
            hsv = _save_of(L["host"]) or {}
            if hsv and L["b"] not in gr_for(as_int(hsv.get("level"), 1, 100000)):
                continue                      # v241: its host outgrew the boss — nobody could start it
            if L["host"] not in L["members"]:  # v244: a group whose host is gone (dropped at the start) can never start
                db.execute("UPDATE gr_lobby SET status='closed' WHERE id=? AND status='open'", (L["id"],))
                continue
            out.append({"id": L["id"], "b": L["b"], "n": len(L["members"]), "host": hp[0] if hp else "Игрок",
                        "hlv": as_int(hsv.get("level"), 1, 100000), "hcls": str(hsv.get("cls", "knight"))[:16]})
            if len(out) >= 50:
                break
        db.commit()
    return 200, {"ok": True, "level": lv, "groups": out}

def gr_start(user, body):
    if not rate_ok(user["id"], "gr_start"):
        return SLOW(user["id"], "gr_start")
    uid, gid = user["id"], str(body.get("id", ""))[:16]
    with db_lock:
        L = _gr_row(gid)
        if not L:
            return 404, {"ok": False, "reason": "none"}
        if L["status"] == "done":
            v = _gr_view(L, uid, full=True); db.commit()
            return 200, v
        if L["status"] != "open":
            return 200, {"ok": False, "reason": "closed"}
        if uid != L["host"]:
            return 200, {"ok": False, "reason": "nothost"}
        if len(L["members"]) < 2:
            return 200, {"ok": False, "reason": "few"}
        saves, drop = [], []
        for m in L["members"]:
            if m < 0:
                sv = _gr_save_of(m, L["host"])
                (saves.append(sv) if sv else drop.append(m))
                continue
            lv, sv = _gr_level(m)
            if not sv or L["b"] not in gr_for(lv) or _gr_won_today(m, L["b"]) or is_flagged(m):
                drop.append(m)
            else:
                saves.append(sv)
        if L["host"] in drop:      # v244: the host himself can't fight it (beaten today / outgrew it): close, not a headless group
            db.execute("UPDATE gr_lobby SET status='closed' WHERE id=? AND status='open'", (gid,))
            db.commit()
            threading.Thread(target=gr_note_done, args=(gid, "Эта группа закрыта."), daemon=True).start()
            others = [m for m in L["members"] if m > 0 and m != uid]
            for m in others:
                _tell(m, f"🛡 Группа на босса {L['b']} уровня закрыта: её создатель не может биться с этим боссом сегодня. Собери свою!", ("Открыть игру", ""))
            return 200, {"ok": False, "reason": "hostout"}
        if drop:
            L["members"] = [m for m in L["members"] if m not in drop]
            db.execute("UPDATE gr_lobby SET members=? WHERE id=?", (json.dumps(L["members"]), gid))
            db.commit()
            return 200, {"ok": False, "reason": "dropped", "n": len(drop)}
        db.execute("UPDATE gr_lobby SET status='fighting' WHERE id=? AND status='open'", (gid,))
        db.commit()
        seed = _seed("gr" + gid)
        R = engine({"mode": "gr", "saves": saves, "b": L["b"], "seed": seed})
        if not R:
            db.execute("UPDATE gr_lobby SET status='open' WHERE id=?", (gid,))
            db.commit()
            return 200, {"ok": False, "reason": "engine"}
        R["b"], R["seed"], R["uids"] = L["b"], seed, L["members"]
        R["cards"] = [{"name": c["name"], "cls": c["cls"], "level": c["level"], "look": c["look"]} for c in _gr_view(L, uid)["members"]]
        rws = R.pop("rewards", None) or []
        day = q_day()
        if any(m < 0 for m in L["members"]):
            R["test"] = 1          # a fight with test bots: no reward and the boss is not marked as beaten today
        if R.get("win") and not R.get("test"):
            for i, m in enumerate(L["members"]):
                if m < 0:
                    continue
                rw = rws[i] if i < len(rws) else {"gold": 0}
                db.execute("INSERT OR IGNORE INTO gr_claims(uid, b, day, lobby, reward, claimed) VALUES(?,?,?,?,?,0)",
                           (m, L["b"], day, gid, json.dumps(rw)))
        R["rewards"] = rws if R.get("win") and not R.get("test") else []
        db.execute("UPDATE gr_lobby SET status='done', result=?, done_at=? WHERE id=?", (json.dumps(R), time.time(), gid))
        db.commit()
        threading.Thread(target=gr_note_done, args=(gid, "⚔️ Эту группу уже собрали — она ушла в бой."), daemon=True).start()
        L = _gr_row(gid)
        v = _gr_view(L, uid, full=True)
        db.commit()
        members = list(L["members"])
    for m in members:
        if m != uid and m > 0:
            _tell(m, f"🛡 Группа вышла на босса {L['b']} уровня — " + ("победа! Открой игру, чтобы посмотреть бой и забрать награду." if R.get("win") else "босс оказался сильнее. Соберитесь ещё раз!"), ("🛡 Посмотреть бой", "gr_" + L["id"]))
    return 200, v

def gr_claim(user, body):
    uid, gid = user["id"], str(body.get("id", ""))[:16]
    with db_lock:
        r = db.execute("SELECT reward, claimed FROM gr_claims WHERE uid=? AND lobby=?", (uid, gid)).fetchone()
        if not r:
            return 200, {"ok": False, "reason": "none"}
        if r[1]:
            return 200, {"ok": False, "reason": "claimed"}
        cur = db.execute("UPDATE gr_claims SET claimed=1 WHERE uid=? AND lobby=? AND claimed=0", (uid, gid))
        db.commit()
        if cur.rowcount != 1:
            return 200, {"ok": False, "reason": "claimed"}
        try:
            rw = json.loads(r[0] or "{}")
        except ValueError:
            rw = {}
        if isinstance(rw, dict):
            _ecr_add(uid, g=as_int(rw.get("gold"), 0, 10**12), c=as_int(rw.get("core"), 0, 10**6), i=1 if rw.get("item") else 0)
            db.commit()
    return 200, {"ok": True, "id": gid, "reward": rw}

def gr_mine(user):
    uid, day = user["id"], q_day()
    with db_lock:
        done = [r[0] for r in db.execute("SELECT b FROM gr_claims WHERE uid=? AND day=?", (uid, day))]
        rows = db.execute("SELECT id FROM gr_lobby WHERE created>? AND status IN ('open','fighting','done') AND members LIKE ? ORDER BY created DESC LIMIT 20",
                          (time.time() - 2 * 86400, f"%{uid}%")).fetchall()
        open_, fresh, stale_tell = [], [], []
        mylv = _gr_level(uid)[0]
        for (gid,) in rows:
            L = _gr_row(gid)
            if not L or uid not in L["members"]:
                continue
            # keep 'fighting' in open: otherwise a refresh mid-fight clears the bar and cancels
            # the member's watch loop, and they never get the «Подключиться» offer
            if L["status"] in ("open", "fighting") and L["created"] > time.time() - GR_TTL:
                if L["status"] == "open" and L["host"] == uid and mylv and L["b"] not in gr_for(mylv):
                    for m in _gr_stale_close(L, "Создатель группы перерос этого босса — группа закрыта."):
                        stale_tell.append((m, L["b"]))
                    continue
                open_.append({"id": gid, "b": L["b"], "n": len(L["members"]), "host": L["host"] == uid,
                              "fighting": 1 if L["status"] == "fighting" else 0, "created": int(L["created"] * 1000)})
            elif L["status"] == "done":
                c = db.execute("SELECT claimed FROM gr_claims WHERE uid=? AND lobby=?", (uid, gid)).fetchone()
                try:
                    R = json.loads(L["result"] or "{}")
                except ValueError:
                    R = {}
                fresh.append({"id": gid, "b": L["b"], "win": bool(R.get("win")), "test": 1 if R.get("test") else 0, "unclaimed": bool(c and not c[0]), "at": L["done_at"]})
        lv, _ = _gr_level(uid)
        db.commit()
    for m, b in stale_tell:
        _tell(m, f"🛡 Группа на босса {b} уровня закрыта: её создатель уже перерос этого босса. Собери свою!", ("Открыть игру", ""))
    return 200, {"ok": True, "done": done, "open": open_, "recent": fresh[:8], "level": lv, "bosses": gr_for(lv) if lv else []}


# ---------------------------------------------------------------- NFT: a very rare drop from a beaten tower boss
# The roll is made here, never on the phone. The owner hands the NFTs out himself: the player presses «Вывести»
# in «Мои награды», the bot tells the owners, they send the gift and press «Выдал» under that message.
db.execute("""CREATE TABLE IF NOT EXISTS nft_drops(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, name TEXT, room INTEGER,
              ts REAL, status TEXT DEFAULT 'new', req_ts REAL, done_ts REAL)""")
if "link" not in [c[1] for c in db.execute("PRAGMA table_info(nft_drops)")]:
    db.execute("ALTER TABLE nft_drops ADD COLUMN link TEXT")
db.commit()
NFT_RATE_DEFAULT = 0.01          # percent per beaten boss: one boss in 10 000
NFT_POOL_DEFAULT = ["NFT еБашни"]
NFT_FLOOR = 250                  # only bosses from this floor up can drop one (250, 300, 350…)
NFT_GAP = 15                     # seconds between two counted bosses of one player (a boss fight is longer than that)
NFT_DAY_CAP = 300                # bosses a day that can roll at all
NFT_ST = {"new": "получено", "pending": "на выводе", "done": "выдано", "rejected": "отклонено"}

def _kv_get(k, dflt=None):
    r = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    return r[0] if r else dflt

def _kv_set(k, v):
    db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (k, str(v)))

def nft_rate():
    try:
        return max(0.0, min(100.0, float(_kv_get("nft:rate", NFT_RATE_DEFAULT))))
    except ValueError:
        return NFT_RATE_DEFAULT

def nft_cap():
    return as_int(_kv_get("nft:cap", NFT_DAY_CAP), 1, 10**6)

def nft_pool():
    try:
        p = json.loads(_kv_get("nft:pool", "null") or "null") or []
        return [str(x)[:300] for x in p if str(x).strip()] or NFT_POOL_DEFAULT
    except (ValueError, TypeError):
        return NFT_POOL_DEFAULT

def _nft_split(entry):
    """«Plush Pepe | https://t.me/nft/PlushPepe-1» → name and the gift's page (the link is optional)."""
    name, _, link = str(entry).partition("|")
    link = link.strip()
    return name.strip()[:60], (link if link.startswith("https://") else "")

def _nft_row(r):
    return {"id": r[0], "name": r[1], "room": r[2], "ts": int(r[3] * 1000), "status": r[4], "st": NFT_ST.get(r[4], r[4]), "link": r[5] or ""}

def _nft_list(uid):
    return [_nft_row(r) for r in db.execute("SELECT id, name, room, ts, status, link FROM nft_drops WHERE uid=? ORDER BY id DESC", (uid,))]

def _admins_tell(text, markup=None):
    for a in ADMIN_IDS:
        tg_try("sendMessage", chat_id=a, text=text, parse_mode="HTML", disable_web_page_preview=True, **({"reply_markup": markup} if markup else {}))

def _who(uid):
    r = db.execute("SELECT name, username, room FROM players WHERE id=?", (uid,)).fetchone() or ("Игрок", None, 0)
    return f"{mention(uid, r[0], r[1])} (id <code>{int(uid)}</code>, этаж {r[2] or 0})"

def _nft_give(uid, room, why, pick=None):
    """Caller holds db_lock. Records one NFT and returns it."""
    name, link = pick or _nft_split(random.choice(nft_pool()))
    now = time.time()
    cur = db.execute("INSERT INTO nft_drops(uid, name, room, ts, link) VALUES(?,?,?,?,?)", (uid, name, room, now, link))
    db.commit()
    nid = cur.lastrowid
    who = _who(uid)
    threading.Thread(target=_admins_tell, args=(f"🎉 Выпало NFT «{html_esc(name)}» (#{nid})" + (f"\n{html_esc(link)}" if link else "") + f"\nИгрок: {who}\n{why}",), daemon=True).start()
    log.info("nft #%s %r to %s (%s)", nid, name, uid, why)
    return {"id": nid, "name": name, "room": room, "ts": int(now * 1000), "status": "new", "st": NFT_ST["new"], "link": link}

def nft_boss(user, body):
    """The game calls this after a tower boss from floor 250 is beaten for the first time on the climb (never from the farm)."""
    uid, room = user["id"], as_int(body.get("room"), 0, 10**7)
    if room < NFT_FLOOR or room % 50:
        return 200, {"ok": True, "nft": None}
    now = time.time()
    with db_lock:
        sv = _save_of(uid) or {}
        top = max(as_int(sv.get("maxCleared"), 0, 10**7), _player_room(uid) or 0)
        # only a boss beaten for the first time on the climb: each floor rolls once per player, ever (farming it again,
        # or starting over with «Новая игра», gives nothing), and it has to be the new record, not one far below it
        done = as_int(_kv_get(f"nftmax:{uid}", 0), 0, 10**7)
        if room > top + 50 or room < top // 50 * 50 or room <= done:
            return 200, {"ok": True, "nft": None}
        flagged = is_flagged(uid)
        last = float(_kv_get(f"nftlast:{uid}", 0) or 0)
        dk = f"nftn:{uid}:{q_day()}"
        n = as_int(_kv_get(dk, 0), 0, 10**9)
        if now - last < NFT_GAP or n >= nft_cap():
            return 200, {"ok": True, "nft": None}
        _kv_set(f"nftlast:{uid}", now)
        _kv_set(f"nftmax:{uid}", room)
        _kv_set(dk, n + 1)
        _kv_set("nft:rolls", as_int(_kv_get("nft:rolls", 0), 0, 10**12) + 1)
        db.commit()
        if random.random() * 100 >= nft_rate():
            return 200, {"ok": True, "nft": None}
        if flagged:
            # the anticheat has this player marked: the owner decides, the player sees nothing until then
            name, link = _nft_split(random.choice(nft_pool()))
            tok = hashlib.sha1(f"{uid}:{now}".encode()).hexdigest()[:12]
            _kv_set(f"nfg:{tok}", json.dumps({"uid": uid, "room": room, "name": name, "link": link}, ensure_ascii=False))
            db.commit()
            who = _who(uid)
            kb = {"inline_keyboard": [[{"text": "✅ Выдать всё равно", "callback_data": f"nf:g:{tok}"}, {"text": "❌ Не выдавать", "callback_data": f"nf:x:{tok}"}]]}
            threading.Thread(target=_admins_tell, args=(f"⚠️ NFT «{html_esc(name)}» выбил игрок под античитом\nИгрок: {who}\nБосс {room} этажа\n\n"
                                                        "Пока он ничего не получил. Выдать?", kb), daemon=True).start()
            log.info("nft roll won by flagged %s: %r, waiting for the owner", uid, name)
            return 200, {"ok": True, "nft": None}
        got = _nft_give(uid, room, f"Босс {room} этажа")
    return 200, {"ok": True, "nft": got}

def nft_mine(user):
    with db_lock:
        return 200, {"ok": True, "items": _nft_list(user["id"]), "rate": nft_rate()}

def nft_withdraw(user, body):
    uid, nid = user["id"], as_int(body.get("id"), 0, 10**12)
    with db_lock:
        r = db.execute("SELECT name, status FROM nft_drops WHERE id=? AND uid=?", (nid, uid)).fetchone()
        if not r:
            return 404, {"ok": False, "reason": "not found"}
        if r[1] != "new":
            return 200, {"ok": True, "items": _nft_list(uid)}
        db.execute("UPDATE nft_drops SET status='pending', req_ts=? WHERE id=?", (time.time(), nid))
        db.commit()
        who = _who(uid)
        items = _nft_list(uid)
    kb = {"inline_keyboard": [[{"text": "✅ Выдал", "callback_data": f"nf:d:{nid}"}, {"text": "❌ Отклонить", "callback_data": f"nf:r:{nid}"}]]}
    threading.Thread(target=_admins_tell, args=(f"📤 Заявка на вывод NFT «{html_esc(r[0])}» (#{nid})\nИгрок: {who}\n\n"
                                                "Отправь подарок и нажми «Выдал» — игроку придёт уведомление.", kb), daemon=True).start()
    return 200, {"ok": True, "items": items}

def nft_callback(cq):
    """nf:d:<id> — the owner handed the NFT out, nf:r:<id> — refused. The player gets a message either way."""
    me = (cq.get("from") or {}).get("id")
    if me not in ADMIN_IDS:
        tg_try("answerCallbackQuery", callback_query_id=cq["id"])
        return
    parts = (cq.get("data") or "").split(":")
    if len(parts) == 3 and parts[1] in ("g", "x"):
        with db_lock:
            raw = _kv_get(f"nfg:{parts[2]}")
            if not raw:
                tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Уже решено")
                return
            db.execute("DELETE FROM kv WHERE k=?", (f"nfg:{parts[2]}",))
            d = json.loads(raw)
            got = _nft_give(d["uid"], d["room"], "Выдано вручную (игрок под античитом)", (d["name"], d.get("link") or "")) if parts[1] == "g" else None
            db.commit()
            pm = db.execute("SELECT can_pm FROM players WHERE id=?", (d["uid"],)).fetchone()
        m = cq.get("message") or {}
        if m:
            tg_try("editMessageText", chat_id=m["chat"]["id"], message_id=m["message_id"], disable_web_page_preview=True,
                   text=(m.get("text") or "") + ("\n\n✅ Выдано" if got else "\n\n❌ Не выдано"))
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Выдано" if got else "Не выдаём")
        if got and pm and pm[0]:
            tg_try("sendMessage", chat_id=d["uid"], text=f"🎁 С босса тебе выпало NFT «{got['name']}»! Открой игру → «Задания» → «Мои награды» и нажми «Вывести».")
        return
    act, nid = (parts[1], as_int(parts[2], 0, 10**12)) if len(parts) == 3 else ("", 0)
    with db_lock:
        r = db.execute("SELECT uid, name, status FROM nft_drops WHERE id=?", (nid,)).fetchone()
        if not r or r[2] != "pending" or act not in ("d", "r"):
            tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Эта заявка уже закрыта")
            return
        st = "done" if act == "d" else "rejected"
        db.execute("UPDATE nft_drops SET status=?, done_ts=? WHERE id=?", (st, time.time(), nid))
        db.commit()
        pm = db.execute("SELECT can_pm FROM players WHERE id=?", (r[0],)).fetchone()
    m = cq.get("message") or {}
    if m:
        tg_try("editMessageText", chat_id=m["chat"]["id"], message_id=m["message_id"], parse_mode="HTML", disable_web_page_preview=True,
               text=html_esc(m.get("text") or "") + ("\n\n✅ Выдано" if act == "d" else "\n\n❌ Отклонено"))
    tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Отмечено")
    if pm and pm[0]:
        txt = (f"🎁 Твоё NFT «{r[1]}» отправлено! Проверь подарки в своём профиле Telegram." if act == "d"
               else f"Заявка на вывод NFT «{r[1]}» отклонена. Напиши в поддержку, если это ошибка.")
        tg_try("sendMessage", chat_id=r[0], text=txt)

def nft_command(msg):
    """/nft (or /нфт), owners only, in the bot's private chat: what dropped and to whom, and the settings.
       /nft шанс 0.01 — chance in percent per boss; /nft список A; B; C — what can drop; /nft тест — give yourself one."""
    me = (msg.get("from") or {}).get("id")
    if me not in ADMIN_IDS:
        return
    chat = msg["chat"]["id"]
    args = (msg.get("text") or "").split(None, 1)
    rest = args[1].strip() if len(args) > 1 else ""
    low = rest.lower()
    with db_lock:
        if low.startswith(("шанс", "rate")):
            try:
                v = float(rest.split(None, 1)[1].replace(",", ".").rstrip("%"))
                _kv_set("nft:rate", max(0.0, min(100.0, v)))
                db.commit()
                return tg("sendMessage", chat_id=chat, text=f"Шанс NFT с босса: {nft_rate():g}% (1 на {round(100 / nft_rate()) if nft_rate() else '∞'} боссов)")
            except (IndexError, ValueError):
                r = nft_rate()
                return tg("sendMessage", chat_id=chat, text=f"Сейчас шанс: {r:g}% за босса (1 на {round(100 / r) if r else '∞'}).\nИзменить: /nft шанс 0.01")
        if low.startswith(("лимит", "cap")):
            try:
                _kv_set("nft:cap", max(1, int(rest.split(None, 1)[1])))
                db.commit()
                return tg("sendMessage", chat_id=chat, text=f"Лимит: {nft_cap()} боссов в день на игрока, дальше шанс не проверяется")
            except (IndexError, ValueError):
                return tg("sendMessage", chat_id=chat, text="Так: /nft лимит 300")
        if low.startswith(("список", "pool")):
            names = [x.strip() for x in rest.split(None, 1)[1:][0].replace("\n", ";").split(";")] if len(rest.split(None, 1)) > 1 else []
            names = [x for x in names if x]
            if not names:
                return tg("sendMessage", chat_id=chat, text="Так: /nft список Plush Pepe; Durov's Cap | https://t.me/nft/DurovsCap-1\n"
                                                           "Через «;» — варианты (выпадают поровну), после «|» — необязательная ссылка на подарок.")
            _kv_set("nft:pool", json.dumps(names, ensure_ascii=False))
            db.commit()
            return tg("sendMessage", chat_id=chat, disable_web_page_preview=True, text="Теперь может выпасть (поровну):\n• " + "\n• ".join(
                (lambda n, l: n + (f" — {l}" if l else ""))(*_nft_split(x)) for x in names))
        if low.startswith(("тест", "test")):
            got = _nft_give(me, 0, "Тестовая выдача командой /nft тест")
            return tg("sendMessage", chat_id=chat, text=f"Выдал тебе тестовое NFT «{got['name']}» (#{got['id']}). Открой игру → Задания → «Мои награды».")
        rows = db.execute("""SELECT d.id, d.uid, d.name, d.room, d.ts, d.status, p.name, p.username FROM nft_drops d
                             LEFT JOIN players p ON p.id=d.uid ORDER BY d.id DESC""").fetchall()
        rolls = as_int(_kv_get("nft:rolls", 0), 0, 10**12)
        rate, pool = nft_rate(), nft_pool()
    when = lambda t: time.strftime("%d.%m %H:%M", time.gmtime(t + AC_TZ * 3600)) if t else "—"
    by_name, by_st = {}, {}
    for r in rows:
        by_name[r[2]] = by_name.get(r[2], 0) + 1
        by_st[r[5]] = by_st.get(r[5], 0) + 1
    head = (f"💎 <b>NFT с боссов</b>\n\nШанс: {rate:g}% за босса с {NFT_FLOOR} этажа (1 на {round(100 / rate) if rate else '∞'})\n"
            f"Может выпасть: {html_esc(', '.join(_nft_split(x)[0] for x in pool))}" + (" ⚠️ это заглушка — задай свои: /nft список" if pool == NFT_POOL_DEFAULT else "") + f"\nБоссов с бросками: {rolls} · лимит {nft_cap()} в день на игрока\n\n"
            f"Выпало всего: <b>{sum(1 for r in rows if r[3])}</b>" + (f" (и тестовых: {sum(1 for r in rows if not r[3])})" if any(not r[3] for r in rows) else "") + "\n"
            + ("".join(f"• {html_esc(k)}: {v}\n" for k, v in sorted(by_name.items(), key=lambda x: -x[1])) if rows else "")
            + f"\nЖдут вывода: <b>{by_st.get('pending', 0)}</b> · выдано: {by_st.get('done', 0)} · не выведено: {by_st.get('new', 0)}"
            + (f" · отклонено: {by_st['rejected']}" if by_st.get("rejected") else ""))
    # room 0 is what «/nft тест» gives: no boss behind it
    where = lambda room: f"с босса {room} этажа" if room else "тестовая выдача"
    lines = [f"#{r[0]} {html_esc(r[2])} — {mention(r[1], r[6], r[7])}, {where(r[3])}, {when(r[4])} · {NFT_ST.get(r[5], r[5])}" for r in rows[:40]]
    tail = ("\n\nПоследние:\n" + "\n".join(lines)) if lines else ""
    tail += "\n\nНастройки:\n/nft шанс 0.01\n/nft лимит 300\n/nft список Имя1; Имя2 | ссылка на подарок\n/nft тест — выдать себе для проверки"
    text = head + tail
    for i in range(0, len(text), 3900):
        tg("sendMessage", chat_id=chat, text=text[i:i + 3900], parse_mode="HTML", disable_web_page_preview=True)

def nft_stats_line():
    """One line for /статистика. Caller holds db_lock."""
    # SUM(status='pending') is SQLite-only: under PostgreSQL the comparison is BOOLEAN and sum() has no such overload
    n = db.execute("SELECT COUNT(*), SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) FROM nft_drops").fetchone()
    return f"NFT: выпало {n[0] or 0}, ждут вывода {n[1] or 0} (подробно: /nft)"

# ---------------------------------------------------------------- http
BOT_USERNAME = ""
BOT_ID = 0

# ---- brotli for the game page (v196): Python has no brotli of its own, Node (already here for duels) does it once per version
_br_cache, _br_busy, _br_lock = {}, set(), threading.Lock()
_BR_JS = ("const z=require('zlib');const b=[];process.stdin.on('data',d=>b.push(d));process.stdin.on('end',()=>"
          "process.stdout.write(z.brotliCompressSync(Buffer.concat(b),{params:{[z.constants.BROTLI_PARAM_QUALITY]:11}})))")
def _br_make(raw, key):
    try:
        r = subprocess.run(["node", "-e", _BR_JS], input=raw, capture_output=True, timeout=60)
        if r.returncode == 0 and r.stdout:
            with _br_lock:
                if len(_br_cache) > 20:
                    _br_cache.clear()
                _br_cache[key] = r.stdout
    except Exception as e:
        log.info("brotli: %s", e)
    finally:
        with _br_lock:
            _br_busy.discard(key)

def brotli_of(raw, key):
    """The brotli copy if it is ready; otherwise start making it in the background and answer plain (Caddy gzips that) this time."""
    with _br_lock:
        if key in _br_cache:
            return _br_cache[key]
        if key in _br_busy:
            return None
        _br_busy.add(key)
    threading.Thread(target=_br_make, args=(raw, key), daemon=True).start()
    return None

# ---------------------------------------------------------------- МАССОВАЯ БОЙНЯ (v256)
# A chat giveaway shown as one big automatic battle. The server decides everything that matters:
#   * who may join (chat member, channel subscription, N NFT gifts in the profile),
#   * the draw: secrets.SystemRandom shuffles the fighters once; the last one in that order wins (1/N each),
#   * who kills whom: mb_engine.js runs the game's own battle simulation (Node.js) with that order,
#   * the clock: every client gets the same start time and the same death log, and draws the battle with its own camera.
# The log is handed out at most MB_LOOKAHEAD seconds ahead of the battle, so nobody learns the winner early.
# The draw (order, seed) and a SHA-256 of the whole protocol are stored before the battle; a restart changes nothing.
import secrets, math, re, zlib, struct
RL.update({"mbjoin": (6, 60), "mbfighter": (40, 60)})
MB_MAX = 500
MB_PTS = 15
MB_SKPTS = 20             # v263: 20 points to spend (the tree is still level 30's)
# the class's skills a level-15 hero can take: base skills and, per path, its nodes open by level 15 (must match the game)
MB_TREE = {
    "knight":    (("bash", "guard", "holy_blade", "bastion"), {"guardian": ("p_bulwark", "p_ironskin", "p_faithwall"), "crusader": ("p_judgement", "p_zeal", "p_wrath")}),
    "mage":      (("m_bolt", "m_wave", "m_comet", "m_mind"), {"pyro": ("p_flamewave", "p_ignite", "p_inferno"), "cryo": ("p_icelance", "p_frostbite", "p_tide")}),
    "necro":     (("raise_dead", "bone_spear", "life_drain", "dark_pact"), {"bonelord": ("p_bonearmy", "p_gravepower", "p_legion"), "plague": ("p_plaguecloud", "p_rot", "p_pestilence")}),
    "gladiator": (("energy_wave", "cross_wave", "blade_dance", "crowd"), {"arena": ("p_dualstrike", "p_crowdroar", "p_champion"), "energyblade": ("p_energystorm", "p_resonance", "p_overload")}),
    "samurai":   (("k_iai", "k_cres", "k_flurry", "k_breath"), {"thunder": ("p_k_god", "p_k_static", "p_k_flash"), "moon": ("p_k_wave", "p_k_bleed", "p_k_eclipse")}),
}
MB_SKMAX = 5
MB_SKMAX3 = {"p_faithwall", "p_wrath", "p_inferno", "p_tide", "p_legion", "p_pestilence", "p_champion", "p_overload", "p_k_flash", "p_k_eclipse"}   # the third path skills: up to 3
mb_skmax = lambda k: 3 if k in MB_SKMAX3 else MB_SKMAX
def mb_build_ok(cls, path, skills):
    """The build's skills, cleaned: only this class's and this path's, each 0…5, 15 points at most. None when it can't be fixed."""
    base, paths = MB_TREE.get(cls, MB_TREE["knight"])
    if path not in paths:
        path = next(iter(paths))
    allowed = set(base) | set(paths[path])
    out = {}
    for k, v in (skills or {}).items():
        if k in allowed:
            v = int(v)
            if v < 0 or v > mb_skmax(k):
                return None
            if v:
                out[k] = v
    if sum(out.values()) > MB_SKPTS:
        return None
    return path, out
def mb_fill(cls, path, skills):
    """Points left unspent go round the skills in order: they only change how the fighter fights on the map."""
    base, paths = MB_TREE.get(cls, MB_TREE["knight"])
    order = list(base) + list(paths[path])
    left, i = MB_SKPTS - sum(skills.values()), 0
    while left > 0 and i < 400:
        k = order[i % len(order)]
        if skills.get(k, 0) < mb_skmax(k):
            skills[k] = skills.get(k, 0) + 1
            left -= 1
        i += 1
    return skills
MB_CLASSES = ("knight", "mage", "necro", "gladiator", "samurai")   # must match L.CLASS_ORDER in the game
MB_LOOKAHEAD = 12.0
MB_LEAD_IN = 12.0          # seconds between the draw and the first blow: clients load the battle
MB_ENGINE = os.path.join(HERE, "mb_engine.js")
MB_REG_MIN = (2, 5, 10, 15, 30, 60, 120, 360, 720, 1440)
MB_DELAY_MIN = (0, 1, 2, 5, 10, 15, 30, 60)
MB_TZ = 3 * 3600           # times in the chat are written in Moscow time, like the rest of the game
_mb_rng = secrets.SystemRandom()
# Telegram ids are BIGINT and times REAL DEFAULT 0 (→ DOUBLE PRECISION): the same tables work in SQLite and in PostgreSQL (db_adapter)
db.execute("""CREATE TABLE IF NOT EXISTS mb_games(id TEXT PRIMARY KEY, chat_id BIGINT, chat_title TEXT, by_uid BIGINT, title TEXT,
  prize TEXT, conds TEXT, max_n INTEGER DEFAULT 500, created REAL DEFAULT 0, reg_ends REAL DEFAULT 0, plan_at REAL DEFAULT 0,
  start_at REAL DEFAULT 0, status TEXT, n INTEGER DEFAULT 0, seed INTEGER DEFAULT 0, ord TEXT, log TEXT, hash TEXT, proto TEXT,
  winner BIGINT DEFAULT 0, post_mid BIGINT DEFAULT 0, posted INTEGER DEFAULT 0, pend INTEGER DEFAULT 0, last_post REAL DEFAULT 0,
  last_edit REAL DEFAULT 0, last_n INTEGER DEFAULT 0, finished REAL DEFAULT 0, flags TEXT)""")
db.execute("""CREATE TABLE IF NOT EXISTS mb_players(pk TEXT PRIMARY KEY, gid TEXT, uid BIGINT, name TEXT, username TEXT, cls TEXT,
  stats TEXT, joined REAL DEFAULT 0)""")
db.execute("CREATE INDEX IF NOT EXISTS mb_players_gid ON mb_players(gid)")
db.execute("CREATE TABLE IF NOT EXISTS mb_msgs(pk TEXT PRIMARY KEY, chat_id BIGINT, uid BIGINT, n INTEGER DEFAULT 0)")
db.commit()

def mb_duration(n):
    """Mirror of mbDuration in the game: 2 → 2:00, 30 → 4:00, 500 → 5:30."""
    if n <= 2:
        return 120
    if n < 30:
        return round(120 + 120 * math.log(n / 2) / math.log(15))
    return round(240 + 90 * min(1, math.log(n / 30) / math.log(500 / 30)))

def mb_timeline(n):
    """Mirror of mbTimeline: T[k] is when the k-th death is due (seconds from the first blow)."""
    D, deaths = mb_duration(n), n - 1
    if deaths <= 0:
        return 0, []
    T = [0.0] * deaths
    fin = D if n <= 2 else min(40, D * 0.12)
    T[deaths - 1] = D
    spot = min(deaths - 1, 9)
    mass = deaths - 1 - spot
    spot_end = D - fin
    spot_start = max(D * 0.7, spot_end - spot * 14) if mass else D * 0.25
    step = (spot_end - spot_start) / spot if spot else 0
    for i in range(spot):
        T[mass + i] = spot_start + step * (i + 0.5)
    a, b = 6, max(7, spot_start - 4)
    for k in range(mass):
        q = (k + 1) / mass
        u = 1 - (1 - q) ** (1 / 2.2)
        T[k] = a + u * (b - a)
    return D, T

def mb_msk(ts):
    return time.strftime("%H:%M", time.gmtime(ts + MB_TZ))

def _mb_row(gid):
    r = db.execute("SELECT id, chat_id, chat_title, by_uid, title, prize, conds, max_n, created, reg_ends, plan_at, start_at, status, n, "
                   "seed, ord, log, hash, proto, winner, post_mid, posted, pend, last_post, last_edit, last_n, finished, flags "
                   "FROM mb_games WHERE id=?", (gid,)).fetchone()
    if not r:
        return None
    keys = ("id", "chat_id", "chat_title", "by_uid", "title", "prize", "conds", "max_n", "created", "reg_ends", "plan_at", "start_at",
            "status", "n", "seed", "ord", "log", "hash", "proto", "winner", "post_mid", "posted", "pend", "last_post", "last_edit",
            "last_n", "finished", "flags")
    g = dict(zip(keys, r))
    g["conds"] = json.loads(g["conds"] or "{}")
    g["flags"] = json.loads(g["flags"] or "{}")
    return g

def _mb_count(gid):
    return db.execute("SELECT COUNT(*) FROM mb_players WHERE gid=?", (gid,)).fetchone()[0]

def mb_clean_gid(v):
    v = str(v or "")
    return v if re.fullmatch(r"[a-f0-9]{10}", v) else ""

# ---- counting messages: every message the bot sees in a group adds one (needs privacy mode off, or the bot as admin)
# ---- the chats the bot sits in: whoever is in such a chat can start a massacre there from the game, for stars
db.execute("CREATE TABLE IF NOT EXISTS mb_chats(chat_id BIGINT PRIMARY KEY, title TEXT, username TEXT, admin INTEGER, ts REAL DEFAULT 0)")
db.commit()
_mb_seen, _mb_cache_bot, _mb_cache_mem = {}, {}, {}
MB_PRICE_DEFAULT = 35

def mb_price():
    r = db.execute("SELECT v FROM kv WHERE k='mb_price'").fetchone()
    try:
        return max(0, int(r[0])) if r else MB_PRICE_DEFAULT
    except (TypeError, ValueError):
        return MB_PRICE_DEFAULT

def mb_price_set(user, body):
    """Owners: the price of a massacre in stars (0 — free)."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    try:
        n = int(body.get("price"))
    except (TypeError, ValueError):
        return 400, {"ok": False, "reason": "число"}
    if not 0 <= n <= 100000:
        return 400, {"ok": False, "reason": "от 0 до 100000"}
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES('mb_price', ?)", (str(n),))
        db.commit()
    log.info("massacre price set by %s: %s", user["id"], n)
    return 200, {"ok": True, "price": n}

def mb_chat_seen(chat, admin=None):
    """A group the bot is in (a message, a command, a change of its rights). admin: True/False when known, None — unknown."""
    if chat.get("type") not in ("group", "supergroup") or not chat.get("id"):
        return
    cid, now = chat["id"], time.time()
    if admin is None and now - _mb_seen.get(cid, 0) < 300:
        return
    _mb_seen[cid] = now
    with db_lock:
        old = db.execute("SELECT admin FROM mb_chats WHERE chat_id=?", (cid,)).fetchone()
        adm = (1 if admin else 0) if admin is not None else (old[0] if old else None)
        db.execute("INSERT OR REPLACE INTO mb_chats(chat_id, title, username, admin, ts) VALUES(?,?,?,?,?)",
                   (cid, chat.get("title") or "", chat.get("username") or "", adm, now))
        db.commit()
    if admin is not None:
        _mb_cache_bot.pop(cid, None)

def mb_count_msg(msg):          # the hook in handle_update: every group message tells us the bot is in that chat
    mb_chat_seen(msg.get("chat") or {})

_mb_bot_rights0 = bot_rights
def bot_rights(upd):
    """my_chat_member: the bot's rights in a group changed — remember whether it can run a massacre there."""
    ch, new = upd.get("chat") or {}, upd.get("new_chat_member") or {}
    st = new.get("status")
    if st in ("left", "kicked"):
        with db_lock:
            db.execute("DELETE FROM mb_chats WHERE chat_id=?", (ch.get("id"),))
            db.commit()
        _mb_cache_bot.pop(ch.get("id"), None)
    else:
        mb_chat_seen(ch, admin=st == "administrator")
    _mb_bot_rights0(upd)

def mb_bot_admin(cid):
    """Is the bot an admin of this chat? Asked of Telegram, kept 5 minutes."""
    c = _mb_cache_bot.get(cid)
    if c and time.time() - c[1] < 300:
        return c[0]
    r = tg_try("getChatMember", chat_id=cid, user_id=BOT_ID) if BOT_ID else {"ok": False}
    ok = r.get("ok") and (r.get("result") or {}).get("status") == "administrator"
    _mb_cache_bot[cid] = (ok, time.time())
    if r.get("ok") or "chat not found" in str(r.get("description", "")).lower() or "kicked" in str(r.get("description", "")).lower():
        with db_lock:
            if ok:
                db.execute("UPDATE mb_chats SET admin=1 WHERE chat_id=?", (cid,))
            else:
                db.execute("DELETE FROM mb_chats WHERE chat_id=?", (cid,)) if not r.get("ok") else db.execute("UPDATE mb_chats SET admin=0 WHERE chat_id=?", (cid,))
            db.commit()
    return ok

def mb_in_chat(cid, uid):
    """Is the player in this chat? Kept 5 minutes."""
    k = (cid, uid)
    c = _mb_cache_mem.get(k)
    if c and time.time() - c[1] < 300:
        return c[0]
    r = tg_try("getChatMember", chat_id=cid, user_id=uid)
    res = r.get("result") or {}
    ok = bool(r.get("ok")) and (res.get("status") in ("creator", "administrator", "member") or (res.get("status") == "restricted" and res.get("is_member")))
    _mb_cache_mem[k] = (ok, time.time())
    return ok

_mb_seed_at = [0]
def mb_seed_chats():
    """The chats where the boss was ever called are chats the bot sits in: they join the list too. Where the main bot relays only
    some updates to the game (a separate poller), group messages never reach us — this is how those chats are found."""
    if time.time() - _mb_seed_at[0] < 600:
        return
    _mb_seed_at[0] = time.time()
    try:
        with db_lock:
            have = {r[0] for r in db.execute("SELECT chat_id FROM mb_chats").fetchall()}
            for cid, title in db.execute("SELECT chat_id, title FROM raid_events WHERE chat_id IS NOT NULL").fetchall():
                if cid and int(cid) not in have:
                    db.execute("INSERT OR IGNORE INTO mb_chats(chat_id, title, username, admin, ts) VALUES(?,?,?,?,?)", (int(cid), title or "", "", None, 0))
                    have.add(int(cid))
            db.commit()
    except Exception as e:
        log.info("mb seed chats: %s", e)

def mb_chats(user, qs):
    """The chats where this player can start a massacre: the bot is an admin there and the player is a member.
    ?q=@name — find one more chat by its username."""
    uid = user["id"]
    q = (qs.get("q") or [""])[0].strip()
    if q:
        q = re.sub(r"^(?:https?://)?t\.me/", "@", q)
        if not q.startswith("@"):
            q = "@" + q
        if re.fullmatch(r"@[A-Za-z0-9_]{4,32}", q):
            r = tg_try("getChat", chat_id=q)
            if r.get("ok"):
                mb_chat_seen(r["result"])
    mb_seed_chats()
    with db_lock:
        rows = db.execute("SELECT chat_id, title, username FROM mb_chats WHERE admin IS NULL OR admin=1 ORDER BY ts DESC LIMIT 60").fetchall()
        busy = {r[0]: r[1] for r in db.execute("SELECT chat_id, id FROM mb_games WHERE status IN ('reg','running','pay')").fetchall()}
        st = _stars_state(uid)
    def check(row):
        return row if mb_bot_admin(row[0]) and mb_in_chat(row[0], uid) else None
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=8) as ex:
        ok = [r for r in ex.map(check, rows) if r]
    return 200, {"ok": True, "price": mb_price(), "balance": st["balance"], "test": st.get("test"),
                 "chats": [{"id": r[0], "title": r[1] or (("@" + r[2]) if r[2] else str(r[0])), "username": r[2] or "", "busy": busy.get(r[0], "")} for r in ok]}

# ---- /massacre in a group: a massacre is now made in the game; the bot shows the way there
def mb_cid_enc(cid):
    return ("n" if cid < 0 else "p") + str(abs(cid))

def mb_command(msg):
    chat = msg["chat"]
    mb_chat_seen(chat)
    with db_lock:
        busy = db.execute("SELECT id FROM mb_games WHERE chat_id=? AND status IN ('reg','running')", (chat["id"],)).fetchone()
        price = mb_price()
    if busy:
        tg_try("sendMessage", chat_id=chat["id"], text="В этом чате уже идёт массовая бойня.",
               reply_markup={"inline_keyboard": [[{"text": "⚔️ Открыть", "url": app_link("mb_" + busy[0])}]]})
        return
    tg_try("sendMessage", chat_id=chat["id"], reply_to_message_id=msg.get("message_id"), parse_mode="HTML",
           text=f"⚔️ <b>Массовая бойня</b> создаётся в игре — любым участником чата" + (f", стоит <b>{price} ★</b>." if price else ", бесплатно.")
                + ("" if mb_bot_admin(chat["id"]) else f"\n\n⚠️ Сначала сделайте @{BOT_USERNAME} админом этого чата."),
           reply_markup={"inline_keyboard": [[{"text": "⚔️ Создать бойню", "url": app_link("mbc_" + mb_cid_enc(chat["id"]))}]]})

def _mb_conds_text(c):
    out = []
    if c.get("chan"):
        out.append(f"📢 подписка на {html_esc(c['chan'])}")
    if c.get("prem"):
        out.append("💎 Telegram Premium")
    if mb_nft_need(c):
        n = mb_nft_need(c)
        out.append(f"🎁 не меньше {n} NFT-{plural_ru(n, 'подарка', 'подарков', 'подарков')} в профиле")
    return out

def mb_tgtime(ts, fallback):
    """v263: a time Telegram itself counts down in the message (Bot API 9.5 «date_time» entity, format r = «через 5 минут»).
    Old apps show the fallback text."""
    return f'<tg-time unix="{int(ts)}" format="r">{html_esc(fallback)}</tg-time>'

def _mb_announce_text(g, n):
    """The giveaway post: blocks with air between them, the important bits in bold, the fine print in a quote."""
    c = _mb_conds_text(g["conds"])
    reg, plan = mb_msk(g["reg_ends"]), mb_msk(g["plan_at"])
    now = time.time()
    bt = f"🗡 Битва в <b>{plan} МСК</b>" + (f" · {mb_tgtime(g['plan_at'], 'в ' + plan)}" if g["plan_at"] > now else "")
    rt = f"⏳ Регистрация до {reg}" + (f" · закроется {mb_tgtime(g['reg_ends'], 'в ' + reg)}" if g["reg_ends"] > now else "")
    when = f"{bt}\n{rt}" if reg != plan else bt
    return (f"⚔️ <b>{html_esc(g['title'])}</b>\n"
            f"<i>Массовая бойня: все на одной арене, выживет один</i>\n\n"
            + mb_prizes_text(g) + "\n\n"
            + when + "\n"
            + f"👥 Участников: <b>{n}</b> из {g['max_n']}\n\n"
            + ("📋 <b>Условия</b>\n" + "\n".join(c) + "\n\n" if c else "")
            + "<blockquote>Победителя выбирает честный жребий, а прокачка умений меняет шансы: от ×0,7 до ×1,5 (обычная прокачка — ×1). Класс и путь сами по себе преимущества не дают.</blockquote>")

def mb_new(user, body):
    try:
        chat_id = int(body.get("chat"))
    except (TypeError, ValueError):
        return 400, {"ok": False, "reason": "Выбери чат."}
    if not mb_bot_admin(chat_id):
        return 403, {"ok": False, "reason": f"Бот не админ в этом чате: попроси админов сделать @{BOT_USERNAME} администратором."}
    if not mb_in_chat(chat_id, user["id"]):
        return 403, {"ok": False, "reason": "Ты не состоишь в этом чате."}
    with db_lock:
        crow = db.execute("SELECT title FROM mb_chats WHERE chat_id=?", (chat_id,)).fetchone()
    t = {"t": crow[0] if crow else ""}
    title = str(body.get("title", "")).strip()[:40] or "Массовая бойня"
    raw = body.get("prizes")
    raw = [str(x) for x in raw][:10] if isinstance(raw, list) else [str(body.get("prize", ""))]
    # v271: rest skips may be a prize too, paid now with the price; the bot puts them on the winners' accounts itself
    sks = body.get("skips") if isinstance(body.get("skips"), list) else []
    sks = [as_int(x, 0, MB_SK_MAX) for x in sks[:10]]
    prizes = []
    for i in range(len(raw)):
        n, img, u = mb_prize(raw[i])
        k = sks[i] if i < len(sks) else 0
        if not n and not k:
            break
        if k:
            n = (n + " + " if n else "") + mb_sk_txt(k)
        prizes.append({"n": n[:90], "i": img, "u": u, "sk": k})
    if not prizes:
        return 400, {"ok": False, "reason": "Укажи приз."}
    try:
        mx = max(2, min(MB_MAX, int(body.get("max", MB_MAX))))
        reg = int(body.get("reg", 10))
        delay = int(body.get("delay", 0))
        nnft = max(0, min(1000, int(body.get("nft", 0) or 0)))
        places = max(1, min(10, int(body.get("places", 1) or 1)))
    except (TypeError, ValueError):
        return 400, {"ok": False, "reason": "Проверь числа."}
    if reg not in MB_REG_MIN or delay not in MB_DELAY_MIN:
        return 400, {"ok": False, "reason": "Неверное время."}
    places = min(places, mx)
    if len(prizes) < places:
        return 400, {"ok": False, "reason": f"Укажи приз для каждого места: заполнено {len(prizes)} из {places}."}
    prizes = prizes[:places]
    sk_cost = sum(p["sk"] for p in prizes)
    prize, pimg, purl = prizes[0]["n"], prizes[0]["i"], prizes[0]["u"]
    chan = str(body.get("chan", "") or "").strip()[:64]
    if chan:
        if re.fullmatch(r"[A-Za-z0-9_]{4,32}", chan):
            chan = "@" + chan
        chan = re.sub(r"^(?:https?://)?t\.me/", "@", chan)
        if not re.fullmatch(r"@[A-Za-z0-9_]{4,32}|-100\d{5,16}", chan):
            return 400, {"ok": False, "reason": "Канал пиши как @name."}
        # the bot itself must sit in the channel as an admin: only then Telegram shows it who is subscribed
        r = tg_try("getChatMember", chat_id=chan, user_id=BOT_ID) if BOT_ID else {"ok": False}
        st = ((r.get("result") or {}).get("status")) if r.get("ok") else None
        if st not in ("administrator", "creator"):
            return 400, {"ok": False, "reason": f"Бота нет среди админов канала {chan}: добавь @{BOT_USERNAME} в канал админом, иначе подписку не проверить и розыгрыш не создать."}
    if nnft:
        r = tg_try("getUserGifts", user_id=user["id"], limit=1)
        if not r.get("ok"):
            return 400, {"ok": False, "reason": "Telegram не дал боту проверить подарки, условие с NFT сейчас недоступно."}
    now = time.time()
    with db_lock:
        if db.execute("SELECT id FROM mb_games WHERE chat_id=? AND status IN ('reg','running')", (chat_id,)).fetchone():
            return 409, {"ok": False, "reason": "В этом чате уже идёт массовая бойня."}
        # the price comes off the hero's star balance; short — the game tops up exactly what is missing and comes back
        price, bal = mb_price(), (db.execute("SELECT stars FROM players WHERE id=?", (user["id"],)).fetchone() or (0,))[0] or 0
        if bal < price + sk_cost:
            return 200, {"ok": False, "reason": "balance", "need": price + sk_cost, "balance": bal}
        if price:
            db.execute("UPDATE players SET stars=stars-? WHERE id=?", (price, user["id"]))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], -price, "massacre", 1, now))
        if sk_cost:
            db.execute("UPDATE players SET stars=stars-? WHERE id=?", (sk_cost, user["id"]))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], -sk_cost, "massacre-skips", sk_cost, now))
        gid = secrets.token_hex(5)
        reg_ends = now + reg * 60
        plan_at = reg_ends + delay * 60 + (MB_LEAD_IN if delay == 0 else 0)
        db.execute("INSERT INTO mb_games(id, chat_id, chat_title, by_uid, title, prize, conds, max_n, created, reg_ends, plan_at, status, flags) "
                   "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (gid, chat_id, t.get("t", ""), user["id"], title, prize, json.dumps({"chan": chan, "nft": nnft, "prem": 1 if body.get("prem") else 0, "places": places, "prizes": prizes, "pimg": pimg, "purl": purl}),
                    mx, now, reg_ends, plan_at, "reg", json.dumps({"paid": price + sk_cost, "sk": sk_cost})))
        db.commit()
        g = _mb_row(gid)
    kb = {"inline_keyboard": [[{"text": "⚔️ Участвовать", "url": app_link("mb_" + gid)}]]}
    r = tg_try("sendMessage", chat_id=chat_id, text=_mb_announce_text(g, 0), parse_mode="HTML", reply_markup=kb)
    if not r.get("ok"):          # the post didn't go out: no massacre, the stars go back
        with db_lock:
            db.execute("UPDATE mb_games SET status='cancelled' WHERE id=?", (gid,))
            if price + sk_cost:
                db.execute("UPDATE players SET stars=stars+? WHERE id=?", (price + sk_cost, user["id"]))
                db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (user["id"], price + sk_cost, "massacre-refund", 1, time.time()))
            db.commit()
        return 200, {"ok": False, "reason": f"Бот не смог написать в чат ({r.get('description') or 'ошибка Telegram'}). Звёзды вернулись на счёт."}
    if r.get("ok") and isinstance(r.get("result"), dict):
        with db_lock:
            db.execute("UPDATE mb_games SET post_mid=? WHERE id=?", (r["result"]["message_id"], gid))
            db.commit()
        tg_try("pinChatMessage", chat_id=chat_id, message_id=r["result"]["message_id"], disable_notification=True)
    return 200, {"ok": True, "gid": gid, "cost": price + sk_cost}

MB_MEDAL = {1: "🥇", 2: "🥈", 3: "🥉"}
MB_SK_MAX = 1000          # rest skips for one place

def mb_sk_txt(k):
    k = int(k)
    w = "пропуск" if k % 10 == 1 and k % 100 != 11 else "пропуска" if 2 <= k % 10 <= 4 and not 12 <= k % 100 <= 14 else "пропусков"
    return f"{k} {w} отдыха"

def mb_sk_refund(g, k, why):
    """Caller holds db_lock. Skips nobody won (fewer fighters than places, or no battle at all) go back to the organizer as stars."""
    if k > 0:
        db.execute("UPDATE players SET stars=stars+? WHERE id=?", (k, g["by_uid"]))
        db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (g["by_uid"], k, why, k, time.time()))
def mb_prize_list(g):
    c = g["conds"]
    return c.get("prizes") or [{"n": g["prize"], "i": c.get("pimg", ""), "u": c.get("purl", "")}]
def mb_prize_html(p):
    """A prize in a chat message: plain text; a Telegram gift is a link to it."""
    return f'<a href="{html_esc(p["u"])}">{html_esc(p["n"])}</a>' if p.get("u") else html_esc(p["n"])
def mb_prizes_text(g):
    ps = mb_prize_list(g)
    if len(ps) == 1:
        return f"🏆 <b>Приз:</b> {mb_prize_html(ps[0])}"
    return "🏆 <b>Призы</b>\n" + "\n".join(f"{MB_MEDAL.get(i, f'{i}.')} {mb_prize_html(p)}" for i, p in enumerate(ps, 1))

MB_GIFT_RE = re.compile(r"(?:https?://)?(?:t\.me|telegram\.me)/nft/([A-Za-z0-9]+)-(\d+)", re.I)
def mb_prize(text):
    """The prize as typed. A Telegram gift link (t.me/nft/PlushPepe-123) brings the gift's own picture: (name, picture, link)."""
    text = text.strip()
    m = MB_GIFT_RE.search(text)
    if not m:
        return text[:60], "", ""
    slug, num = m.group(1), m.group(2)
    name = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", slug) + f" #{num}"
    rest = (text[:m.start()] + text[m.end():]).strip(" ·-—:")
    return (rest or name)[:60], f"https://nft.fragment.com/gift/{slug.lower()}-{num}.large.jpg", f"https://t.me/nft/{slug}-{num}"

def mb_nft_need(c):
    try:
        return max(0, int(c.get("nft") or 0))
    except (TypeError, ValueError):
        return 0              # a game made before v258 named a gift: no count to check

def _mb_nft_count(uid, need):
    """How many NFT (upgraded, unique) gifts are in the profile, counted up to `need`; None when Telegram doesn't answer."""
    n, off = 0, ""
    for _ in range(20):
        p = {"user_id": uid, "exclude_unlimited": True, "exclude_limited_upgradable": True,
             "exclude_limited_non_upgradable": True, "limit": 100}
        if off:
            p["offset"] = off
        r = tg_try("getUserGifts", **p)
        if not r.get("ok"):
            return None
        res = r.get("result") or {}
        n += sum(1 for og in res.get("gifts") or [] if og.get("type") == "unique")
        off = res.get("next_offset") or ""
        if n >= need or not off:
            return n
    return n

def mb_check(g, uid, user=None):
    """None when the player may join, otherwise the reason in plain words. Every check asks Telegram itself."""
    r = tg_try("getChatMember", chat_id=g["chat_id"], user_id=uid)
    st = ((r.get("result") or {}).get("status")) if r.get("ok") else None
    if not r.get("ok"):
        return "Не получилось проверить, что ты в чате розыгрыша. Попробуй ещё раз."
    if st in ("left", "kicked") or (st == "restricted" and not (r.get("result") or {}).get("is_member")):
        return "Участвовать могут только участники чата, где идёт розыгрыш."
    c = g["conds"]
    # v273: Telegram itself puts is_premium into the signed launch data, so it can't be faked from the game
    if c.get("prem") and not (user or {}).get("is_premium"):
        return "Участвовать могут только игроки с Telegram Premium."
    if c.get("chan"):
        r = tg_try("getChatMember", chat_id=c["chan"], user_id=uid)
        if not r.get("ok"):
            return "Не получилось проверить подписку на канал. Попробуй позже."
        m = r.get("result") or {}
        if not (m.get("status") in ("member", "administrator", "creator") or (m.get("status") == "restricted" and m.get("is_member"))):
            return f"Подпишись на {c['chan']} и попробуй снова."
    need = mb_nft_need(c)
    if need:
        have = _mb_nft_count(uid, need)
        if have is None:
            return "Telegram не ответил на проверку подарков. Попробуй через минуту."
        if have < need:
            return f"Нужно не меньше {need} NFT-{plural_ru(need, 'подарка', 'подарков', 'подарков')} в профиле, у тебя {have}. Считаются только улучшенные подарки, видимые в профиле."
    return None

def _mb_default_cls(uid):
    r = db.execute("SELECT cls FROM players WHERE id=?", (uid,)).fetchone()
    return r[0] if r and r[0] in MB_CLASSES else "knight"

def mb_join(user, body):
    gid = mb_clean_gid(body.get("gid"))
    with db_lock:
        g = _mb_row(gid) if gid else None
    if not g:
        return 404, {"ok": False, "reason": "Розыгрыш не найден."}
    if g["status"] != "reg" or time.time() >= g["reg_ends"]:
        return 409, {"ok": False, "reason": "Регистрация закрыта."}
    pk = f"{gid}:{user['id']}"
    with db_lock:
        if db.execute("SELECT 1 FROM mb_players WHERE pk=?", (pk,)).fetchone():
            return 200, {"ok": True, "already": True}
    if not rate_ok(user["id"], "mbjoin"):
        return 429, {"ok": False, "reason": "Слишком часто. Подожди немного."}
    why = mb_check(g, user["id"], user)
    if why:
        return 403, {"ok": False, "reason": why}
    with db_lock:      # count and insert under one lock: two taps or two players at once can't pass the limit
        g = _mb_row(gid)
        if g["status"] != "reg" or time.time() >= g["reg_ends"]:
            return 409, {"ok": False, "reason": "Регистрация закрыта."}
        if _mb_count(gid) >= g["max_n"]:
            return 409, {"ok": False, "reason": "Мест больше нет."}
        db.execute("INSERT OR IGNORE INTO mb_players(pk, gid, uid, name, username, cls, stats, joined) VALUES(?,?,?,?,?,?,?,?)",
                   (pk, gid, user["id"], display_name(user)[:40] or "Игрок", (user.get("username") or "")[:40], _mb_default_cls(user["id"]),
                    json.dumps({"path": "", "skills": {}}), time.time()))
        db.commit()
    return 200, {"ok": True}

def mb_fighter(user, body):
    gid = mb_clean_gid(body.get("gid"))
    cls = str(body.get("cls", ""))
    sk = body.get("skills") or {}
    if cls not in MB_CLASSES or not isinstance(sk, dict):
        return 400, {"ok": False}
    try:
        b = mb_build_ok(cls, str(body.get("path", "")), sk)
    except (TypeError, ValueError):
        b = None
    if not b:
        return 400, {"ok": False, "reason": "Очков больше, чем можно."}
    with db_lock:
        g = _mb_row(gid) if gid else None
        if not g or g["status"] != "reg":
            return 409, {"ok": False, "reason": "Битва уже началась: бойца не изменить."}
        n = db.execute("UPDATE mb_players SET cls=?, stats=? WHERE pk=?", (cls, json.dumps({"path": b[0], "skills": b[1]}), f"{gid}:{user['id']}")).rowcount
        db.commit()
    if n:
        mb_rate_bg(cls, b[0], b[1])
    return (200, {"ok": True}) if n else (404, {"ok": False, "reason": "Сначала зарегистрируйся."})

def mb_cancel(user, body):
    gid = mb_clean_gid(body.get("gid"))
    with db_lock:
        g = _mb_row(gid) if gid else None
    if not g or g["status"] != "reg":
        return 409, {"ok": False, "reason": "Отменить можно только до начала битвы."}
    if not (user["id"] == g["by_uid"] or user["id"] in ADMIN_IDS or _is_chat_admin(g["chat_id"], user["id"])):
        return 403, {"ok": False}
    with db_lock:
        n = db.execute("UPDATE mb_games SET status='cancelled', finished=? WHERE id=? AND status='reg'", (time.time(), gid)).rowcount
        paid = int((g.get("flags") or {}).get("paid", 0) or 0) if isinstance(g.get("flags"), dict) else 0
        if n and paid:           # cancelled before the battle: the organizer gets his stars back
            db.execute("UPDATE players SET stars=stars+? WHERE id=?", (paid, g["by_uid"]))
            db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (g["by_uid"], paid, "massacre-refund", 1, time.time()))
        db.commit()
    tg_try("sendMessage", chat_id=g["chat_id"], text=f"❌ Массовая бойня «{html_esc(g['title'])}» отменена организатором.", parse_mode="HTML")
    if g["post_mid"]:
        tg_try("unpinChatMessage", chat_id=g["chat_id"], message_id=g["post_mid"])
    return 200, {"ok": True}

def _mb_canon(proto):
    return json.dumps(proto, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _mb_parts(rows):
    parts = []
    for uid, name, un, cls, st in rows:
        cls = cls if cls in MB_CLASSES else "knight"
        raw = json.loads(st or "{}")
        try:
            bd = mb_build_ok(cls, str(raw.get("path", "")), raw.get("skills") or {}) or mb_build_ok(cls, "", {})
        except (TypeError, ValueError, AttributeError):
            bd = mb_build_ok(cls, "", {})
        parts.append({"uid": uid, "name": name, "username": un or "", "cls": cls, "path": bd[0], "skills": mb_fill(cls, bd[0], dict(bd[1]))})
    return parts

def mb_draw(gid):
    """Registration is over: freeze the fighters and draw the order of deaths. Runs once per game (status changes under the lock)."""
    with db_lock:
        pre = db.execute("SELECT uid, name, username, cls, stats FROM mb_players WHERE gid=? ORDER BY joined, pk", (gid,)).fetchall()
    mb_rate([(p["cls"], p["path"], p["skills"]) for p in _mb_parts(pre)])     # v263: the builds' weights, outside the lock
    with db_lock:
        g = _mb_row(gid)
        if not g or g["status"] != "reg":
            return
        rows = db.execute("SELECT uid, name, username, cls, stats FROM mb_players WHERE gid=? ORDER BY joined, pk", (gid,)).fetchall()
        now = time.time()
        if len(rows) < 2:
            db.execute("UPDATE mb_games SET status='cancelled', finished=? WHERE id=?", (now, gid))
            mb_sk_refund(g, int((g.get("flags") or {}).get("sk", 0) or 0), "massacre-skips-back")
            db.commit()
            cancel = True
        else:
            cancel = False
            parts = _mb_parts(rows)
            ws = mb_rate([(p["cls"], p["path"], p["skills"]) for p in parts])
            for p, w in zip(parts, ws):
                p["w"] = w
            # the weighted draw (Efraimidis–Spirakis): each fighter draws u^(1/w); the highest survives, so a fighter wins
            # with probability w / (sum of all w), and the lower draws fall first
            keys = [_mb_rng.random() ** (1.0 / max(0.01, p["w"])) for p in parts]
            order = sorted(range(len(parts)), key=lambda i: keys[i])
            seed = _mb_rng.getrandbits(31)
            start_at = max(now + MB_LEAD_IN, g["plan_at"])
            proto = {"game": gid, "chat": g["chat_id"], "title": g["title"], "prize": g["prize"], "drawn": round(now, 3),
                     "start": round(start_at, 3), "fighters": parts, "order": order, "seed": seed}
            h = hashlib.sha256(_mb_canon(proto)).hexdigest()
            db.execute("UPDATE mb_games SET status='running', n=?, seed=?, ord=?, proto=?, hash=?, start_at=?, winner=? WHERE id=? AND status='reg'",
                       (len(parts), seed, json.dumps(order), json.dumps(proto, ensure_ascii=False), h, start_at, parts[order[-1]]["uid"], gid))
            db.commit()
    if cancel:
        tg_try("sendMessage", chat_id=g["chat_id"], parse_mode="HTML",
               text=f"❌ Массовая бойня «{html_esc(g['title'])}» отменена: участников меньше двух.")
        if g["post_mid"]:
            tg_try("unpinChatMessage", chat_id=g["chat_id"], message_id=g["post_mid"])
        return
    threading.Thread(target=mb_compute, args=(gid,), daemon=True).start()
    threading.Thread(target=mb_tell_fighters, args=(g, [p["uid"] for p in parts], start_at), daemon=True).start()
    tg_try("sendMessage", chat_id=g["chat_id"], parse_mode="HTML",
           text=(f"🔥 <b>{html_esc(g['title'])}</b>\n<i>Регистрация закрыта</i>\n\n"
                 f"👥 Бойцов: <b>{len(parts)}</b>\n🗡 Битва начнётся {mb_tgtime(start_at, 'через ' + str(int(start_at - time.time() + 0.5)) + ' с')}\n\n"
                 + mb_prizes_text(g) + "\n\n"
                 "<blockquote>Жребий с учётом прокачки уже брошен. Проверить, что результат не подменили, можно в игре: «Реплей бойни» → «Проверить протокол».</blockquote>"),
           reply_markup={"inline_keyboard": [[{"text": "📺 Смотреть трансляцию", "url": app_link("mb_" + gid)}]]})

def mb_tell_fighters(g, uids, start_at):
    """v263: everyone who signed up hears from the bot in private that the battle is about to begin (only those who
    started the bot can be written to). About 20 messages a second: well inside Telegram's limit for a bot."""
    with db_lock:
        ok = {r[0] for r in db.execute(f"SELECT id FROM players WHERE can_pm=1 AND id IN ({','.join('?' * len(uids))})", tuple(uids)).fetchall()} if uids else set()
    kb = {"inline_keyboard": [[{"text": "📺 Смотреть битву", "url": app_link("mb_" + g["id"])}]]}
    sent = 0
    for uid in uids:
        if uid not in ok:
            continue
        left = int(start_at - time.time() + 0.5)
        txt = (f"⚔️ <b>{html_esc(g['title'])}</b>: массовая бойня начинается "
               + (mb_tgtime(start_at, f"через {left} с") if left > 0 else "прямо сейчас") + "!\n\nТы в списке бойцов — открой трансляцию и смотри, как пройдёт твой бой.")
        for _ in range(3):
            r = tg_try("sendMessage", chat_id=uid, text=txt, parse_mode="HTML", reply_markup=kb)
            if r.get("ok") or r.get("error_code") != 429:
                break
            time.sleep(float(((r.get("parameters") or {}).get("retry_after")) or 2))
        sent += 1
        time.sleep(0.05)
    log.info("mb %s: told %s of %s fighters in private", g["id"], sent, len(uids))

# ---- v263: the weighted draw. The draw still decides, but a stronger build has better odds: from ×0.7 to ×1.5 against the
# class's default build (×1). The weight comes from mb_engine.js «rate» (duels of the game's own engine), cached per build.
MB_W_MIN, MB_W_MAX, MB_W_POW = 0.7, 1.5, 3.5
_mb_wcache = {}

def _mb_bkey(cls, path, skills):
    return f"{cls}|{path}|" + ",".join(f"{k}:{v}" for k, v in sorted((skills or {}).items()) if v)

def mb_weight_of(ratio):
    return round(max(MB_W_MIN, min(MB_W_MAX, (ratio or 1) ** MB_W_POW)), 3)

def mb_rate(builds):
    """[(cls, path, skills)] already filled → [weight]. Unknown builds go to Node in one run; without Node everyone gets ×1."""
    keys = [_mb_bkey(*b) for b in builds]
    miss = [i for i, k in enumerate(keys) if k not in _mb_wcache]
    if miss and NODE and os.path.exists(MB_ENGINE):
        defaults = {}
        for c in MB_CLASSES:
            p0 = next(iter(MB_TREE[c][1]))
            defaults[c] = {"cls": c, "path": p0, "skills": mb_fill(c, p0, {})}
        uniq = {}
        for i in miss:
            uniq.setdefault(keys[i], builds[i])
        pdef = {f"{c}|{pp}": {"cls": c, "path": pp, "skills": mb_fill(c, pp, {})} for c in MB_CLASSES for pp in MB_TREE[c][1]}
        q = {"mode": "rate", "level": 30, "defaults": defaults, "pathDefaults": pdef,
             "builds": [{"cls": b[0], "path": b[1], "skills": b[2]} for b in uniq.values()]}
        try:
            p = subprocess.run([NODE, MB_ENGINE], input=json.dumps(q).encode(), capture_output=True, timeout=90)
            r = json.loads(p.stdout.decode() or "{}")
            for k, ratio in zip(uniq.keys(), r.get("ratio") or []):
                _mb_wcache[k] = mb_weight_of(ratio)
        except Exception as e:
            log.warning("mb rate: %s", e)
    return [_mb_wcache.get(k, 1.0) for k in keys]

def mb_rate_bg(cls, path, skills):
    """A player changed his build: work its weight out now, so the draw doesn't wait for it."""
    try:
        bd = mb_build_ok(cls, path, skills) or mb_build_ok(cls, "", {})
        threading.Thread(target=mb_rate, args=([(cls, bd[0], mb_fill(cls, bd[0], dict(bd[1])))],), daemon=True).start()
    except Exception:
        pass

_mb_computing = set()
def mb_compute(gid):
    """Who kills whom: the game's battle simulation with the drawn order (Node.js). Without Node: a fair fallback."""
    if gid in _mb_computing:
        return
    _mb_computing.add(gid)
    try:
        with db_lock:
            g = _mb_row(gid)
        if not g or g["log"] or g["status"] != "running":
            return
        proto = json.loads(g["proto"])
        parts, order, seed = proto["fighters"], proto["order"], proto["seed"]
        log_rows = None
        if NODE and os.path.exists(MB_ENGINE):
            try:
                q = {"fighters": [{"cls": p["cls"]} for p in parts], "order": order, "seed": seed}
                p = subprocess.run([NODE, MB_ENGINE], input=json.dumps(q).encode(), capture_output=True, timeout=120)
                r = json.loads(p.stdout.decode() or "{}")
                if r.get("log") and len(r["log"]) == len(parts) - 1:
                    log_rows = r["log"]
                else:
                    log.warning("mb engine: %s", (r.get("error") or p.stderr.decode()[-300:]))
            except Exception as e:
                log.warning("mb engine: %s", e)
        if log_rows is None:
            # the fallback still keeps the draw: each victim is killed by a fighter who dies later (or by the winner)
            D, T = mb_timeline(len(parts))
            rnd = random.Random(seed)
            rank = {v: k for k, v in enumerate(order)}
            log_rows = []
            for k, v in enumerate(order[:-1]):
                later = order[k + 1:]
                kl = later[rnd.randrange(len(later))]
                log_rows.append([k, v, kl, round(T[k], 2)])
        with db_lock:
            db.execute("UPDATE mb_games SET log=? WHERE id=? AND (log IS NULL OR log='')", (json.dumps(log_rows), gid))
            db.commit()
        _mb_cache.pop(gid, None)
    finally:
        _mb_computing.discard(gid)

# ---- what the game asks while the giveaway runs (cached for a second: hundreds of players poll the same battle)
_mb_cache = {}
def _mb_snapshot(gid):
    now = time.time()
    c = _mb_cache.get(gid)
    if c and now - c["at"] < 1.0:
        return c
    with db_lock:
        g = _mb_row(gid)
        if not g:
            return None
        n = _mb_count(gid) if g["status"] == "reg" else g["n"]
        players = {}
        if g["status"] == "reg":
            for uid, cls, st in db.execute("SELECT uid, cls, stats FROM mb_players WHERE gid=?", (gid,)).fetchall():
                players[uid] = (cls, json.loads(st or "{}") or {})
    c = {"at": now, "g": g, "n": n, "players": players}
    if g["proto"]:
        proto = json.loads(g["proto"])
        c["fighters"] = [[p["username"] or p["name"], p["cls"], p.get("path", ""), p.get("skills", {}), p.get("w", 1)] for p in proto["fighters"]]
        c["uid2i"] = {p["uid"]: i for i, p in enumerate(proto["fighters"])}
        c["T"] = mb_timeline(len(proto["fighters"]))[1]
        c["log"] = json.loads(g["log"]) if g["log"] else None
    _mb_cache[gid] = c
    return c

def mb_state(user, q):
    gid = mb_clean_gid(q.get("gid", [""])[0])
    c = _mb_snapshot(gid) if gid else None
    if not c:
        return 404, {"ok": False, "reason": "Розыгрыш не найден."}
    g, now = c["g"], time.time()
    out = {"ok": True, "gid": gid, "title": g["title"], "prize": g["prize"], "conds": g["conds"], "max": g["max_n"],
           "status": g["status"], "regEnds": int(g["reg_ends"] * 1000), "planAt": int(g["plan_at"] * 1000),
           "startAt": int(g["start_at"] * 1000), "now": int(now * 1000), "count": c["n"], "chat": g["chat_title"] or "",
           "manage": user["id"] == g["by_uid"] or user["id"] in ADMIN_IDS}
    me = c["players"].get(user["id"])
    if me:
        out["me"] = {"joined": True, "cls": me[0], "path": me[1].get("path", ""), "skills": me[1].get("skills", {})}
    if "fighters" in c:
        i = c["uid2i"].get(user["id"])
        out["me"] = {"joined": i is not None, "idx": i}
        if i is not None:
            out["me"].update({"cls": c["fighters"][i][1], "path": c["fighters"][i][2], "skills": c["fighters"][i][3]})
        out["n"] = len(c["fighters"])
        out["fighters"] = c["fighters"]
        out["seed"] = g["seed"]
        out["hash"] = g["hash"]
        if c["log"] is None:
            out["log"], out["computing"] = [], True
        else:
            try:
                frm = max(0, int(q.get("from", ["0"])[0]))
            except ValueError:
                frm = 0
            t = now - g["start_at"]
            done = g["status"] == "done"
            out["log"] = [r[:3] for r in c["log"][frm:] if done or c["T"][r[0]] <= t + MB_LOOKAHEAD]
        if g["status"] == "done":
            out["winner"] = c["uid2i"].get(g["winner"])
    return 200, out

def mb_proto(user, q):
    """The whole protocol of a finished battle: anyone can hash it and compare with the fingerprint posted before the battle."""
    gid = mb_clean_gid(q.get("gid", [""])[0])
    with db_lock:
        g = _mb_row(gid) if gid else None
    if not g or g["status"] != "done":
        return 404, {"ok": False, "reason": "Протокол открывается после битвы."}
    proto = json.loads(g["proto"])
    return 200, {"ok": True, "hash": g["hash"], "canonical": _mb_canon(proto).decode("utf-8"), "log": json.loads(g["log"] or "[]")}

def mb_mine(user):
    with db_lock:
        rows = db.execute("SELECT g.id, g.title, g.status, g.reg_ends, g.start_at, g.chat_title FROM mb_games g WHERE g.status IN ('reg','running') "
                          "AND (g.by_uid=? OR g.id IN (SELECT gid FROM mb_players WHERE uid=?)) ORDER BY g.created DESC LIMIT 5",
                          (user["id"], user["id"])).fetchall()
    return 200, {"ok": True, "games": [{"gid": r[0], "title": r[1], "status": r[2], "chat": r[5] or ""} for r in rows]}

# ---- the bot's posts while the battle runs: one summary every 10 s while the crowd is big, every kill by name at the end
def _mb_who(p):
    return mention(p["uid"], p["name"], p["username"])

def _mb_watch_kb(g, text="📺 Смотреть трансляцию"):
    return {"inline_keyboard": [[{"text": text, "url": app_link("mb_" + g["id"])}]]}

# v265: private messages of the battle (who fell, who won) go out one by one from a queue: the battle loop never waits
_mb_dm_q = queue.Queue()

def _mb_dm_worker():
    while True:
        uid, txt, kb = _mb_dm_q.get()
        try:
            with db_lock:
                ok = db.execute("SELECT can_pm FROM players WHERE id=?", (uid,)).fetchone()
            if not ok or not ok[0]:
                continue
            for _ in range(3):
                r = tg_try("sendMessage", chat_id=uid, text=txt, parse_mode="HTML", reply_markup=kb, disable_web_page_preview=True)
                if r.get("ok") or r.get("error_code") != 429:
                    break
                time.sleep(float(((r.get("parameters") or {}).get("retry_after")) or 2))
        except Exception as e:
            log.info("mb dm: %s", e)
        time.sleep(0.05)

threading.Thread(target=_mb_dm_worker, daemon=True).start()

def _mb_tell_fallen(g, parts, N, rows):
    """Everyone who fell in these rows hears in private who took him out and where he finished."""
    for r in rows:
        v, k = parts[r[1]], parts[r[2]]
        if not v.get("uid"):
            continue
        place = N - r[0]
        if place <= int(g["conds"].get("places", 1) or 1):
            continue                    # a prize place: one message at the end, with the place and the killer
        _mb_dm_q.put((v["uid"], f"☠️ <b>{html_esc(g['title'])}</b>: ты выбыл из бойни.\n\n"
                                f"Тебя вынес {_mb_who(k)}.\nТвоё место: <b>{place}</b> из {N}.",
                      _mb_watch_kb(g, "📺 Досмотреть битву")))

def _mb_send(g, text, markup=None):
    p = {"chat_id": g["chat_id"], "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}
    if markup:
        p["reply_markup"] = markup
    r = tg_try("sendMessage", **p)
    if not r.get("ok") and r.get("error_code") == 429:
        return float(((r.get("parameters") or {}).get("retry_after")) or 5)
    return 0.0

def mb_progress(g):
    if not g["log"]:
        return
    now = time.time()
    if now < g["last_post"]:
        return                      # Telegram asked to slow down
    proto, rows = json.loads(g["proto"]), json.loads(g["log"])
    parts, N = proto["fighters"], len(proto["fighters"])
    t = now - g["start_at"]
    posted = g["posted"]
    due = [r for r in rows[posted:] if r[3] <= t]
    if not due:
        if posted >= N - 1:
            mb_finish(g)
        return
    left_after = N - 1 - (posted + len(due))
    lines, wait = [], 0.0
    if N - 1 - posted > 15 and left_after > 15:
        if now - (g["last_post"] or g["start_at"]) < 10 and left_after > 15:
            return                  # collect for the 10-second summary
        k = len(due)
        lines.append(f"💀 За последние 10 секунд погибли {k} {plural_ru(k, 'боец', 'бойца', 'бойцов')}.\n🩸 Осталось бойцов: <b>{left_after + 1}</b>")
        for m in (250, 100, 50, 25):
            if left_after + 1 < m <= N - posted:      # this summary crossed the mark
                lines.append(f"🔥 В живых меньше {m} бойцов!")
                break
    else:
        for r in due:
            alive = N - 1 - r[0]
            lines.append(f"☠️ {_mb_who(parts[r[1]])} уничтожен бойцом {_mb_who(parts[r[2]])}\n🩸 Осталось бойцов: <b>{alive}</b>")
            if alive == 2:
                a, b = [parts[i] for i in range(N) if i not in {x[1] for x in rows[:r[0] + 1]}][:2]
                lines.append(f"⚔️ <b>Финальная дуэль:</b> {_mb_who(a)} против {_mb_who(b)}")
    wait = _mb_send(g, "\n\n".join(lines), _mb_watch_kb(g))   # the last blows too: their own message, before the results
    told = 0
    with db_lock:
        if wait:
            db.execute("UPDATE mb_games SET last_post=? WHERE id=?", (now + wait, g["id"]))
        else:
            told = db.execute("UPDATE mb_games SET posted=?, last_post=? WHERE id=? AND posted=?", (posted + len(due), now, g["id"], posted)).rowcount
        db.commit()
    if told:
        _mb_tell_fallen(g, parts, N, due)
    if not wait and posted + len(due) >= N - 1:
        g = _mb_row(g["id"])
        mb_finish(g)

MB_CLS_RU = {"knight": "Рыцарь", "mage": "Маг", "necro": "Некромант", "gladiator": "Гладиатор", "samurai": "Самурай"}
_mb_font = None
def mb_card_png(cls, name):
    """The winner's card: his class standing in the steel set (a/mbcard_<class>.bin, raw 640×640 RGB),
    his nick written on the plate in the game's pixel font (a/mbfont.json), packed as PNG. None if the pieces are missing."""
    global _mb_font
    try:
        raw = bytearray(zlib.decompress(open(os.path.join(PUBLIC, "a", f"mbcard_{cls if cls in MB_CLS_RU else 'knight'}.bin"), "rb").read()))
        if _mb_font is None:
            _mb_font = json.load(open(os.path.join(PUBLIC, "a", "mbfont.json"), encoding="utf-8"))
    except Exception as e:
        log.warning("mb card: %s", e)
        return None
    W = 640
    glyphs, gh = _mb_font["g"], _mb_font["h"]
    text = "".join(ch if ch in glyphs else "?" for ch in name)[:32] or "?"
    tw = sum(len(glyphs[ch][0]) if glyphs[ch] else 4 for ch in text) + len(text) - 1
    sc = next((k for k in (4, 3, 2) if tw * k <= 500), 1)
    x0, y0 = (W - tw * sc) // 2, 585 - gh * sc // 2
    def put(x, y, col):
        if 0 <= x < W and 0 <= y < W:
            i = (y * W + x) * 3
            raw[i:i + 3] = col
    for dx, dy, col in [(o[0], o[1], (10, 7, 16)) for o in ((-1, 0), (1, 0), (0, -1), (0, 1), (1, 1))] + [(0, 0, (255, 210, 74))]:
        x = x0
        for ch in text:
            rows = glyphs[ch]
            for gy, row in enumerate(rows):
                for gx, bit in enumerate(row):
                    if bit == "1":
                        for yy in range(sc):
                            for xx in range(sc):
                                put(x + gx * sc + xx + dx * sc, y0 + gy * sc + yy + dy * sc, col)
            x += ((len(rows[0]) if rows else 4) + 1) * sc
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    rows = b"".join(b"\x00" + bytes(raw[y * W * 3:(y + 1) * W * 3]) for y in range(W))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", W, W, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows, 6)) + chunk(b"IEND", b""))

def mb_places(proto, k):
    """The first k places: the winner, then whoever fell last."""
    parts, order = proto["fighters"], proto["order"]
    return [parts[order[len(order) - p]] for p in range(1, min(k, len(order)) + 1)]

def mb_finish(g):
    """The last blow has fallen: one results post, whatever restarts happen (status changes once, under the lock)."""
    with db_lock:
        cur = _mb_row(g["id"])
        if not cur or cur["status"] != "running":
            return
        if not db.execute("UPDATE mb_games SET status='done', finished=? WHERE id=? AND status='running'", (time.time(), g["id"])).rowcount:
            return
        proto = json.loads(cur["proto"])
        N = len(proto["fighters"])
        top = mb_places(proto, cur["conds"].get("places", 1))
        ps = mb_prize_list(cur)
        # v271: the skips of each prize place land on the winner's account at once; places nobody took give them back
        for i, p in enumerate(ps, 1):
            k = int(p.get("sk") or 0)
            if not k:
                continue
            if i <= len(top) and top[i - 1].get("uid"):
                db.execute("UPDATE players SET skips=skips+? WHERE id=?", (k, top[i - 1]["uid"]))
                db.execute("INSERT INTO star_ledger(uid, delta, what, n, ts) VALUES(?,?,?,?,?)", (top[i - 1]["uid"], 0, "massacre-prize-skips", k, time.time()))
            else:
                mb_sk_refund(cur, k, "massacre-skips-back")
        db.commit()
    _mb_cache.pop(g["id"], None)
    w = top[0]
    rows = [f"{MB_MEDAL.get(i, f'{i}.')} {_mb_who(p)}" + (f" — {mb_prize_html(ps[i - 1])}" if i <= len(ps) else "") for i, p in enumerate(top, 1)]
    cap = (f"🏆 <b>Итоги: {html_esc(cur['title'])}</b>\n\n"
           f"Последним на ногах остался {_mb_who(w)}\n\n"
           + ("Призовые места:\n" if len(top) > 1 else "Приз:\n") + "\n".join(rows) + "\n\n"
           f"👥 Бойцов было {N}. Жребий учитывал прокачку: шанс у каждого от ×0,7 до ×1,5.")
    kb = {"inline_keyboard": [[{"text": "🎬 Реплей бойни", "url": app_link("mb_" + cur["id"])}]]}
    killer = {r[1]: r[2] for r in json.loads(cur["log"] or "[]")}
    idx = {id(p): i for i, p in enumerate(proto["fighters"])}
    for i, p in enumerate(top, 1):
        k = killer.get(idx.get(id(p)))
        if p.get("uid"):
            _mb_dm_q.put((p["uid"], (f"🏆 <b>{html_esc(cur['title'])}</b>: ты победил! Последним на ногах остался именно ты."
                                     if i == 1 else f"🏅 <b>{html_esc(cur['title'])}</b>: ты занял {i} место из {N}."
                                     + (f"\nТебя вынес {_mb_who(proto['fighters'][k])}." if k is not None else ""))
                          + (("\n\nТвой приз: " + mb_prize_html(ps[i - 1]) + ". "
                              + ("Пропуски уже на твоём счёте в игре." if ps[i - 1].get("sk") and ps[i - 1]["n"] == mb_sk_txt(ps[i - 1]["sk"])
                                 else "Пропуски уже на твоём счёте, остальное — организатор свяжется с тобой." if ps[i - 1].get("sk")
                                 else "Организатор свяжется с тобой.")) if i <= len(ps) else ""),
                          {"inline_keyboard": [[{"text": "🎬 Реплей бойни", "url": app_link("mb_" + cur["id"])}]]}))
    png = mb_card_png(w["cls"], "@" + w["username"] if w.get("username") else (w.get("name") or "Победитель"))
    try:
        r = tg_multipart("sendPhoto", {"photo": ("winner.png", png, "image/png")}, chat_id=cur["chat_id"], caption=cap,
                         parse_mode="HTML", reply_markup=kb) if png else {"ok": False}
    except Exception as e:
        log.warning("mb card send: %s", e)
        r = {"ok": False}
    if not r.get("ok"):
        _mb_send(cur, cap, kb)
    if cur["post_mid"]:
        tg_try("unpinChatMessage", chat_id=cur["chat_id"], message_id=cur["post_mid"])
    tg_try("sendMessage", chat_id=cur["by_uid"], parse_mode="HTML",
           text=f"🏆 Бойня «{html_esc(cur['title'])}» окончена. Кому что отдать (пропуски бот уже начислил сам):\n"
                + "\n".join(f"{i}. {_mb_who(p)} (id {p['uid']})" + (f" — {mb_prize_html(ps[i - 1])}" if i <= len(ps) else "") for i, p in enumerate(top, 1)),
           disable_web_page_preview=True)

def mb_loop():
    while True:
        time.sleep(1)
        try:
            now = time.time()
            with db_lock:
                ids = db.execute("SELECT id, status, reg_ends, plan_at FROM mb_games WHERE status IN ('reg','running')").fetchall()
            for gid, status, reg_ends, plan_at in ids:
                if status == "reg":
                    if now >= max(reg_ends, plan_at - MB_LEAD_IN):
                        mb_draw(gid)
                    else:
                        with db_lock:
                            g = _mb_row(gid)
                            n = _mb_count(gid)
                        if g["post_mid"] and n != g["last_n"] and now - g["last_edit"] > 20:
                            kb = {"inline_keyboard": [[{"text": "⚔️ Участвовать", "url": app_link("mb_" + gid)}]]}
                            if g["conds"].get("photo"):      # a post made by v258 with the gift's picture
                                tg_try("editMessageCaption", chat_id=g["chat_id"], message_id=g["post_mid"], caption=_mb_announce_text(g, n), parse_mode="HTML", reply_markup=kb)
                            else:
                                tg_try("editMessageText", chat_id=g["chat_id"], message_id=g["post_mid"], text=_mb_announce_text(g, n), parse_mode="HTML", reply_markup=kb)
                            with db_lock:
                                db.execute("UPDATE mb_games SET last_n=?, last_edit=? WHERE id=?", (n, now, gid))
                                db.commit()
                else:
                    with db_lock:
                        g = _mb_row(gid)
                    if not g["log"]:
                        threading.Thread(target=mb_compute, args=(gid,), daemon=True).start()   # after a restart in the middle
                        continue
                    if now >= g["start_at"]:
                        if not g["flags"].get("go"):
                            with db_lock:
                                db.execute("UPDATE mb_games SET flags=? WHERE id=?", (json.dumps(dict(g["flags"], go=1)), gid))
                                db.commit()
                            _mb_send(g, f"⚔️ <b>{html_esc(g['title'])}</b>: битва началась! Бойцов: <b>{g['n']}</b>",
                                     {"inline_keyboard": [[{"text": "📺 Смотреть трансляцию", "url": app_link("mb_" + gid)}]]})
                            continue
                        mb_progress(g)
        except Exception as e:
            log.warning("mb loop: %s", e)

class Handler(BaseHTTPRequestHandler):
    server_version = "Emberspire"

    def log_message(self, fmt, *args):
        pass

    def send_bytes(self, code, raw, ctype, cache="no-cache"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", cache)
        try:
            self.end_headers()
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass    # the player closed the app before the answer arrived: nothing to do

    def send_media(self, raw, ctype):
        """Pictures and the title video. iPhones play a video only from a server that answers byte ranges (206)."""
        # v196: a week in the phone's cache, and after that a cheap check (304) instead of the whole video or song again
        lm = getattr(self, "_media_mtime", None)
        lms = time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime(lm)) if lm else None
        if lms and self.headers.get("If-Modified-Since") == lms and not self.headers.get("Range"):
            self.send_response(304)
            self.send_header("Last-Modified", lms)
            self.send_header("Cache-Control", "public, max-age=604800")
            self.end_headers()
            return
        rng = self.headers.get("Range", "")
        start, end = 0, len(raw) - 1
        partial = False
        if rng.startswith("bytes="):
            try:
                a_, b_ = rng[6:].split(",")[0].split("-")
                if a_:
                    start, end = int(a_), (int(b_) if b_ else len(raw) - 1)
                else:
                    start = max(0, len(raw) - int(b_))
                end = min(end, len(raw) - 1)
                partial = start <= end
            except ValueError:
                partial = False
            if not partial:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{len(raw)}")
                self.end_headers()
                return
        body = raw[start:end + 1]
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=604800")
        if lms:
            self.send_header("Last-Modified", lms)
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{len(raw)}")
        try:
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_json(self, code, obj):
        self.send_bytes(code, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8", "no-store")

    def signed(self):
        return check_init_data(self.headers.get("X-Init-Data", ""))

    def body(self, limit):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n > limit:
                return None
            b = json.loads(self.rfile.read(n) or b"{}")
            return b if isinstance(b, dict) else {}
        except (ValueError, TypeError):
            return {}

    def send_nftimg(self, n):
        """The picture of a Telegram NFT gift, taken from Fragment once and kept on our server: some players' networks
        do not reach fragment.com, and a picture from the game's own address always loads."""
        n = str(n).lower()
        if not NFT_IMG_RE.match(n):
            return self.send_json(400, {"ok": False})
        data = nft_img(n)
        if not data:
            return self.send_json(404, {"ok": False})
        self.send_response(200)
        self.send_header("Content-Type", "image/webp")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=604800")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        path = url.path
        if path == "/api/health":
            return self.send_json(200, {"ok": True})
        if path == "/api/notice":
            return self.send_json(*notice_get())
        if path == "/api/season":
            return self.send_json(*season_get())
        if path == "/api/nftimg":
            return self.send_nftimg(urllib.parse.parse_qs(url.query).get("n", [""])[0])
        if path.startswith("/api/"):
            u, f = self.signed()
            if not u:
                return self.send_json(401, {"ok": False, "reason": "not signed in"})
            ensure_player(u)
            if path == "/api/leaderboard":
                return self.send_json(*leaderboard(u, urllib.parse.parse_qs(url.query).get("cls", [""])[0]))
            if path == "/api/mb/state":
                return self.send_json(*mb_state(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/mb/proto":
                return self.send_json(*mb_proto(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/mb/mine":
                return self.send_json(*mb_mine(u))
            if path == "/api/mb/chats":
                return self.send_json(*mb_chats(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/ref":
                return self.send_json(*ref_info(u))
            if path == "/api/partner":
                return self.send_json(*partner_info(u))
            if path == "/api/partner/refs":
                return self.send_json(*partner_refs(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/admin/partners":
                return self.send_json(*admin_partners(u))
            if path == "/api/raid":
                return self.send_json(*raid_get(u, f, urllib.parse.parse_qs(url.query).get("ci", [""])[0]))
            if path == "/api/raid/stats":
                return self.send_json(*raid_stats(u, urllib.parse.parse_qs(url.query).get("ci", [""])[0], f))
            if path == "/api/save":
                return self.send_json(*save_get(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/duel":
                return self.send_json(*duel_get(u, urllib.parse.parse_qs(url.query).get("id", [""])[0]))
            if path == "/api/duel/mine":
                return self.send_json(*duel_mine(u))
            if path == "/api/admin/ac":
                return self.send_json(*ac_admin_get(u))
            if path == "/api/stars":
                return self.send_json(*stars_get(u))
            if path == "/api/quests":
                return self.send_json(*quests_get(u))
            if path == "/api/nft":
                return self.send_json(*nft_mine(u))
            if path == "/api/gr":
                return self.send_json(*gr_get(u, urllib.parse.parse_qs(url.query).get("id", [""])[0]))
            if path == "/api/gr/mine":
                return self.send_json(*gr_mine(u))
            if path == "/api/gr/list":
                return self.send_json(*gr_list(u))
            if path == "/api/admin/player":
                return self.send_json(*admin_player(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/admin/dash":
                return self.send_json(*dash_data(u, urllib.parse.parse_qs(url.query)))
            if path == "/api/ghost":
                return self.send_json(*ghost_find(u, urllib.parse.parse_qs(url.query).get("room", ["0"])[0]))
            return self.send_json(404, {"ok": False})
        if path in ("/stats", "/stats/"):
            return self.send_bytes(200, STATS_PAGE.encode(), "text/html; charset=utf-8", "no-store")
        if path.startswith("/cards/"):
            name = os.path.basename(path)
            full = os.path.join(CARDS, name)
            if not name.endswith(".jpg") or not os.path.isfile(full):
                return self.send_json(404, {"ok": False})
            with open(full, "rb") as fh:
                return self.send_bytes(200, fh.read(), "image/jpeg", "public, max-age=604800")
        # static files from ./public, index.html for the root
        rel = "index.html" if path in ("", "/") else "terms.html" if path in ("/terms", "/terms/") else path.lstrip("/")
        full = os.path.normpath(os.path.join(PUBLIC, rel))
        if not full.startswith(PUBLIC + os.sep) or not os.path.isfile(full):
            return self.send_json(404, {"ok": False})
        with open(full, "rb") as fh:
            raw = fh.read()
        if full.endswith((".mp4", ".jpg", ".png", ".webm", ".mp3")):
            self._media_mtime = int(os.path.getmtime(full))
            return self.send_media(raw, mimetypes.guess_type(full)[0] or "application/octet-stream")
        if full.endswith(".html"):
            # tell the game the bot and Mini App names, so invite links point to the right place
            cfg = f'<script>window.EMBER_BOT={json.dumps(BOT_USERNAME)};window.EMBER_APP={json.dumps(APP_NAME)};</script>'
            raw = raw.replace(b"<head>", b"<head>" + cfg.encode(), 1)
            if b"{{SUPPORT" in raw:
                sup = SUPPORT_URL or (f"https://t.me/{BOT_USERNAME}" if BOT_USERNAME else "#")
                raw = raw.replace(b"{{SUPPORT}}", _html.escape(sup).encode()).replace(b"{{SUPPORT_TEXT}}", _html.escape("Написать в поддержку" if SUPPORT_URL else "Написать боту").encode())
        # v196: an ETag (a phone that has this version gets a tiny 304), brotli for pages and scripts (≈20% smaller than gzip),
        # and the picture files in public/a/ (their names carry a hash) are kept by phones for a year
        etag = '"' + hashlib.md5(raw).hexdigest()[:20] + '"'
        cache = "public, max-age=31536000, immutable" if rel.startswith("a/") else "no-cache"
        if self.headers.get("If-None-Match", "") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return
        ctype = (mimetypes.guess_type(full)[0] or "application/octet-stream") + ("; charset=utf-8" if full.endswith((".html", ".js")) else "")
        enc = None
        if full.endswith((".html", ".js")) and "br" in self.headers.get("Accept-Encoding", "") and len(raw) > 2048:
            br = brotli_of(raw, etag)
            if br:
                raw, enc = br, "br"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", cache)
        self.send_header("ETag", etag)
        self.send_header("Vary", "Accept-Encoding")
        if enc:
            self.send_header("Content-Encoding", enc)
        try:
            self.end_headers()
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def tg_update(self):
        """Accept an update the TypeScript bot relayed to us. This bot is the only
        getUpdates poller, so it hands us the updates we own (/boss, inline duels,
        admin/support commands, my_chat_member, Stars top-ups). The body is the raw
        Telegram update; the request is authorised with the token both containers share."""
        if self.headers.get("X-TG-Forward", "") != BOT_TOKEN:
            return self.send_json(403, {"ok": False})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            upd = json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception as e:
            log.warning("tg-update body: %s", e)
            return self.send_json(400, {"ok": False})
        threading.Thread(target=_handle_update_safe, args=(upd,), daemon=True).start()
        return self.send_json(200, {"ok": True})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/tg-update":
            return self.tg_update()
        u, f = self.signed()
        if not u:
            return self.send_json(401, {"ok": False, "reason": "not signed in"})
        if path not in ("/api/stars/invoice", "/api/stars/skip") and not rate_ok(u["id"], "post"):
            return self.send_json(429, {"ok": False, "reason": "slow"})
        is_new = ensure_player(u)
        body = self.body(600_000 if path in ("/api/share/prepare", "/api/duel/card") else 2_000_000 if path == "/api/save" else 16_384 if path == "/api/ev" else 4096)
        if body is None:
            return self.send_json(413, {"ok": False})
        routes = {
            "/api/score": lambda: submit_score(u, body),
            "/api/hello": lambda: hello(u, f, is_new, body),
            "/api/ev": lambda: ev_log(u, body),
            "/api/ref/claim": lambda: ref_claim(u),
            "/api/partner/code": lambda: partner_code(u),
            "/api/partner/enter": lambda: partner_attach_api(u, body),
            "/api/partner/withdraw": lambda: partner_withdraw(u),
            "/api/admin/partner": lambda: admin_partner_set(u, body),
            "/api/admin/partner/pay": lambda: admin_partner_pay(u, body),
            "/api/raid/hit": lambda: raid_hit(u, f, body),
            "/api/raid/join": lambda: raid_join(u, f, body),
            "/api/raid/claim": lambda: raid_claim(u, f, body),
            "/api/save": lambda: save_put(u, body),
            "/api/session/ping": lambda: session_ping(u, body),
            "/api/quests/channel": lambda: quest_channel(u),
            "/api/admin/notice": lambda: notice_set(u, body),
            "/api/admin/rest": lambda: rest_cfg_set(u, body),
            "/api/admin/wipe": lambda: admin_wipe(u, body),
            "/api/admin/skips": lambda: admin_skips(u, body),
            "/api/admin/season": lambda: season_set(u, body),
            "/api/admin/ac": lambda: ac_admin_set(u, body),
            "/api/stars/topup": lambda: stars_topup(u, body),
            "/api/stars/invoice": lambda: stars_invoice(u, body),
            "/api/admin/stars": lambda: stars_mode(u, body),
            "/api/stars/buy": lambda: stars_buy(u, body),
            "/api/stars/skip": lambda: stars_skip(u, body),
            "/api/luck": lambda: luck_spin(u, body),
            "/api/luck/info": lambda: luck_info(u),
            "/api/quests/claim": lambda: quests_claim(u, body),
            "/api/nft/boss": lambda: nft_boss(u, body),
            "/api/nft/withdraw": lambda: nft_withdraw(u, body),
            "/api/notify": lambda: notify_set(u, body),
            "/api/rest": lambda: rest_set(u, body),
            "/api/share/prepare": lambda: share_prepare(u, body),
            "/api/duel/new": lambda: duel_new(u, body),
            "/api/duel/accept": lambda: duel_accept(u, body),
            "/api/duel/direct": lambda: duel_direct(u, body),
            "/api/duel/decline": lambda: duel_decline(u, body),
            "/api/duel/cancel": lambda: duel_cancel(u, body),
            "/api/ghost/fight": lambda: ghost_fight(u, body),
            "/api/duel/card": lambda: duel_card(u, body),
            "/api/gr/new": lambda: gr_new(u, body),
            "/api/gr/join": lambda: gr_join(u, body),
            "/api/gr/leave": lambda: gr_leave(u, body),
            "/api/gr/kick": lambda: gr_kick(u, body),
            "/api/gr/start": lambda: gr_start(u, body),
            "/api/gr/claim": lambda: gr_claim(u, body),
            "/api/gr/bot": lambda: gr_bot(u, body),
            "/api/gr/public": lambda: gr_public(u, body),
            "/api/mb/new": lambda: mb_new(u, body),
            "/api/mb/join": lambda: mb_join(u, body),
            "/api/mb/fighter": lambda: mb_fighter(u, body) if rate_ok(u["id"], "mbfighter") else (429, {"ok": False}),
            "/api/mb/cancel": lambda: mb_cancel(u, body),
            "/api/admin/mbprice": lambda: mb_price_set(u, body),
        }
        fn = routes.get(path)
        return self.send_json(*(fn() if fn else (404, {"ok": False})))

# ---------------------------------------------------------------- statistics for the owner (v193)
_ev_rate = {}
def ev_log(user, body):
    """The game sends fights on new floors in small batches: floor, boss/elite/ordinary, win, which try, the hero."""
    uid, now = user["id"], time.time()
    w = _ev_rate.get(uid)
    if not w or now - w[0] > 600:
        w = _ev_rate[uid] = [now, 0]
    evs = body.get("ev")
    if not isinstance(evs, list):
        return 400, {"ok": False}
    rows = []
    for e in evs[:20]:
        if not isinstance(e, dict) or w[1] >= 400:      # a hero can't fight more than ~40 times a minute: anything past that is noise
            break
        w[1] += 1
        kind = e.get("k") if e.get("k") in ("n", "e", "b") else "n"
        rows.append((uid, now, as_int(e.get("r"), 1, 100000), kind, 1 if e.get("w") else 0, as_int(e.get("t"), 1, 1000),
                     as_int(e.get("d"), 0, 3600), str(e.get("c") or "")[:16], as_int(e.get("l"), 1, 100000),
                     as_int(e.get("hp"), 0, 10**12), as_int(e.get("atk"), 0, 10**12), as_int(e.get("df"), 0, 10**12),
                     as_int(e.get("q"), 0, 60), 1 if e.get("a") else 0))
    if rows:
        with db_lock:
            db.executemany("INSERT INTO fight_log VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            db.commit()
    return 200, {"ok": True}

def _median(a):
    a = sorted(a)
    return 0 if not a else a[len(a) // 2] if len(a) % 2 else (a[len(a) // 2 - 1] + a[len(a) // 2]) / 2

SPEND_RU = {"skips": "Пропуск отдыха", "luck": "Удача", "reset": "Сброс умений", "path": "Сброс пути", "class": "Смена класса",
            "autofarm": "Автофарм"}
BANDS = [(1, 99, "1–99"), (100, 299, "100–299"), (300, 599, "300–599"), (600, 10**9, "600+")]
FLOOR_BUCKETS = [(0, 0, "0"), (1, 24, "1–24"), (25, 49, "25–49"), (50, 99, "50–99"), (100, 149, "100–149"), (150, 199, "150–199"),
                 (200, 299, "200–299"), (300, 399, "300–399"), (400, 599, "400–599"), (600, 999, "600–999"), (1000, 10**9, "1000+")]

def dash_data(user, q):
    """Everything the owner's statistics page shows, counted here so the page only draws."""
    if user["id"] not in ADMIN_IDS:
        return 403, {"ok": False}
    days = as_int((q.get("days") or ["30"])[0], 1, 365)
    now = time.time()
    today = int((now + AC_TZ_S) // 86400)
    d0 = today - days + 1
    t0 = d0 * 86400 - AC_TZ_S
    dayof = lambda ts: int((ts + AC_TZ_S) // 86400)
    with db_lock:
        # seen/updated are TIMESTAMP under PostgreSQL: NULLIF(seen,0) compares a timestamp with a number and fails there,
        # so "last seen" is coalesced in Python instead (0 = never seen, as in the SQLite schema)
        pl = db.execute("SELECT id, name, username, cls, room, level, first_seen, seen, updated, flagged FROM players").fetchall()
        sv = {}
        for uid, data in db.execute("SELECT uid, data FROM saves"):
            try:
                d = json.loads(data)
                sv[uid] = (int(d.get("level") or 0), int(d.get("maxCleared") or 0), str(d.get("cls") or ""))
            except (ValueError, TypeError):
                pass
        act = dict(db.execute("SELECT day, COUNT(*) FROM act WHERE day>=? GROUP BY day", (d0,)).fetchall())
        act_any = db.execute("SELECT COUNT(DISTINCT uid) FROM act WHERE day>=?", (d0,)).fetchone()[0]
        fights = db.execute("SELECT uid, room, kind, win, tries, dur, cls, ts, q, auto FROM fight_log WHERE ts>=?", (t0,)).fetchall()
        pays = db.execute("SELECT uid, n, ts FROM star_pay WHERE refunded=0").fetchall()
        spend = db.execute("SELECT uid, what, -delta, ts FROM star_ledger WHERE delta<0 AND what<>'refund' AND ts>=?", (t0,)).fetchall()
    P = {}
    for uid, name, un, cls, room, level, first, seen, upd, flagged in pl:
        lv, mc, sc = sv.get(uid, (0, 0, ""))
        P[uid] = {"name": name or "Игрок", "un": un or "", "cls": sc or cls or "", "floor": max(room or 0, mc), "level": max(level or 0, lv) or 1,
                  "first": first or 0, "seen": seen or upd or 0, "flag": 1 if flagged else 0, "paid": 0}
    for uid, n, ts in pays:
        if uid in P:
            P[uid]["paid"] += n or 0
    real = [p for p in P.values() if not p["flag"]]
    # ---- overview and day by day
    series = []
    pay_day, payers_day, new_day = {}, {}, {}
    for uid, n, ts in pays:
        d = dayof(ts)
        pay_day[d] = pay_day.get(d, 0) + (n or 0)
        payers_day.setdefault(d, set()).add(uid)
    for p in real:
        if p["first"]:
            d = dayof(p["first"])
            new_day[d] = new_day.get(d, 0) + 1
    for d in range(d0, today + 1):
        series.append({"d": d, "date": time.strftime("%d.%m", time.gmtime(d * 86400)), "act": act.get(d, 0), "new": new_day.get(d, 0),
                       "stars": pay_day.get(d, 0), "payers": len(payers_day.get(d, ()))})
    seen_in = lambda sec: sum(1 for p in real if now - p["seen"] < sec)
    paid_period = sum(n or 0 for uid, n, ts in pays if ts >= t0)
    payers_period = len({uid for uid, n, ts in pays if ts >= t0})
    payers_all = len({uid for uid, n, ts in pays})
    summary = {"total": len(real), "new_day": sum(1 for p in real if now - p["first"] < 86400),
               "new_period": sum(1 for p in real if p["first"] >= t0), "dau": seen_in(86400), "wau": seen_in(7 * 86400),
               "active_period": act_any, "started": sum(1 for p in real if p["floor"] > 0),
               "stars_period": paid_period, "payers_period": payers_period, "payers_all": payers_all,
               "stars_all": sum(n or 0 for uid, n, ts in pays), "fights": len(fights)}
    # ---- where players are, and where those who left stopped
    floors = []
    for lo, hi, lab in FLOOR_BUCKETS:
        inb = [p for p in real if lo <= p["floor"] <= hi]
        floors.append({"lab": lab, "active": sum(1 for p in inb if now - p["seen"] < 3 * 86400),
                       "gone": sum(1 for p in inb if now - p["seen"] >= 7 * 86400 and p["first"] < now - 7 * 86400),
                       "all": len(inb)})
    # ---- walls: bosses and elite floors on the way up
    per = {}
    for uid, room, kind, win, tries, dur, cls, ts, qv, auto in fights:
        if kind == "n":
            continue
        r = per.setdefault(room, {"room": room, "kind": kind, "att": 0, "wins": 0, "players": set(), "cleared": set(), "tries": [], "first": 0, "dur": [], "qw": [], "ql": []})
        r["att"] += 1
        r["players"].add(uid)
        if win:
            if uid not in r["cleared"]:
                r["cleared"].add(uid)
                r["tries"].append(tries)
                if tries == 1:
                    r["first"] += 1
            r["wins"] += 1
            r["dur"].append(dur)
            r["qw"].append(qv)
        else:
            r["ql"].append(qv)
    walls = []
    for room in sorted(per):
        r = per[room]
        np_ = len(r["players"])
        if np_ == 0:
            continue
        walls.append({"room": room, "kind": r["kind"], "players": np_, "cleared": len(r["cleared"]), "att": r["att"],
                      "win": round(100 * r["wins"] / r["att"]), "tries": round(sum(r["tries"]) / len(r["tries"]), 1) if r["tries"] else None,
                      "first": round(100 * r["first"] / len(r["cleared"])) if r["cleared"] else None,
                      "stuck": np_ - len(r["cleared"]), "dur": round(_median(r["dur"])) if r["dur"] else None,
                      "qw": round(sum(r["qw"]) / len(r["qw"]) / 10, 1) if r["qw"] else None,
                      "ql": round(sum(r["ql"]) / len(r["ql"]) / 10, 1) if r["ql"] else None})
    # the hardest floors: most losses per player who came there (any kind, at least 3 players)
    lossy = {}
    for uid, room, kind, win, tries, dur, cls, ts, qv, auto in fights:
        x = lossy.setdefault(room, [kind, set(), 0])
        x[1].add(uid)
        x[2] += 0 if win else 1
    hardest = sorted(({"room": r, "kind": v[0], "players": len(v[1]), "loss": round(v[2] / len(v[1]), 1)} for r, v in lossy.items() if len(v[1]) >= 3),
                     key=lambda x: -x["loss"])[:12]
    # ---- classes
    cl = {}
    for p in real:
        if not p["cls"]:
            continue
        c = cl.setdefault(p["cls"], {"cls": p["cls"], "ru": CLS_RU.get(p["cls"], p["cls"]), "players": 0, "active": 0, "floors": [], "band": {b[2]: [0, 0] for b in BANDS},
                                     "bw": 0, "ba": 0, "nw": 0, "na": 0, "btries": []})
        c["players"] += 1
        c["active"] += 1 if now - p["seen"] < 7 * 86400 else 0
        c["floors"].append(p["floor"])
    for uid, room, kind, win, tries, dur, cls, ts, qv, auto in fights:
        c = cl.get(cls)
        if not c:
            continue
        if kind == "b":
            c["ba"] += 1
            c["bw"] += win
            if win:
                c["btries"].append(tries)
            for lo, hi, lab in BANDS:
                if lo <= room <= hi:
                    c["band"][lab][0] += win
                    c["band"][lab][1] += 1
        else:
            c["na"] += 1
            c["nw"] += win
    classes = []
    for c in sorted(cl.values(), key=lambda c: -c["players"]):
        classes.append({"cls": c["cls"], "ru": c["ru"], "players": c["players"], "active": c["active"],
                        "floor_med": round(_median(c["floors"])), "floor_max": max(c["floors"] or [0]),
                        "boss_win": round(100 * c["bw"] / c["ba"]) if c["ba"] else None, "boss_att": c["ba"],
                        "boss_tries": round(sum(c["btries"]) / len(c["btries"]), 1) if c["btries"] else None,
                        "norm_win": round(100 * c["nw"] / c["na"]) if c["na"] else None,
                        "band": {k: (round(100 * v[0] / v[1]) if v[1] >= 5 else None) for k, v in c["band"].items()}})
    # ---- stars: what they buy, and whether right after losing
    losses = {}
    for uid, room, kind, win, tries, dur, cls, ts, qv, auto in fights:
        if not win:
            losses.setdefault(uid, []).append(ts)
    buys = {}
    after_loss = 0
    for uid, what, n, ts in spend:
        key = what.split(":")[0]
        b = buys.setdefault(key, {"what": key, "ru": SPEND_RU.get(key, key), "stars": 0, "times": 0, "people": set()})
        b["stars"] += n or 0
        b["times"] += 1
        b["people"].add(uid)
        if any(0 <= ts - t <= 600 for t in losses.get(uid, ())):
            after_loss += 1
    spend_list = sorted(({"what": b["what"], "ru": b["ru"], "stars": b["stars"], "times": b["times"], "people": len(b["people"])} for b in buys.values()),
                        key=lambda x: -x["stars"])
    payer_floor = [p["floor"] for p in real if p["paid"] > 0]
    stars = {"spend": spend_list, "after_loss": round(100 * after_loss / len(spend)) if spend else None, "buys": len(spend),
             "payer_floor_med": round(_median(payer_floor)) if payer_floor else None,
             "conv": round(100 * payers_period / act_any, 1) if act_any else None}
    # ---- people: the most recently seen first
    people = sorted(({"name": p["name"], "un": p["un"], "cls": CLS_RU.get(p["cls"], p["cls"]), "floor": p["floor"], "level": p["level"],
                      "seen": int(p["seen"]), "first": int(p["first"]), "paid": p["paid"], "flag": p["flag"]} for p in P.values()),
                    key=lambda x: -x["seen"])[:500]
    return 200, {"ok": True, "days": days, "now": int(now), "tz": AC_TZ_S, "summary": summary, "series": series, "floors": floors,
                 "walls": walls, "hardest": hardest, "classes": classes, "stars": stars, "people": people}

STATS_PAGE = r"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Статистика еБашни</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:#0f0c17;--card:#1a1526;--card2:#221b31;--line:#2e2540;--tx:#ece6f5;--mut:#9a90ad;--gold:#f2c14e;--good:#5fd38a;--bad:#ff6b6b;--warn:#ffb347;--blue:#6ab0ff;--violet:#b48cff}
*{box-sizing:border-box}html,body{margin:0;background:var(--bg);color:var(--tx);font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;-webkit-text-size-adjust:100%}
body{padding:12px 12px calc(24px + env(safe-area-inset-bottom))}
h1{font-size:18px;margin:2px 0 10px;display:flex;align-items:center;gap:8px}h1 small{color:var(--mut);font-weight:400;font-size:12px;margin-left:auto}
h2{font-size:15px;margin:0 0 4px}.sub{color:var(--mut);font-size:12px;margin:0 0 10px}
.bar{display:flex;gap:6px;overflow-x:auto;margin:0 -12px 10px;padding:0 12px;scrollbar-width:none}.bar::-webkit-scrollbar{display:none}
.chip{flex:none;border:1px solid var(--line);background:var(--card);color:var(--tx);border-radius:16px;padding:6px 12px;font:inherit;font-size:13px}
.chip.on{background:var(--gold);color:#1a1300;border-color:var(--gold);font-weight:600}
.per .chip{padding:4px 10px;font-size:12px}.tabs{flex-wrap:wrap;overflow:visible}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px;margin-bottom:10px}
.kpis{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:10px}@media(min-width:560px){.kpis{grid-template-columns:repeat(3,1fr)}}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 12px}.kpi b{display:block;font-size:22px;line-height:1.1;font-variant-numeric:tabular-nums}.kpi span{color:var(--mut);font-size:12px}
.kpi i{font-style:normal;font-size:12px;color:var(--mut)}
.note{background:var(--card2);border-left:3px solid var(--gold);border-radius:6px;padding:8px 10px;margin:8px 0 0;font-size:13px}
.note.bad{border-color:var(--bad)}.note.good{border-color:var(--good)}
svg{display:block;width:100%;height:auto}svg text{font:10px -apple-system,Roboto,sans-serif;fill:var(--mut)}
.legend{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--mut);margin-top:6px}.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
.hb{display:grid;grid-template-columns:84px 1fr 56px;align-items:center;gap:8px;margin:5px 0;font-size:12px}
.hb .lab{color:var(--mut);text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.hb .v{font-variant-numeric:tabular-nums;color:var(--tx)}
.track{height:14px;background:var(--card2);border-radius:4px;display:flex;overflow:hidden}.track>div{height:100%}
table{width:100%;border-collapse:collapse;font-size:12px;font-variant-numeric:tabular-nums}th{color:var(--mut);font-weight:500;text-align:right;padding:4px 4px 6px;border-bottom:1px solid var(--line);white-space:nowrap}
td{text-align:right;padding:6px 4px;border-bottom:1px solid var(--line);white-space:nowrap}th:first-child,td:first-child{text-align:left}tr:last-child td{border-bottom:0}
.tw{overflow-x:auto;margin:0 -4px}
.pill{display:inline-block;min-width:38px;text-align:center;border-radius:5px;padding:1px 5px;font-weight:600}
.k-b{color:var(--bad)}.k-e{color:var(--violet)}
.tag{display:inline-block;font-size:10px;border-radius:4px;padding:0 4px;margin-left:4px;vertical-align:1px}.tag.b{background:#4a1f24;color:#ff9b9b}.tag.e{background:#2f2448;color:#cbb2ff}
input[type=search]{width:100%;background:var(--card2);border:1px solid var(--line);color:var(--tx);border-radius:10px;padding:8px 10px;font:inherit;margin-bottom:8px}
.ppl{display:flex;flex-direction:column}.pp{display:grid;grid-template-columns:1fr auto;gap:2px 8px;padding:8px 2px;border-bottom:1px solid var(--line)}
.pp .n{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pp .m{color:var(--mut);font-size:12px}.pp .r{text-align:right;font-variant-numeric:tabular-nums}
.empty{color:var(--mut);text-align:center;padding:18px 6px}
.err{color:var(--bad);text-align:center;padding:30px 10px}
.load{color:var(--mut);text-align:center;padding:40px 10px}
.dot{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px;vertical-align:1px}
</style></head><body>
<h1>📊 Статистика <small id="upd"></small></h1>
<div class="bar per" id="per"></div>
<div class="bar tabs" id="tabs"></div>
<div id="v"><div class="load">Загружаем…</div></div>
<script>
const W=window.Telegram&&Telegram.WebApp;try{W.ready();W.expand();W.setHeaderColor&&W.setHeaderColor('#0f0c17');W.setBackgroundColor&&W.setBackgroundColor('#0f0c17');}catch(e){}
const $=id=>document.getElementById(id),esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=n=>n==null?'—':Number(n).toLocaleString('ru-RU');
let D=null,days=30,tab='over',q='';
try{days=+localStorage.getItem('st.days')||30;tab=localStorage.getItem('st.tab')||'over';}catch(e){}
const TABS=[['over','Обзор'],['walls','Где застревают'],['cls','Классы'],['stars','Звёзды'],['ppl','Игроки']];
function chips(){
  $('per').innerHTML=[7,30,90].map(d=>`<button class="chip${d===days?' on':''}" data-d="${d}">${d} дней</button>`).join('');
  $('tabs').innerHTML=TABS.map(([k,l])=>`<button class="chip${k===tab?' on':''}" data-t="${k}">${l}</button>`).join('');}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
  if(b.dataset.d){days=+b.dataset.d;try{localStorage.setItem('st.days',days)}catch(x){}chips();load();}
  if(b.dataset.t){tab=b.dataset.t;try{localStorage.setItem('st.tab',tab)}catch(x){}chips();draw();}});
async function load(){
  if(!W||!W.initData){$('v').innerHTML='<div class="err">Открой страницу кнопкой «Открыть статистику» в боте — так она знает, что это ты.</div>';return;}
  $('v').innerHTML='<div class="load">Загружаем…</div>';
  try{const r=await fetch('/api/admin/dash?days='+days,{headers:{'X-Init-Data':W.initData}});
    if(r.status===403){$('v').innerHTML='<div class="err">Эта страница только для владельца игры.</div>';return;}
    if(!r.ok)throw 0;D=await r.json();$('upd').textContent='обновлено '+new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});draw();}
  catch(e){$('v').innerHTML='<div class="err">Не удалось загрузить. Потяни вниз или открой ещё раз.</div>';}}
function draw(){if(!D)return;const f={over,walls,cls,stars,ppl}[tab]||over;$('v').innerHTML=f();if(tab==='ppl'){const i=$('q');i.value=q;i.oninput=()=>{q=i.value;$('pl').innerHTML=pplRows();};}}
/* ---- small charts ---- */
function cols(series,keys,colors,h=150,labelEvery){
  const n=series.length,Wd=340,pad=22,bw=(Wd-pad)/n,max=Math.max(1,...series.map(s=>Math.max(...keys.map(k=>s[k]||0))));
  const step=niceStep(max),top=Math.ceil(max/step)*step;let g='';
  for(let v=0;v<=top;v+=step){const y=h-14-(h-24)*v/top;g+=`<line x1="${pad}" x2="${Wd}" y1="${y}" y2="${y}" stroke="#2e2540" stroke-width="1"/><text x="${pad-4}" y="${y+3}" text-anchor="end">${v}</text>`;}
  const per=keys.length,inner=bw*0.78/per;
  series.forEach((s,i)=>{keys.forEach((k,j)=>{const v=s[k]||0,bh=(h-24)*v/top,x=pad+i*bw+bw*0.11+j*inner,y=h-14-bh;
    if(v>0)g+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${Math.max(1,inner-0.6).toFixed(1)}" height="${bh.toFixed(1)}" rx="1.5" fill="${colors[j]}"/>`;});
    const le=labelEvery||Math.ceil(n/7);if((i%le===0&&i<n-le/2)||i===n-1)g+=`<text x="${i===n-1?Wd:pad+i*bw+bw/2}" y="${h-2}" text-anchor="${i===n-1?'end':'middle'}">${s.date}</text>`;});
  return `<svg viewBox="0 0 ${Wd} ${h}">${g}</svg>`;}
function niceStep(m){const r=m/4,p=Math.pow(10,Math.floor(Math.log10(r||1))),k=r/p;return Math.max(1,(k<=1?1:k<=2?2:k<=5?5:10)*p);}
function hbars(rows){const max=Math.max(1,...rows.map(r=>r.parts.reduce((a,p)=>a+p.v,0)));
  return rows.map(r=>{const tot=r.parts.reduce((a,p)=>a+p.v,0);return `<div class="hb"><span class="lab">${esc(r.lab)}</span><div class="track">${r.parts.map(p=>p.v?`<div style="width:${100*p.v/max}%;background:${p.c}"></div>`:'').join('')}</div><span class="v">${r.txt!=null?r.txt:fmt(tot)}</span></div>`;}).join('');}
const leg=a=>`<div class="legend">${a.map(([c,t])=>`<span><i style="background:${c}"></i>${t}</span>`).join('')}</div>`;
const tone=(v,good,bad,rev)=>{if(v==null)return '';const g=rev?v<=good:v>=good,b=rev?v>=bad:v<=bad;return g?'background:#1d3b2a;color:#7fe0a3':b?'background:#4a1f24;color:#ff9b9b':'background:#3d3220;color:#ffd27a';};
const ago=t=>{if(!t)return '—';const s=D.now-t;return s<3600?Math.max(1,Math.round(s/60))+' мин назад':s<86400?Math.round(s/3600)+' ч назад':Math.round(s/86400)+' дн назад';};
const kpi=(v,l,x)=>`<div class="kpi"><b>${v}</b><span>${l}</span>${x?`<br><i>${x}</i>`:''}</div>`;
/* ---- tabs ---- */
function over(){const S=D.summary,se=D.series;
  const fl=D.floors.filter(r=>r.lab!=='0'||r.all);const worst=[...D.floors].filter(r=>r.lab!=='0').sort((a,b)=>b.gone-a.gone)[0];
  const lastAct=se.slice(-7).reduce((a,s)=>a+s.act,0),prevAct=se.slice(-14,-7).reduce((a,s)=>a+s.act,0);
  return `<div class="kpis">
    ${kpi(fmt(S.total),'игроков всего',`начали играть: ${fmt(S.started)}`)}
    ${kpi(fmt(S.new_period),'новых за '+D.days+' дн',`за сутки: ${fmt(S.new_day)}`)}
    ${kpi(fmt(S.dau),'заходили за сутки',`за неделю: ${fmt(S.wau)}`)}
    ${kpi(fmt(S.stars_period)+' ★','звёзд за '+D.days+' дн',`всего: ${fmt(S.stars_all)} ★`)}
    ${kpi(fmt(S.payers_period),'платили за '+D.days+' дн',`за всё время: ${fmt(S.payers_all)}`)}
    ${kpi(S.active_period?(Math.round(1000*S.payers_period/S.active_period)/10+'%'):'—','платящих среди активных','')}
  </div>
  <div class="card"><h2>Игроки по дням</h2><p class="sub">Сколько человек заходило и сколько пришло новых. Заходы считаются с этого обновления.</p>
    ${cols(se,['act','new'],['#6ab0ff','#f2c14e'])}${leg([['#6ab0ff','заходили'],['#f2c14e','новые']])}
    ${prevAct&&lastAct?`<div class="note ${lastAct>=prevAct?'good':'bad'}">За последние 7 дней заходов ${lastAct>=prevAct?'больше':'меньше'}, чем неделей раньше: ${fmt(lastAct)} против ${fmt(prevAct)}.</div>`:''}</div>
  <div class="card"><h2>Звёзды по дням</h2><p class="sub">Сколько звёзд купили (без возвратов).</p>${cols(se,['stars'],['#f2c14e'])}</div>
  <div class="card"><h2>На каких этажах игроки</h2><p class="sub">По самому высокому пройденному этажу. Зелёным — заходили за 3 дня, красным — не заходят неделю и дольше.</p>
    ${hbars(fl.map(r=>({lab:r.lab,parts:[{v:r.active,c:'#5fd38a'},{v:r.all-r.active-r.gone,c:'#4b4160'},{v:r.gone,c:'#ff6b6b'}],txt:fmt(r.all)})))}
    ${leg([['#5fd38a','играют'],['#4b4160','иногда'],['#ff6b6b','ушли']])}
    ${worst&&worst.gone?`<div class="note bad">Больше всего ушедших на этажах <b>${esc(worst.lab)}</b>: ${fmt(worst.gone)} чел.</div>`:''}</div>`;}
function walls(){const W2=D.walls.filter(w=>w.kind==='b'),E=D.walls.filter(w=>w.kind==='e'),H=D.hardest;
  if(!D.walls.length&&!H.length)return `<div class="card empty">Данные о боях начнут копиться после обновления игры. Загляни через день-два.</div>`;
  const row=w=>`<tr><td><b>${w.room}</b></td><td>${fmt(w.players)}</td><td>${fmt(w.cleared)}</td><td><span class="pill" style="${tone(w.stuck/w.players*100,15,40,1)}">${fmt(w.stuck)}</span></td><td><span class="pill" style="${tone(w.first,60,30)}">${w.first==null?'—':w.first+'%'}</span></td><td><span class="pill" style="${tone(w.tries,1.6,3,1)}">${w.tries==null?'—':String(w.tries).replace('.',',')}</span></td><td>${w.dur==null?'—':w.dur+'с'}</td></tr>`;
  const tbl=(rows,t)=>rows.length?`<div class="tw"><table><tr><th>Этаж</th><th>Дошли</th><th>Прошли</th><th>Застряли</th><th>С 1-й</th><th>Попыток</th><th>Бой</th></tr>${rows.map(row).join('')}</table></div>`:`<div class="empty">${t}</div>`;
  const top=[...W2].filter(w=>w.players>=3).sort((a,b)=>(b.stuck/b.players)-(a.stuck/a.players))[0];
  return `<div class="card"><h2>Самые трудные этажи</h2><p class="sub">Сколько поражений в среднем приходится на одного игрока, который туда дошёл (от 3 игроков).</p>
    ${H.length?hbars(H.map(h=>({lab:h.room+(h.kind==='b'?' 👑':h.kind==='e'?' ⚔':''),parts:[{v:h.loss,c:h.kind==='b'?'#ff6b6b':h.kind==='e'?'#b48cff':'#6ab0ff'}],txt:String(h.loss).replace('.',',')}))):'<div class="empty">Пока мало данных.</div>'}
    ${leg([['#ff6b6b','босс 👑'],['#b48cff','элита ⚔'],['#6ab0ff','обычный']])}</div>
  <div class="card"><h2>Боссы этажей</h2><p class="sub">Только первые прохождения. «Застряли» — дошли, но ещё не прошли. «Попыток» — сколько боёв нужно в среднем до победы.</p>
    ${tbl(W2,'Пока никто не дрался с боссом за этот период.')}
    ${top&&top.stuck?`<div class="note bad">Главная стена — босс <b>${top.room}</b> этажа: застряли ${fmt(top.stuck)} из ${fmt(top.players)}.</div>`:''}</div>
  <div class="card"><h2>Элитные этажи</h2>${tbl(E,'Пока нет данных.')}</div>`;}
function cls(){const C=D.classes;if(!C.length)return '<div class="card empty">Нет данных.</div>';
  const bands=Object.keys(C[0].band);
  const best=[...C].filter(c=>c.boss_att>=20).sort((a,b)=>b.boss_win-a.boss_win),hi=best[0],lo=best[best.length-1];
  return `<div class="card"><h2>Классы</h2><p class="sub">Сколько играют и как далеко зашли. «Медиана» — этаж, до которого дошла половина игроков класса.</p>
    ${hbars(C.map(c=>({lab:c.ru,parts:[{v:c.active,c:'#5fd38a'},{v:c.players-c.active,c:'#4b4160'}],txt:fmt(c.players)})))}${leg([['#5fd38a','заходили за неделю'],['#4b4160','остальные']])}
    <div class="tw" style="margin-top:10px"><table><tr><th>Класс</th><th>Медиана</th><th>Макс.</th><th>Обычные</th><th>Боссы</th><th>Попыток</th></tr>
    ${C.map(c=>`<tr><td>${esc(c.ru)}</td><td>${fmt(c.floor_med)}</td><td>${fmt(c.floor_max)}</td><td>${c.norm_win==null?'—':c.norm_win+'%'}</td><td><span class="pill" style="${tone(c.boss_win,55,35)}">${c.boss_win==null?'—':c.boss_win+'%'}</span></td><td>${c.boss_tries==null?'—':String(c.boss_tries).replace('.',',')}</td></tr>`).join('')}</table></div></div>
  <div class="card"><h2>Победы над боссами по высоте</h2><p class="sub">Доля выигранных боёв с боссами на новых этажах. Пусто — меньше 5 боёв.</p>
    <div class="tw"><table><tr><th>Класс</th>${bands.map(b=>`<th>${b}</th>`).join('')}</tr>
    ${C.map(c=>`<tr><td>${esc(c.ru)}</td>${bands.map(b=>{const v=c.band[b];return `<td><span class="pill" style="${tone(v,55,35)}">${v==null?'—':v+'%'}</span></td>`;}).join('')}</tr>`).join('')}</table></div>
    ${hi&&lo&&hi!==lo&&hi.boss_win-lo.boss_win>=15?`<div class="note">Разрыв по боссам: ${esc(hi.ru)} ${hi.boss_win}% против ${esc(lo.ru)} ${lo.boss_win}%.</div>`:''}</div>`;}
function stars(){const St=D.stars,S=D.summary,sp=St.spend;
  return `<div class="kpis">
    ${kpi(fmt(S.stars_period)+' ★','куплено за '+D.days+' дн','')}
    ${kpi(fmt(S.payers_period),'платили за '+D.days+' дн','')}
    ${kpi(St.conv==null?'—':String(St.conv).replace('.',',')+'%','платят из активных','')}
    ${kpi(St.after_loss==null?'—':St.after_loss+'%','трат сразу после поражения','в течение 10 минут')}
    ${kpi(St.payer_floor_med==null?'—':fmt(St.payer_floor_med),'медианный этаж платящих','')}
    ${kpi(fmt(St.buys),'покупок за '+D.days+' дн','')}
  </div>
  <div class="card"><h2>На что тратят звёзды</h2><p class="sub">Сколько звёзд ушло на каждую вещь за период и сколько человек покупали.</p>
    ${sp.length?hbars(sp.map(x=>({lab:x.ru.length>12?x.ru.slice(0,11)+"…":x.ru,parts:[{v:x.stars,c:'#f2c14e'}],txt:fmt(x.stars)+' ★'}))):'<div class="empty">За этот период трат не было.</div>'}
    ${sp.length?`<div class="tw" style="margin-top:8px"><table><tr><th>Что</th><th>Звёзд</th><th>Покупок</th><th>Людей</th></tr>${sp.map(x=>`<tr><td>${esc(x.ru)}</td><td>${fmt(x.stars)}</td><td>${fmt(x.times)}</td><td>${fmt(x.people)}</td></tr>`).join('')}</table></div>`:''}</div>
  <div class="card"><h2>Платящие по дням</h2>${cols(D.series,['payers'],['#b48cff'])}</div>`;}
function pplRows(){const s=q.trim().toLowerCase();const L=D.people.filter(p=>!s||(p.name+' '+p.un+' '+p.cls).toLowerCase().includes(s)).slice(0,200);
  if(!L.length)return '<div class="empty">Никого не нашли.</div>';
  return L.map(p=>{const on=D.now-p.seen<86400*3;return `<div class="pp"><div class="n"><span class="dot" style="background:${on?'#5fd38a':'#4b4160'}"></span>${esc(p.name)}${p.un?` <span class="m">@${esc(p.un)}</span>`:''}${p.flag?' <span class="tag b">флаг</span>':''}</div>
    <div class="r"><b>${fmt(p.floor)}</b> <span class="m">эт.</span></div><div class="m">${esc(p.cls||'без класса')} · ${p.level} ур. · ${ago(p.seen)}</div><div class="r m">${p.paid?`<span style="color:#f2c14e">${fmt(p.paid)} ★</span>`:''}</div></div>`;}).join('');}
function ppl(){return `<div class="card"><input id="q" type="search" placeholder="Поиск по имени или классу"><div class="ppl" id="pl">${pplRows()}</div></div>`;}
chips();load();
</script>
</body></html>
"""

# ---------------------------------------------------------------- bot: /start opens the game, inline "raid" invites a group
def tg(method, **params):
    req = urllib.request.Request(f"https://api.telegram.org/bot{BOT_TOKEN}/{method}",
                                 data=json.dumps(params).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.loads(r.read())

def tg_multipart(method, files, **params):
    """Bot API call with file parts. files: {field: (filename, bytes, content_type)}."""
    boundary = "----EmberForm" + hashlib.md5(os.urandom(8)).hexdigest()
    chunks = []
    for k, v in params.items():
        if v is None:
            continue
        if isinstance(v, (dict, list, bool)):
            v = json.dumps(v)
        else:
            v = str(v)
        chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
    for name, (filename, raw, ctype) in files.items():
        chunks.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\nContent-Type: {ctype}\r\n\r\n".encode()
        )
        chunks.append(raw)
        chunks.append(b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/{method}",
        data=b"".join(chunks),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read())
        except Exception:
            return {"ok": False, "error_code": e.code, "description": str(e)}
    except Exception as e:
        return {"ok": False, "error_code": 0, "description": str(e)}

def app_link(param=""):
    return f"https://t.me/{BOT_USERNAME}/{APP_NAME}" + (f"?startapp={param}" if param else "")

_bot_card_fid = {}
def bot_card_file_id(name):
    """Telegram often cannot fetch WEBAPP_URL/bot/*.jpg for inline photo results (same black/empty
    preview problem as share cards). Upload once to an admin chat and reuse file_id."""
    key = name + ":" + BOT_CARDS_V
    if key in _bot_card_fid:
        return _bot_card_fid[key]
    cached = _kv("bcfid:" + key)
    if isinstance(cached, str) and cached:
        _bot_card_fid[key] = cached
        return cached
    path = os.path.join(HERE, "public", "bot", name + ".jpg")
    if not os.path.isfile(path):
        return None
    chat = next(iter(ADMIN_IDS), None)
    if not chat:
        return None
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
        r = tg_multipart("sendPhoto", {"photo": (name + ".jpg", raw, "image/jpeg")},
                         chat_id=chat, disable_notification=True)
        if not r.get("ok"):
            log.warning("bot_card upload %s: %s", name, r)
            return None
        msg = r.get("result") or {}
        sizes = msg.get("photo") or []
        fid = sizes[-1].get("file_id") if sizes else None
        mid = msg.get("message_id")
        if mid:
            tg_try("deleteMessage", chat_id=chat, message_id=mid)
        if fid:
            _bot_card_fid[key] = fid
            _kv("bcfid:" + key, fid)
        return fid
    except Exception as e:
        log.warning("bot_card_file_id %s: %s", name, e)
        return None

def answer_inline(q):
    """The game's «Позвать чат в игру» / «@bot raid»: invite card + way to bring a boss into a chat.
    Prefer a cached photo_file_id; never upload during the query (Telegram drops slow answers).
    Fall back to an article so the query never shows empty results."""
    cap = ("🔥 <b>Зову в еБашню!</b>\nПиксельная башня, где герой сам дерётся, а ты одеваешь его и лезешь всё выше.\n\n"
           "👹 Хотите общего босса на весь чат? Добавьте бота — он покажет боссов, админ выберет, и весь чат бьёт наперегонки.")
    kb = {"inline_keyboard": [[{"text": "🎮 Играть", "url": app_link()}],
                              [{"text": "👹 Добавить бота и призвать босса", "url": startgroup_link()}]]}
    key = "invite:" + BOT_CARDS_V
    fid = _bot_card_fid.get(key)
    if not fid:
        cached = _kv("bcfid:" + key)
        if isinstance(cached, str) and cached:
            fid = _bot_card_fid[key] = cached
    if fid:
        results = [{"type": "photo", "id": "invite2", "photo_file_id": fid,
                    "title": "Позвать чат в еБашню", "description": "Приглашение в игру и босс чата",
                    "caption": cap, "parse_mode": "HTML", "reply_markup": kb}]
    else:
        results = [{"type": "article", "id": "invite2",
                    "title": "Позвать чат в еБашню", "description": "Приглашение в игру и босс чата",
                    "input_message_content": {"message_text": cap, "parse_mode": "HTML"},
                    "reply_markup": kb}]
        threading.Thread(target=lambda: bot_card_file_id("invite"), daemon=True).start()
    try:
        tg("answerInlineQuery", inline_query_id=q["id"], cache_time=10, is_personal=False, results=results)
    except Exception as e:
        log.warning("inline photo answer: %s", e)
        tg("answerInlineQuery", inline_query_id=q["id"], cache_time=5, is_personal=False, results=[{
            "type": "article", "id": "invite2",
            "title": "Позвать чат в еБашню", "description": "Приглашение в игру и босс чата",
            "input_message_content": {"message_text": cap, "parse_mode": "HTML"},
            "reply_markup": kb}])

CLS_RU = {"knight": "Рыцарь", "gunner": "Стрелок", "necro": "Некромант", "assassin": "Ассасин", "gladiator": "Гладиатор", "mage": "Маг",
          "samurai": "Самурай", "duelist": "Дуэлянт", "berserker": "Берсерк", "ranger": "Следопыт", "paladin": "Паладин", "monk": "Монах",
          "shaman": "Шаман", "orc": "Орк", "vampire": "Вампир"}

def stats_command(msg):
    """/статистика (or /stats) in a private chat with the bot, admins only: mini-app totals and who is where.
    "/статистика все" lists everybody, otherwise the 50 seen most recently."""
    chat = msg["chat"]["id"]
    if (msg.get("from") or {}).get("id") not in ADMIN_IDS:
        tg("sendMessage", chat_id=chat, text="⛔ Эта статистика доступна только администраторам.")
        return
    full = "все" in (msg.get("text") or "").lower() or "all" in (msg.get("text") or "").lower()
    now = time.time()
    with db_lock:
        # seen/updated are TIMESTAMP under PostgreSQL, where COALESCE(NULLIF(seen, 0), updated, 0) mixes a timestamp
        # with a number and fails; the same order is applied in Python below instead
        rows = db.execute("SELECT id, name, username, cls, room, level, seen, updated FROM players").fetchall()
        lv = {}
        for uid, data in db.execute("SELECT uid, data FROM saves"):
            try:
                d = json.loads(data)
                lv[uid] = (int(d.get("level") or 0), int(d.get("maxCleared") or 0), str(d.get("cls") or ""))
            except (ValueError, TypeError):
                pass
        nft_ln = nft_stats_line()
        can_pm = db.execute("SELECT COUNT(*) FROM players WHERE can_pm=1").fetchone()[0]
    def last(r):
        return r[6] or r[7] or 0
    rows.sort(key=last, reverse=True)      # most recently seen first (SQLite and PostgreSQL alike)
    total = len(rows)
    d1 = sum(1 for r in rows if now - last(r) < 86400)
    d7 = sum(1 for r in rows if now - last(r) < 7 * 86400)
    played = sum(1 for r in rows if (r[4] or 0) > 0 or (lv.get(r[0], (0, 0))[1] > 0))
    when = lambda t: time.strftime("%d.%m %H:%M", time.gmtime(t + AC_TZ * 3600)) if t else "—"
    if not full and WEBAPP_URL:
        # v193: a short line and a button; everything else lives on the statistics page
        return tg("sendMessage", chat_id=chat, parse_mode="HTML",
                  text=(f"🎮 <b>Статистика мини-аппа</b>\nИгроков: <b>{total}</b> · за сутки: <b>{d1}</b> · за неделю: <b>{d7}</b>\n"
                        f"Личные сообщения доступны: <b>{can_pm}</b>\n"
                        f"Графики, стены, классы и звёзды — на странице."),
                  reply_markup={"inline_keyboard": [[{"text": "📊 Открыть статистику", "web_app": {"url": WEBAPP_URL + "stats"}}],
                                                    [{"text": "Список текстом", "callback_data": "stats_all"}]]})
    head = (f"🎮 Статистика мини-аппа\n\nВсего игроков: {total}\nХоть раз прошли этаж: {played}\n"
            f"Заходили за сутки: {d1}\nЗаходили за неделю: {d7}\nЛичные сообщения доступны: {can_pm}\n{nft_ln}\n\n"
            + ("Все игроки" if full else f"Последние {min(50, total)} по времени входа") + " (этаж · ур. · вход):")
    lines = []
    for r in (rows if full else rows[:50]):
        uid, name, un, cls, room, level, seen, upd = r
        sl, sf, sc = lv.get(uid, (0, 0, ""))
        who = html_esc(name or "Игрок") + (f" @{html_esc(un)}" if un else "")
        cl = CLS_RU.get(sc or cls or "", "")
        lines.append(f"{who}{' · ' + cl if cl else ''} — эт. {max(room or 0, sf)} · ур. {max(level or 0, sl) or 1} · {when(seen or upd)}")
    if not full and total > 50:
        lines.append("\nВесь список: /статистика все")
    # Telegram takes up to 4096 characters per message
    chunks, cur = [], head
    for ln in lines:
        if len(cur) + len(ln) + 1 > 3900:
            chunks.append(cur)
            cur = ""
        cur += "\n" + ln
    chunks.append(cur)
    for c in chunks:
        tg("sendMessage", chat_id=chat, text=c, parse_mode="HTML", disable_web_page_preview=True)

# ---------- /рассылка: the owner writes once, every player who allowed the bot gets it with a button into the game ----------
BC_BUTTON = "Зайти в еБашню!"
bc_running = threading.Event()

def tg_try(method, **params):
    """Like tg(), but Telegram's refusals come back as a dict instead of an exception (403 blocked, 429 slow down, 400 bad)."""
    try:
        return tg(method, **params)
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read())
        except Exception:
            return {"ok": False, "error_code": e.code, "description": str(e)}
    except Exception as e:
        return {"ok": False, "error_code": 0, "description": str(e)}

def bc_markup():
    return {"inline_keyboard": [[{"text": BC_BUTTON, "web_app": {"url": WEBAPP_URL}}]]} if WEBAPP_URL else \
           {"inline_keyboard": [[{"text": BC_BUTTON, "url": app_link()}]]}

def bc_send(job, chat_id):
    """One copy of the post: a reply-to post is copied as it is (photo, video, formatting), plain text keeps its formatting."""
    if job.get("copy"):
        extra = {"caption": job["caption"], "caption_entities": job.get("caption_entities") or []} if "caption" in job else {}
        return tg_try("copyMessage", chat_id=chat_id, from_chat_id=job["from"], message_id=job["copy"], reply_markup=bc_markup(), **extra)
    return tg_try("sendMessage", chat_id=chat_id, text=job["text"], entities=job.get("entities") or [],
                  disable_web_page_preview=True, reply_markup=bc_markup())

def bc_targets():
    with db_lock:
        # Mini-app players who allowed PMs plus users who started the main bot.
        # UNION deduplicates people who exist in both games.
        try:
            rows = db.execute("""SELECT id FROM players WHERE can_pm=1
                                 UNION
                                 SELECT telegram_id AS id FROM users
                                 WHERE last_start_at IS NOT NULL AND is_active=TRUE
                                 ORDER BY id""").fetchall()
        except Exception as e:
            # Standalone SQLite installs may not have the main bot's users table.
            log.info("main-bot users unavailable for broadcast; using mini-app players only: %s", e)
            rows = db.execute("SELECT id FROM players WHERE can_pm=1 ORDER BY id").fetchall()
        return [int(r[0]) for r in rows]

def bc_mark_unreachable(uid):
    """Exclude a blocked user from future broadcasts until they start the bot again."""
    with db_lock:
        try:
            db.execute("UPDATE users SET is_active=FALSE WHERE telegram_id=?", (uid,))
        except Exception:
            # The main bot's users table is absent in standalone SQLite mode.
            db.rollback()
        db.execute("UPDATE players SET can_pm=0 WHERE id=?", (uid,))
        db.commit()

def bc_is_unreachable(result):
    if result.get("error_code") == 403:
        return True
    if result.get("error_code") != 400:
        return False
    description = (result.get("description") or "").lower()
    return any(phrase in description for phrase in (
        "chat not found", "user is deactivated", "bot was blocked", "blocked by the user",
        "can't initiate conversation", "cannot initiate conversation",
    ))

def terms_command(msg, cmd):
    """/terms: the rules page; /paysupport: what to do when a purchase went wrong (required for bots that take Stars)."""
    chat_id, url = msg["chat"]["id"], terms_url()
    sup = SUPPORT_URL
    rows = []
    if url:
        rows.append([{"text": "Условия и конфиденциальность", "url": url}])
    if sup:
        rows.append([{"text": "Написать в поддержку", "url": sup}])
    if cmd == "/terms":
        text = ("<b>еБашня · условия</b>\n\n"
                "Игра 18+: в ней есть мат и грубый юмор.\n"
                "Всё в игре, включая звёзды на игровом балансе, — внутриигровые ценности без денежной стоимости.\n"
                "Читы и мультиаккаунты запрещены: за них откатываем прогресс или блокируем.\n"
                "Храним только твой Telegram ID, имя и прогресс — для сохранений, рейтинга и дуэлей. Никому не передаём.\n\n"
                "Полный текст — по кнопке ниже. Играя, ты принимаешь эти условия.")
    else:
        text = ("<b>Помощь с оплатой</b>\n\n"
                "Оплатил звёздами, а покупка не пришла за час? Напиши нам и приложи:\n"
                "• дату и время оплаты\n• сумму в звёздах\n• свой ник в игре\n\n"
                "Проверим и начислим покупку или вернём звёзды через Telegram. Уже полученные и потраченные покупки не возвращаются.\n"
                "Поддержка Telegram и магазинов приложений по этим покупкам не помогает — только мы."
                + ("" if sup else "\n\nПиши прямо сюда, в этот чат."))
    tg("sendMessage", chat_id=chat_id, text=text, parse_mode="HTML", disable_web_page_preview=True,
       **({"reply_markup": {"inline_keyboard": rows}} if rows else {}))

def broadcast_command(msg):
    """/рассылка (or /broadcast), owner only, in the bot's private chat.
       «/рассылка текст» sends that text; a reply «/рассылка» to any message (photo, video, formatted text) sends that message.
       The bot first shows exactly how it will look, then asks to confirm."""
    me = (msg.get("from") or {}).get("id")
    if me not in ADMIN_IDS:
        return
    chat = msg["chat"]["id"]
    media = not msg.get("text") and any(k in msg for k in ("photo", "video", "animation", "document", "audio", "voice", "video_note"))
    text = msg.get("text") or msg.get("caption") or ""
    cut = len(text.split()[0]) if text.split() else 0
    body = text[cut:]
    lead = len(body) - len(body.lstrip())
    body = body.strip()
    rep_msg = msg.get("reply_to_message")
    # Telegram counts formatting offsets in UTF-16 units
    u16 = lambda x: len(x.encode("utf-16-le")) // 2
    shift = u16(text[:cut + lead])
    def shifted(lst):
        out = []
        for e in lst or []:
            if e.get("type") == "bot_command" and e.get("offset") == 0:
                continue
            e = dict(e)
            e["offset"] -= shift
            if e["offset"] >= 0:
                out.append(e)
        return out
    if media:
        # a photo or video sent with the caption «/рассылка текст»: that file goes out, the caption without the command
        job = {"copy": msg["message_id"], "from": chat, "caption": body, "caption_entities": shifted(msg.get("caption_entities"))}
    elif rep_msg:
        job = {"copy": rep_msg["message_id"], "from": chat}
    elif body:
        ents = []
        for e in msg.get("entities") or []:
            if e.get("type") == "bot_command" and e.get("offset") == 0:
                continue
            e = dict(e)
            e["offset"] -= shift
            if e["offset"] >= 0:
                ents.append(e)
        job = {"text": body, "entities": ents}
    else:
        tg("sendMessage", chat_id=chat, parse_mode="HTML", text=
           "<b>Рассылка всем пользователям</b>\n\n"
           "• <code>/рассылка текст</code> — разослать текст (жирный, курсив и ссылки сохранятся)\n"
           "• фото, видео или гифка с подписью <code>/рассылка текст</code> — разошлю файл с этой подписью\n"
           "• или ответь командой <code>/рассылка</code> на любое своё сообщение — с картинкой, видео, чем угодно\n\n"
           "В аудиторию входят игроки мини-аппа и пользователи, которые запускали основной бот.\n"
           f"Под каждым сообщением будет кнопка «{BC_BUTTON}». Сначала покажу, как это будет выглядеть, и спрошу подтверждение.")
        return
    if bc_running.is_set():
        tg("sendMessage", chat_id=chat, text="Предыдущая рассылка ещё идёт — дождись отчёта.")
        return
    n = len(bc_targets())
    tg("sendMessage", chat_id=chat, text="Вот так увидят игроки:")
    pv = bc_send(job, chat)
    if not pv.get("ok"):
        tg("sendMessage", chat_id=chat, text=f"Telegram не принял сообщение: {pv.get('description', '?')}")
        return
    key = "bc:" + hashlib.sha1(f"{chat}:{time.time()}".encode()).hexdigest()[:10]
    with db_lock:
        db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (key, json.dumps(job)))
        db.commit()
    tg("sendMessage", chat_id=chat, text=f"Отправить это {n} {plural_ru(n, 'игроку', 'игрокам', 'игрокам')}?\n"
       "(игроки мини-аппа и те, кто запускал основной бот; заблокировавшие бота исключаются)",
       reply_markup={"inline_keyboard": [[{"text": f"✅ Отправить всем ({n})", "callback_data": key + ":go"},
                                          {"text": "Отмена", "callback_data": key + ":no"}]]})

def plural_ru(n, one, few, many):
    n = abs(n) % 100
    return few if 2 <= n % 10 <= 4 and not 12 <= n <= 14 else one if n % 10 == 1 and n != 11 else many

def broadcast_callback(cq):
    me = (cq.get("from") or {}).get("id")
    data = cq.get("data") or ""
    m = cq.get("message") or {}
    if me not in ADMIN_IDS or not data.startswith("bc:"):
        tg_try("answerCallbackQuery", callback_query_id=cq["id"])
        return
    key, _, act = data.rpartition(":")
    with db_lock:
        row = db.execute("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
        db.execute("DELETE FROM kv WHERE k=?", (key,))
        db.commit()
    chat, mid = m.get("chat", {}).get("id"), m.get("message_id")
    if not row:
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Эта рассылка уже отправлена или отменена")
        return
    if act != "go":
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Отменено")
        tg_try("editMessageText", chat_id=chat, message_id=mid, text="Рассылка отменена.")
        return
    if bc_running.is_set():
        tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Предыдущая рассылка ещё идёт")
        return
    tg_try("answerCallbackQuery", callback_query_id=cq["id"], text="Поехали")
    job = json.loads(row[0])
    bc_running.set()
    threading.Thread(target=broadcast_run, args=(job, chat, mid), daemon=True).start()

def broadcast_run(job, chat, mid):
    """About 20 messages a second (Telegram allows 30); those who blocked the bot are marked and skipped next time."""
    try:
        ids = bc_targets()
        ok = blocked = failed = 0
        t0 = time.time()
        tg_try("editMessageText", chat_id=chat, message_id=mid, text=f"Рассылка идёт: 0 из {len(ids)}…")
        for i, uid in enumerate(ids, 1):
            for _ in range(3):
                r = bc_send(job, uid)
                if r.get("ok"):
                    ok += 1
                    break
                code = r.get("error_code")
                if code == 429:
                    time.sleep(int((r.get("parameters") or {}).get("retry_after", 3)) + 1)
                    continue
                if bc_is_unreachable(r):
                    blocked += 1
                    bc_mark_unreachable(uid)
                else:
                    failed += 1
                break
            else:
                failed += 1
            time.sleep(0.05)
            if i % 200 == 0:
                tg_try("editMessageText", chat_id=chat, message_id=mid, text=f"Рассылка идёт: {i} из {len(ids)}…")
        took = int(time.time() - t0)
        tg_try("editMessageText", chat_id=chat, message_id=mid, text=
               f"Рассылка готова за {took // 60} мин {took % 60} с.\n"
               f"Доставлено: {ok}\nЗаблокировали бота или недоступны: {blocked}\nДругие ошибки: {failed}")
        log.info("broadcast: %s ok, %s blocked, %s failed", ok, blocked, failed)
    except Exception as e:
        log.warning("broadcast: %s", e)
        tg_try("sendMessage", chat_id=chat, text=f"Рассылка оборвалась: {e}")
    finally:
        bc_running.clear()

def _handle_update_safe(upd):
    """Runs a relayed update off the HTTP thread; a bad update must not kill the request."""
    try:
        handle_update(upd)
    except Exception as e:
        log.warning("forwarded update: %s", e)

def handle_update(upd):
    """Process a single Telegram update.
    Called by bot_loop when this process is the getUpdates poller, and by the
    /api/tg-update endpoint when the TypeScript bot polls and relays the updates
    this bot owns (/boss, inline duels, admin/support commands, my_chat_member,
    Stars top-ups)."""
    if upd.get("pre_checkout_query"):
        try:
            stars_precheckout(upd["pre_checkout_query"])
        except Exception as e:
            log.warning("pre-checkout: %s", e)
        return
    if (upd.get("message") or {}).get("successful_payment"):
        try:
            stars_paid(upd["message"])
        except Exception as e:
            log.warning("payment: %s", e)
        return
    cq = upd.get("callback_query")
    if cq:
        try:
            if (cq.get("data") or "").startswith("bs:"):
                boss_callback(cq)
                return
            if (cq.get("data") or "").startswith("wp:"):
                wipe_callback(cq)
                return
            if (cq.get("data") or "").startswith("nf:"):
                nft_callback(cq)
                return
            if (cq.get("data") or "").startswith("grm:"):
                gr_mute_callback(cq)
                return
            if (cq.get("data") or "") == "stats_all":
                tg_try("answerCallbackQuery", callback_query_id=cq["id"])
                m = cq.get("message") or {}
                stats_command({"chat": m.get("chat") or {"id": cq["from"]["id"]}, "from": cq["from"], "text": "/статистика все"})
                return
            broadcast_callback(cq)
        except Exception as e:
            log.warning("callback: %s", e)
        return
    cir = upd.get("chosen_inline_result")
    if cir:
        rid, imid = str(cir.get("result_id", "")), cir.get("inline_message_id")
        if rid.startswith("duel_") and imid:
            with db_lock:
                k = "dmsg:" + rid[5:]
                old = db.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
                lst = (json.loads(old[0]) if old else [])[-9:] + [imid]
                db.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (k, json.dumps(lst)))
                db.commit()
        return
    if upd.get("inline_query"):
        try:
            answer_inline(upd["inline_query"])
        except Exception as e:
            log.warning("inline answer: %s", e)
        return
    if upd.get("my_chat_member"):
        try:
            bot_rights(upd["my_chat_member"])
        except Exception as e:
            log.warning("my_chat_member: %s", e)
        return
    msg = upd.get("message") or {}
    if any((u.get("username") or "").lower() == (BOT_USERNAME or "").lower() for u in msg.get("new_chat_members") or []) \
            and msg.get("chat", {}).get("type") in ("group", "supergroup"):
        bot_joined(msg)
        return
    text = msg.get("text") or ""
    first = text.split()[0] if text.split() else ""
    if msg.get("chat", {}).get("type") in ("group", "supergroup"):
        try:
            mb_count_msg(msg)          # v264: remembers the groups the bot is in (a massacre is started there from the game)
        except Exception as e:
            log.warning("mb count: %s", e)
        if first.split("@")[0].lower() in ("/massacre", "/бойня") and ("@" not in first or first.split("@", 1)[1].lower() == (BOT_USERNAME or "").lower()):
            try:
                mb_command(msg)
            except Exception as e:
                log.warning("/massacre: %s", e)
            return
    if first.split("@")[0].lower() == "/start" and msg.get("chat", {}).get("type") in ("group", "supergroup"):
        # plain /start@bot after adding the bot (or /start boss|raid): show the boss panel
        try:
            boss_command(dict(msg, text="/boss " + " ".join(text.split()[1:])))
        except Exception as e:
            log.warning("/start in group: %s", e)
        return
    # v222: «@bot raid Андре» / «@bot босс» typed as a plain message (not picked from the inline card) calls the panel too
    tw = text.lower().split()
    if BOT_USERNAME and tw and tw[0] == "@" + BOT_USERNAME.lower() and len(tw) > 1 and tw[1] in ("raid", "boss", "рейд", "босс") \
            and msg.get("chat", {}).get("type") in ("group", "supergroup"):
        try:
            boss_command(dict(msg, text=" ".join(["/boss"] + text.split()[2:])))
        except Exception as e:
            log.warning("@bot boss: %s", e)
        return
    if first.split("@")[0].lower() == "/boss" and ("@" not in first or first.split("@", 1)[1].lower() == (BOT_USERNAME or "").lower()) \
            and msg.get("chat", {}).get("type") in ("group", "supergroup"):
        try:
            boss_command(msg)
        except Exception as e:
            log.warning("/boss: %s", e)
        return
    cmd = (text.split()[0] if text.split() else "").split("@")[0].lower()
    if not text and msg.get("caption"):
        cap = msg["caption"].split()
        if cap and cap[0].split("@")[0].lower() in ("/рассылка", "/broadcast"):
            cmd = cap[0].split("@")[0].lower()
    if cmd in ("/рассылка", "/broadcast") and msg.get("chat", {}).get("type") == "private":
        try:
            broadcast_command(msg)
        except Exception as e:
            log.warning("/broadcast: %s", e)
        return
    if cmd in ("/сброс", "/wipe") and msg.get("chat", {}).get("type") == "private":
        try:
            wipe_command(msg)
        except Exception as e:
            log.warning("/wipe: %s", e)
        return
    if cmd in ("/refund", "/возврат") and msg.get("chat", {}).get("type") == "private":
        try:
            refund_command(msg)
        except Exception as e:
            log.warning("/refund: %s", e)
        return
    if cmd in ("/terms", "/paysupport", "/support") and msg.get("chat", {}).get("type") == "private":
        try:
            terms_command(msg, cmd)
        except Exception as e:
            log.warning("/terms: %s", e)
        return
    if cmd in ("/nft", "/нфт") and msg.get("chat", {}).get("type") == "private":
        try:
            nft_command(msg)
        except Exception as e:
            log.warning("/nft: %s", e)
        return
    if cmd in ("/статистика", "/stats") and msg.get("chat", {}).get("type") == "private":
        try:
            stats_command(msg)
        except Exception as e:
            log.warning("/stats: %s", e)
        return
    if text.startswith("/start") and msg.get("chat", {}).get("type") == "private" and msg.get("from"):
        fr = msg["from"]
        ensure_player(fr)
        with db_lock:
            db.execute("UPDATE players SET can_pm=1, notify=CASE WHEN notify_off=1 THEN notify ELSE 1 END WHERE id=?", (fr["id"],))
            db.commit()
    if (msg.get("text") or "").startswith("/start") and msg.get("chat", {}).get("type") == "private":
        tg("sendMessage", chat_id=msg["chat"]["id"],
           text="Ебашня ждёт. Выбери героя и поднимайся всё выше: на каждом десятом этаже элита, на каждом пятидесятом — босс.",
           reply_markup={"inline_keyboard": [[{"text": "Войти в башню", "web_app": {"url": WEBAPP_URL}}]]})

def bot_loop():
    global BOT_USERNAME, BOT_ID
    if not WEBAPP_URL:
        log.warning("WEBAPP_URL is empty: the bot will not offer the game button")
    for _ in range(10):
        try:
            me = tg("getMe")["result"]
            BOT_USERNAME, BOT_ID = me["username"], me["id"]
            break
        except Exception as e:
            log.warning("getMe: %s", e)
            time.sleep(5)
    log.info("bot @%s, Mini App link %s", BOT_USERNAME, app_link())
    check_channel_access()
    threading.Thread(target=lambda: bot_card_file_id("invite"), daemon=True).start()
    try:
        tg("setChatMenuButton", menu_button={"type": "web_app", "text": "Играть", "web_app": {"url": WEBAPP_URL}})
    except Exception as e:
        log.warning("could not set the menu button: %s", e)
    # the «/» menu in private chats: Telegram asks every bot that takes Stars for /terms and /paysupport
    try:
        tg("setMyCommands", scope={"type": "all_private_chats"}, commands=[
            {"command": "start", "description": "Войти в башню"},
            {"command": "terms", "description": "Условия и конфиденциальность (18+)"},
            {"command": "paysupport", "description": "Помощь с оплатой звёздами"}])
    except Exception as e:
        log.warning("could not set private commands: %s", e)
    # the owners see their own commands in the «/» menu of their chat with the bot
    for a_id in ADMIN_IDS:
        try:
            tg("setMyCommands", scope={"type": "chat", "chat_id": a_id}, commands=[
                {"command": "start", "description": "Войти в башню"},
                {"command": "nft", "description": "NFT: кому что выпало, заявки, настройки"},
                {"command": "stats", "description": "Статистика игроков"},
                {"command": "broadcast", "description": "Рассылка всем игрокам"},
                {"command": "wipe", "description": "Сброс игрока"},
                {"command": "refund", "description": "Покупки звёзд и возврат"},
                {"command": "terms", "description": "Условия и конфиденциальность (18+)"}])
        except Exception as e:
            log.info("could not set owner commands for %s: %s", a_id, e)
    # the «/» menu in groups: admins see /boss there and a tap sends «/boss@bot», which always reaches this bot
    try:
        tg("setMyCommands", scope={"type": "all_chat_administrators"}, commands=[
            {"command": "boss", "description": "Призвать босса в чат"},
            {"command": "massacre", "description": "Массовая бойня: как создать розыгрыш"}])
    except Exception as e:
        log.warning("could not set group commands: %s", e)
    offset = 0
    while True:
        try:
            res = tg("getUpdates", offset=offset, timeout=30, allowed_updates=["message", "my_chat_member", "inline_query", "chosen_inline_result", "callback_query", "pre_checkout_query"])
            for upd in res.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    handle_update(upd)
                except Exception as e:
                    log.warning("update %s: %s", upd.get("update_id"), e)
        except Exception as e:
            log.warning("bot polling: %s", e)
            time.sleep(5)

def events_loop():
    """Events that ran out of time get their closing post."""
    while True:
        time.sleep(60)
        try:
            with db_lock:
                due = [r[0] for r in db.execute("SELECT ci FROM raid_events WHERE closed=0 AND ends<?", (time.time(),)).fetchall()]
            for ci in due:
                close_event(ci)
            season_close()
        except Exception as e:
            log.warning("events loop: %s", e)

def housekeeping_loop():
    while True:
        try:
            cards_cleanup()
            old = week_id() - 4
            with db_lock:
                db.execute("DELETE FROM raids WHERE week<? AND week>=0", (old,))
                db.execute("DELETE FROM raid_hits WHERE week<? AND week>=0", (old,))
                db.execute("DELETE FROM raid_tries WHERE day<?", (day_id() - 7,))
                db.execute("DELETE FROM raid_tries_c WHERE day<?", (day_id() - 7,))
                db.execute("DELETE FROM fight_log WHERE ts<?", (time.time() - 120 * 86400,))
                db.execute("DELETE FROM act WHERE day<?", (day_id() - 400,))
                db.commit()
        except Exception as e:
            log.warning("housekeeping: %s", e)
        time.sleep(6 * 3600)

if __name__ == "__main__":
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN is not set (see emberspire.env.example)")
    if os.environ.get("EMBER_NO_BOT") != "1":
        threading.Thread(target=bot_loop, daemon=True).start()
    else:
        # The TypeScript bot polls; learn the @username for app links without polling.
        try:
            _me = tg("getMe")["result"]
            BOT_USERNAME, BOT_ID = _me["username"], _me["id"]
        except Exception as e:
            log.warning("getMe: %s", e)
        check_channel_access()
    # These loops never call getUpdates, so they must run in both modes: with
    # EMBER_NO_BOT the reminders, channel checks and event closings still happen.
    threading.Thread(target=reminder_loop, daemon=True).start()
    threading.Thread(target=chan_loop, daemon=True).start()
    threading.Thread(target=events_loop, daemon=True).start()
    threading.Thread(target=mb_loop, daemon=True).start()
    threading.Thread(target=housekeeping_loop, daemon=True).start()
    def _br_warm():
        """v196: ask ourselves for the game page and its picture files, so the brotli copies are ready before the first player comes."""
        time.sleep(2)
        paths = ["/"] + ["/a/" + n for n in (os.listdir(os.path.join(PUBLIC, "a")) if os.path.isdir(os.path.join(PUBLIC, "a")) else []) if n.endswith(".js")]
        for _ in range(2):
            for pth in paths:
                try:
                    urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{PORT}{pth}", headers={"Accept-Encoding": "br"}), timeout=90).read()
                except Exception as e:
                    log.info("brotli warm %s: %s", pth, e)
            time.sleep(15)
    threading.Thread(target=_br_warm, daemon=True).start()
    threading.Thread(target=ac_loop, daemon=True).start()
    threading.Thread(target=ac_scan, daemon=True).start()
    threading.Thread(target=ac_digest_loop, daemon=True).start()
    log.info("Emberspire on 127.0.0.1:%s, game folder %s", PORT, PUBLIC)
    # v231: the standard backlog is 5 waiting connections — under a burst (a few hundred players at once) the rest were
    # refused and Caddy answered 502. 256 waiting connections, and request threads never hold the process at exit.
    class _Server(ThreadingHTTPServer):
        request_queue_size = 256
        daemon_threads = True
    _Server(("127.0.0.1", PORT), Handler).serve_forever()
